import streamlit as st

import api_client
import ui


def render():
    role = api_client.current_user().get("role_code")
    ui.heading("Users & Teams", "Manage portal identities and review developer workload.", role)
    if role == "MANAGER":
        with st.expander("Create user"):
            with st.form("create-user"):
                username = st.text_input("Username")
                email = st.text_input("Email")
                left, right = st.columns(2)
                first_name = left.text_input("First name")
                last_name = right.text_input("Last name")
                role_code = st.selectbox("Role", ["QA", "TECH_LEAD", "DEVELOPER", "MANAGER"])
                password = st.text_input(
                    "Initial password",
                    type="password",
                    help="At least 12 characters; Django password validation applies.",
                )
                if st.form_submit_button("Create user", type="primary"):
                    try:
                        api_client.request(
                            "POST",
                            "users/",
                            json={
                                "username": username,
                                "email": email,
                                "first_name": first_name,
                                "last_name": last_name,
                                "role_code": role_code,
                                "password": password,
                                "is_active": True,
                            },
                        )
                        st.success(
                            "User created. Share the initial password through your approved channel."
                        )
                        st.rerun()
                    except api_client.APIError as exc:
                        ui.friendly_error(exc)
    try:
        data = api_client.request("GET", "users/", params={"page_size": 100})
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    users = data.get("results", [])
    if not users:
        st.info("No team members found.")
        return
    st.dataframe(
        [
            {
                "Name": item["full_name"],
                "Username": item["username"],
                "Email": item["email"],
                "Role": item["role"],
                "Active": "Yes" if item["is_active"] else "No",
            }
            for item in users
        ],
        hide_index=True,
        width="stretch",
    )
    if role == "MANAGER":
        st.subheader("Deactivate a user")
        user_map = {
            f"{item['full_name']} · {item['role']}": item
            for item in users
            if item["is_active"] and item["role_code"] != "MANAGER"
        }
        if user_map:
            selected = st.selectbox("User", list(user_map))
            if st.button("Deactivate", type="secondary"):
                try:
                    api_client.request(
                        "PATCH", f"users/{user_map[selected]['id']}/", json={"is_active": False}
                    )
                    st.success("User deactivated.")
                    st.rerun()
                except api_client.APIError as exc:
                    ui.friendly_error(exc)


render()
