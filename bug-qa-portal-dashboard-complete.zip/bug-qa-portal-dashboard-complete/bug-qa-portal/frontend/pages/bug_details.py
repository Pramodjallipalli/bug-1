import streamlit as st

import api_client
import ui


def _role_flags():
    role = api_client.current_user().get("role_code", "DEVELOPER")
    mode = st.session_state.get("work_mode", "DEFAULT")
    return {
        "role": role,
        "qa": role in {"MANAGER", "QA"},
        "lead": role in {"MANAGER", "QA", "TECH_LEAD"},
        "developer": role in {"MANAGER", "DEVELOPER"}
        or (role in {"QA", "TECH_LEAD"} and mode == "DEVELOPER"),
    }


def _run_action(method, path, *, json=None, data=None, files=None, success="Updated"):
    try:
        api_client.request(method, path, json=json, data=data, files=files)
        st.success(success)
        st.rerun()
    except api_client.APIError as exc:
        ui.friendly_error(exc)


def _show_engineering(bug):
    cycles = bug.get("engineering", [])
    if not cycles:
        st.info("Engineering details will appear after a developer starts work.")
        return
    for cycle in cycles:
        with st.expander(
            f"Fix cycle {cycle['cycle']} · {cycle['developer']['full_name']} · PR {cycle['pr_status']} · CI {cycle['ci_status']}",
            expanded=cycle["cycle"] == bug.get("development_cycle"),
        ):
            left, right = st.columns(2)
            left.write(f"**Branch:** {cycle['branch_name'] or '—'}")
            left.write(f"**Commit:** {cycle['commit_reference'] or '—'}")
            right.write(f"**Pull request:** {cycle['pull_request_url'] or '—'}")
            right.write(f"**CI link:** {cycle['ci_link'] or '—'}")
            st.write(f"**Fix notes:** {cycle['fix_notes'] or '—'}")


def render():
    bug_id = st.session_state.get("selected_bug_id")
    if not bug_id:
        ui.heading("Bug Details", "Select a bug from the bug list.")
        st.info("Open a bug from **Bugs** to see its full history and workflow actions.")
        if st.button("← Back to Bugs"):
            st.switch_page("pages/bugs.py")
        return
    try:
        bug = api_client.request("GET", f"bugs/{bug_id}/")
    except api_client.APIError as exc:
        ui.heading("Bug Details")
        ui.friendly_error(exc)
        return
    flags = _role_flags()
    top = st.columns([0.08, 0.92])
    if top[0].button("← Back"):
        st.switch_page("pages/bugs.py")
    ui.heading(
        f"{bug['bug_key']} · {bug['title']}",
        f"{bug['project_name']} · Reported by {bug['reported_by']['full_name']}",
        flags["role"],
    )
    st.markdown(
        f"{ui.status_chip(bug['status'])} &nbsp;&nbsp; **Severity:** {bug['severity'].title()} &nbsp;&nbsp; **Priority:** {bug['priority']}",
        unsafe_allow_html=True,
    )
    st.divider()

    with st.expander("Workflow actions", expanded=True):
        if bug["status"] == "NEW" and flags["lead"]:
            with st.form(f"triage-{bug_id}"):
                note = st.text_input("Triage note", placeholder="Initial assessment or next step")
                if st.form_submit_button("Triage bug", type="primary"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/triage/",
                        json={"note": note},
                        success="Bug moved to triage.",
                    )
        if bug["status"] in {"IN_TRIAGE", "ASSIGNED"} and flags["lead"]:
            try:
                team = api_client.request("GET", "users/").get("results", [])
                developers = [
                    item
                    for item in team
                    if item.get("role_code") == "DEVELOPER" and item.get("is_active")
                ]
            except api_client.APIError as exc:
                developers = []
                ui.friendly_error(exc)
            if developers:
                with st.form(f"assign-{bug_id}"):
                    names = {
                        item.get("full_name") or item["username"]: item["id"] for item in developers
                    }
                    assignee_name = st.selectbox("Developer", list(names))
                    note = st.text_input("Assignment note", placeholder="Optional context")
                    action_label = "Reassign" if bug["status"] == "ASSIGNED" else "Assign developer"
                    if st.form_submit_button(action_label, type="primary"):
                        action = "reassign" if bug["status"] == "ASSIGNED" else "assign"
                        _run_action(
                            "POST",
                            f"bugs/{bug_id}/{action}/",
                            json={"user_id": names[assignee_name], "note": note},
                            success=f"Assigned to {assignee_name}.",
                        )
        if bug["status"] in {"ASSIGNED", "REOPENED"} and flags["developer"]:
            if st.button("Start Development", type="primary", key=f"start-{bug_id}"):
                _run_action(
                    "POST",
                    f"bugs/{bug_id}/start-work/",
                    json={},
                    success="Development cycle started.",
                )
        if bug["status"] == "IN_DEVELOPMENT" and flags["developer"]:
            with st.form(f"engineering-{bug_id}"):
                st.caption("Update the current engineering cycle.")
                branch = st.text_input(
                    "Branch",
                    value=(bug.get("engineering") or [{}])[0].get("branch_name", ""),
                    placeholder="fix/bug-key-short-summary",
                )
                commit = st.text_input(
                    "Commit",
                    value=(bug.get("engineering") or [{}])[0].get("commit_reference", ""),
                    placeholder="Commit SHA",
                )
                notes = st.text_area(
                    "Fix notes",
                    value=(bug.get("engineering") or [{}])[0].get("fix_notes", ""),
                    placeholder="Describe the implementation and verification.",
                )
                saved = st.form_submit_button("Save engineering details")
            if saved:
                _run_action(
                    "PATCH",
                    f"bugs/{bug_id}/engineering/",
                    json={"branch_name": branch, "commit_reference": commit, "fix_notes": notes},
                    success="Engineering details saved.",
                )
            current_notes = (bug.get("engineering") or [{}])[0].get("fix_notes", "")
            with st.form(f"fix-{bug_id}"):
                fix_notes = st.text_area(
                    "Fix summary for review", value=current_notes, key=f"fix-notes-{bug_id}"
                )
                if st.form_submit_button("Submit Fix"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/submit-fix/",
                        json={"fix_notes": fix_notes},
                        success="Fix submitted for review.",
                    )
        if bug["status"] in {"FIX_SUBMITTED", "PR_REVIEW"} and flags["developer"]:
            current = (bug.get("engineering") or [{}])[0]
            with st.form(f"pr-{bug_id}"):
                pr_url = st.text_input(
                    "Pull request URL",
                    value=current.get("pull_request_url", ""),
                    placeholder="https://github.com/org/repo/pull/123",
                )
                pr_status = st.selectbox(
                    "PR status", ["OPEN", "CHANGES_REQUESTED", "APPROVED", "MERGED"], index=0
                )
                if st.form_submit_button("Save PR status", type="primary"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/pr/",
                        json={"pull_request_url": pr_url, "pr_status": pr_status},
                        success=f"Pull request marked {pr_status.lower()}.",
                    )
        if bug["status"] == "CI_PENDING" and flags["developer"]:
            current = (bug.get("engineering") or [{}])[0]
            with st.form(f"ci-{bug_id}"):
                ci_status = st.selectbox("CI result", ["PASSED", "FAILED"])
                ci_link = st.text_input(
                    "CI run URL",
                    value=current.get("ci_link", ""),
                    placeholder="https://ci.example/run/123",
                )
                if st.form_submit_button("Record CI result", type="primary"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/ci/",
                        json={"ci_status": ci_status, "ci_link": ci_link},
                        success=f"CI result recorded: {ci_status.lower()}.",
                    )
        if bug["status"] == "CI_PASSED" and flags["developer"]:
            with st.form(f"deploy-{bug_id}"):
                environment = st.selectbox("Environment", ["Staging", "Production", "QA"])
                version = st.text_input("Version", placeholder="2.8.1")
                deployment_link = st.text_input(
                    "Deployment link", placeholder="https://deploy.example/releases/123"
                )
                notes = st.text_input("Deployment notes", placeholder="Optional release details")
                if st.form_submit_button("Record Deployment", type="primary"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/deploy/",
                        json={
                            "environment": environment,
                            "version": version,
                            "deployment_link": deployment_link,
                            "notes": notes,
                        },
                        success="Deployment recorded.",
                    )
        if bug["status"] == "DEPLOYED" and flags["developer"]:
            if st.button("Ready for Retest", type="primary", key=f"ready-{bug_id}"):
                _run_action(
                    "POST",
                    f"bugs/{bug_id}/ready-for-retest/",
                    json={},
                    success="QA has been notified that the fix is ready.",
                )
        if bug["status"] == "READY_FOR_RETEST" and flags["qa"]:
            with st.form(f"retest-{bug_id}"):
                test_environment = st.text_input(
                    "Test environment", value=bug.get("environment") or "Staging"
                )
                test_version = st.text_input(
                    "Version under test", value=bug.get("application_version") or ""
                )
                test_steps = st.text_area("Test steps", value=bug.get("steps_to_reproduce", ""))
                expected = st.text_area("Expected result", value=bug.get("expected_result", ""))
                actual = st.text_area("Actual result", value=bug.get("actual_result", ""))
                result = st.radio("Retest result", ["PASS", "FAIL"], horizontal=True)
                remarks = st.text_area(
                    "QA remarks", placeholder="Verification notes or failure details"
                )
                if st.form_submit_button("Save QA Retest", type="primary"):
                    body = {
                        "test_environment": test_environment,
                        "test_version": test_version,
                        "test_steps": test_steps,
                        "expected_result": expected,
                        "actual_result": actual,
                        "test_result": result,
                        "remarks": remarks,
                    }
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/retests/",
                        json=body,
                        success=f"Retest saved: {result}.",
                    )
        if bug["status"] == "CLOSED" and flags["role"] in {"MANAGER", "QA", "TECH_LEAD"}:
            with st.form(f"reopen-{bug_id}"):
                note = st.text_input(
                    "Reason to reopen", placeholder="Why should this closed bug return to work?"
                )
                if st.form_submit_button("Reopen Bug"):
                    _run_action(
                        "POST",
                        f"bugs/{bug_id}/reopen/",
                        json={"note": note},
                        success="Bug reopened.",
                    )
        if not any(
            (
                bug["status"] == "NEW" and flags["lead"],
                bug["status"] in {"IN_TRIAGE", "ASSIGNED"} and flags["lead"],
                bug["status"] in {"ASSIGNED", "REOPENED"} and flags["developer"],
                bug["status"] == "IN_DEVELOPMENT" and flags["developer"],
                bug["status"]
                in {"FIX_SUBMITTED", "PR_REVIEW", "CI_PENDING", "CI_PASSED", "DEPLOYED"}
                and flags["developer"],
                bug["status"] == "READY_FOR_RETEST" and flags["qa"],
                bug["status"] == "CLOSED" and flags["role"] in {"MANAGER", "QA", "TECH_LEAD"},
            )
        ):
            st.info("No workflow action is available for your current role at this stage.")

    (
        overview,
        engineering_tab,
        deployments_tab,
        retests_tab,
        comments_tab,
        history_tab,
        files_tab,
    ) = st.tabs(
        [
            "Overview",
            "Engineering & PR / CI",
            "Deployments",
            "Retests",
            "Comments",
            "History",
            "Attachments",
        ]
    )
    with overview:
        left, right = st.columns(2)
        with left:
            st.subheader("Description")
            st.write(bug["description"])
            st.subheader("Steps to Reproduce")
            st.write(bug.get("steps_to_reproduce") or "—")
            st.subheader("Expected Result")
            st.write(bug.get("expected_result") or "—")
            st.subheader("Actual Result")
            st.write(bug.get("actual_result") or "—")
        with right:
            st.markdown('<div class="panel"><h3>Bug information</h3>', unsafe_allow_html=True)
            st.write(f"**Project:** {bug['project_name']} ({bug['project_key']})")
            st.write(f"**Reporter:** {bug['reported_by']['full_name']}")
            st.write(
                f"**Tech Lead:** {bug['tech_lead']['full_name'] if bug.get('tech_lead') else 'Unassigned'}"
            )
            st.write(
                f"**Developer:** {bug['assigned_to']['full_name'] if bug.get('assigned_to') else 'Unassigned'}"
            )
            st.write(
                f"**QA Verifier:** {bug['verified_by']['full_name'] if bug.get('verified_by') else '—'}"
            )
            st.write(
                f"**Environment / version:** {bug.get('environment') or '—'} · {bug.get('application_version') or '—'}"
            )
            st.write(
                f"**Created:** {bug['created_at'][:10]} · **Updated:** {bug['updated_at'][:10]}"
            )
            st.write(
                f"**Fix cycles:** {bug.get('development_cycle', 0)} · **Reopens:** {bug.get('reopen_count', 0)}"
            )
            st.markdown("</div>", unsafe_allow_html=True)
        transitions = bug.get("status_transitions", [])
        st.subheader("Lifecycle")
        st.caption(
            " → ".join(["NEW"] + [item["to_status"] for item in transitions])
            if transitions
            else "NEW · Waiting for triage"
        )
    with engineering_tab:
        _show_engineering(bug)
    with deployments_tab:
        for item in bug.get("deployments", []):
            st.markdown(
                f"**Cycle {item['cycle']} · {item['environment']} · {item['version'] or 'version not set'}**"
            )
            st.caption(
                f"By {item['deployed_by']['full_name']} · {item['deployed_at'][:19].replace('T', ' ')} UTC · {item.get('deployment_link') or 'No release link'}"
            )
            if item.get("notes"):
                st.write(item["notes"])
        if not bug.get("deployments"):
            st.info("No deployments recorded yet.")
    with retests_tab:
        retests = bug.get("retests", [])
        if retests:
            st.dataframe(
                [
                    {
                        "Cycle": item["cycle"],
                        "Result": item["test_result"],
                        "Tester": item["retested_by"]["full_name"],
                        "Environment": item["test_environment"],
                        "Version": item["test_version"],
                        "Retested at": item["retested_at"][:19].replace("T", " "),
                        "Remarks": item["remarks"],
                    }
                    for item in retests
                ],
                hide_index=True,
                width="stretch",
            )
            for item in retests:
                with st.expander(
                    f"Retest cycle {item['cycle']} · {item['test_result']} · {item['retested_by']['full_name']}"
                ):
                    st.write(
                        f"**Steps:** {item['test_steps']}\n\n**Expected:** {item['expected_result']}\n\n**Actual:** {item['actual_result']}\n\n**Remarks:** {item['remarks'] or '—'}"
                    )
        else:
            st.info("No retest results have been recorded.")
    with comments_tab:
        try:
            comments = api_client.request("GET", f"bugs/{bug_id}/comments/")
        except api_client.APIError as exc:
            comments = []
            ui.friendly_error(exc)
        for comment in comments:
            st.markdown(
                f"**{comment['user']['full_name']}** · {comment['created_at'][:16].replace('T', ' ')} UTC"
            )
            st.write(comment["comment"])
            st.divider()
        with st.form(f"comment-{bug_id}"):
            comment_text = st.text_area("Add a comment", max_chars=4000)
            if st.form_submit_button("Post comment"):
                _run_action(
                    "POST",
                    f"bugs/{bug_id}/comments/",
                    json={"comment": comment_text},
                    success="Comment posted.",
                )
    with history_tab:
        for event in bug.get("history", []):
            st.markdown(
                f"**{event['action']}** · {event['user']['full_name']} · {event['performed_mode'].replace('_', ' ').title()}"
            )
            detail = " → ".join(
                value for value in (event.get("old_value"), event.get("new_value")) if value
            )
            st.caption(
                f"{event['created_at'][:19].replace('T', ' ')} UTC · {detail} · {event.get('notes') or ''}"
            )
        for transition in bug.get("status_transitions", []):
            st.caption(
                f"{transition['from_status']} → {transition['to_status']} · {transition['actor']['full_name']} · {transition['created_at'][:19].replace('T', ' ')} UTC"
            )
        if not bug.get("history") and not bug.get("status_transitions"):
            st.info("No history available yet.")
    with files_tab:
        try:
            attachments = api_client.request("GET", f"bugs/{bug_id}/attachments/")
        except api_client.APIError as exc:
            attachments = []
            ui.friendly_error(exc)
        for attachment in attachments:
            with st.expander(f"{attachment['original_name']} · {attachment['size']} bytes"):
                if st.button("Prepare download", key=f"prepare-download-{attachment['id']}"):
                    try:
                        file_response = api_client.request(
                            "GET",
                            f"bugs/{bug_id}/attachments/{attachment['id']}/download/",
                            stream=True,
                        )
                        st.download_button(
                            f"Save {attachment['original_name']}",
                            data=file_response.content,
                            file_name=attachment["original_name"],
                            mime=attachment["content_type"],
                            key=f"download-{attachment['id']}",
                        )
                    except api_client.APIError as exc:
                        ui.friendly_error(exc)
        upload = st.file_uploader(
            "Add attachment",
            type=["png", "jpg", "jpeg", "gif", "pdf", "txt", "log", "csv"],
            key=f"upload-{bug_id}",
        )
        if upload and st.button("Upload file", key=f"upload-button-{bug_id}"):
            file_data = {
                "file": (upload.name, upload.getvalue(), upload.type or "application/octet-stream")
            }
            _run_action(
                "POST",
                f"bugs/{bug_id}/attachments/",
                files=file_data,
                success="Attachment uploaded.",
            )


render()
