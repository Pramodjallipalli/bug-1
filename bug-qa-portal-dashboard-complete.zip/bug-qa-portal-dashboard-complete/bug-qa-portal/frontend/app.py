import streamlit as st

import api_client
import ui

st.set_page_config(
    page_title="BugTracker · QA Retest Portal",
    page_icon="🐞",
    layout="wide",
    initial_sidebar_state="expanded",
)
ui.inject_theme()


def login_page():
    st.markdown(
        '<div style="height:8vh"></div><div class="panel" style="max-width:560px;margin:auto;padding:30px 34px">',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="eyebrow">BUG MANAGEMENT &amp; QA RETEST</div><h1>Welcome to BugTracker</h1><p class="muted">Sign in to report, triage, fix, and verify bugs.</p>',
        unsafe_allow_html=True,
    )
    with st.form("login-form", clear_on_submit=False):
        username = st.text_input("Username", placeholder="e.g. qa")
        password = st.text_input("Password", type="password", placeholder="Your password")
        submitted = st.form_submit_button("Sign in", type="primary", width="stretch")
    if submitted:
        try:
            api_client.login(username.strip(), password)
            # st.navigation() uses the Dashboard page marked default=True.
            # A plain rerun lets Streamlit render that page reliably after login;
            # forcing st.switch_page() here can race with navigation initialization.
            st.rerun()
        except api_client.APIError as exc:
            st.error(str(exc))
    st.caption(
        "For local demo accounts, see the one-time password printed by `docker compose logs backend`."
    )
    st.markdown("</div>", unsafe_allow_html=True)


if not api_client.authenticated():
    login_page()
    st.stop()

user = api_client.current_user()
role = user.get("role_code", "DEVELOPER")
role_title = user.get("role", role.replace("_", " ").title())

with st.sidebar:
    st.markdown(
        '<div class="brand">BugTracker<small>Bug Management &amp; QA Retest</small></div>',
        unsafe_allow_html=True,
    )
    st.divider()
    st.markdown(
        f"**{user.get('full_name') or user.get('username')}**  \n<small>{role_title}</small>",
        unsafe_allow_html=True,
    )
    if role in {"QA", "TECH_LEAD"}:
        enabled = st.toggle(
            "Developer Mode",
            value=st.session_state.get("work_mode") == "DEVELOPER",
            help="Allows permitted engineering work and records the active mode in bug history.",
        )
        st.session_state["work_mode"] = "DEVELOPER" if enabled else "DEFAULT"
    elif role == "MANAGER":
        st.caption("Full workflow access")
    st.divider()
    if st.button("↪  Sign out", width="stretch"):
        api_client.logout()
        st.rerun()

dashboard_page = st.Page("pages/dashboard.py", title="Dashboard", icon="📊", default=True)
bugs_page = st.Page("pages/bugs.py", title="Bugs", icon="🐞")
report_page = st.Page("pages/report_bug.py", title="Report Issue", icon="➕")
projects_page = st.Page("pages/projects.py", title="Projects", icon="📁")
notifications_page = st.Page("pages/notifications.py", title="Notifications", icon="🔔")
bug_detail_page = st.Page("pages/bug_details.py", title="Bug Details", icon="🔎")
users_page = st.Page("pages/users.py", title="Users & Teams", icon="👥")
triage_page = st.Page("pages/triage.py", title="Triage & Assign", icon="🧭")
retest_page = st.Page("pages/retest.py", title="Retest & Verify", icon="🧪")
development_page = st.Page("pages/development.py", title="Development", icon="💻")
reports_page = st.Page("pages/reports.py", title="Reports & Analytics", icon="📈")
activity_page = st.Page("pages/activity.py", title="Activity", icon="🕘")
verify_issues_page = st.Page("pages/verify_issues.py", title="Verify Reported Issues", icon="✅")
my_issues_page = st.Page("pages/my_issues.py", title="My Reported Issues", icon="📨")

if role == "MANAGER":
    # Manager has full operational access, so expose every workflow page.
    pages = [
        dashboard_page,
        report_page,
        my_issues_page,
        verify_issues_page,
        bugs_page,
        bug_detail_page,
        triage_page,
        development_page,
        retest_page,
        projects_page,
        users_page,
        reports_page,
        activity_page,
        notifications_page,
    ]
elif role == "QA":
    pages = [
        dashboard_page,
        report_page,
        my_issues_page,
        verify_issues_page,
        bugs_page,
        bug_detail_page,
        triage_page,
        retest_page,
        development_page,
        projects_page,
        reports_page,
        activity_page,
        notifications_page,
    ]
elif role == "TECH_LEAD":
    pages = [
        dashboard_page,
        report_page,
        my_issues_page,
        bugs_page,
        bug_detail_page,
        triage_page,
        development_page,
        reports_page,
        projects_page,
        users_page,
        activity_page,
        notifications_page,
    ]
else:
    pages = [
        dashboard_page,
        report_page,
        my_issues_page,
        bugs_page,
        bug_detail_page,
        development_page,
        reports_page,
        activity_page,
        notifications_page,
    ]

page = st.navigation({"WORKSPACE": pages}, position="sidebar", expanded=True)
page.run()
