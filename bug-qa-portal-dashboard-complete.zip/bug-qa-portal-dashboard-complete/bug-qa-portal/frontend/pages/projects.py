import streamlit as st

import api_client
import ui


def render():
    user = api_client.current_user()
    role = user.get("role_code")
    ui.heading("Projects", "Project-level bug ownership and reporting.", role)
    if role == "MANAGER":
        with st.expander("Create project"):
            with st.form("create-project"):
                name = st.text_input("Project name")
                key = st.text_input(
                    "Project key", max_chars=16, help="Short unique key, for example ECOM"
                )
                description = st.text_area("Description")
                if st.form_submit_button("Create project", type="primary"):
                    try:
                        api_client.request(
                            "POST",
                            "projects/",
                            json={
                                "name": name,
                                "key": key.upper(),
                                "description": description,
                                "is_active": True,
                            },
                        )
                        st.success("Project created.")
                        st.rerun()
                    except api_client.APIError as exc:
                        ui.friendly_error(exc)
    try:
        result = api_client.request("GET", "projects/", params={"page_size": 100})
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    projects = result.get("results", [])
    if not projects:
        st.info("No projects found.")
        return
    for project in projects:
        with st.container(border=True):
            left, right = st.columns([0.8, 0.2])
            left.markdown(
                f"### {project['name']}  \n`{project['key']}` · {project['description'] or 'No description'}"
            )
            right.metric("Active", "Yes" if project["is_active"] else "No")
            try:
                bugs = api_client.request(
                    "GET", "bugs/", params={"project": project["id"], "page_size": 1}
                )
                st.caption(f"{bugs.get('count', 0)} bugs tracked")
            except api_client.APIError:
                pass


render()
