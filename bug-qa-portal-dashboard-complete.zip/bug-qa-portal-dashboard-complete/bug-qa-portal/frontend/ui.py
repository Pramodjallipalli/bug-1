from html import escape

import streamlit as st

ROLE_COLORS = {
    "MANAGER": "#1688ff",
    "QA": "#a178ff",
    "TECH_LEAD": "#10c7a1",
    "DEVELOPER": "#ff9a43",
}
STATUS_COLORS = {
    "NEW": "#238ff0",
    "IN_TRIAGE": "#f28a31",
    "ASSIGNED": "#a274ff",
    "IN_DEVELOPMENT": "#9d75f5",
    "FIX_SUBMITTED": "#a274ff",
    "PR_REVIEW": "#8f68e7",
    "CI_PENDING": "#e5ad32",
    "CI_PASSED": "#15bea0",
    "DEPLOYED": "#15bea0",
    "READY_FOR_RETEST": "#22caa8",
    "QA_RETEST": "#a178ff",
    "REOPENED": "#ff755f",
    "CLOSED": "#08bd8d",
    "INVALID": "#8798aa",
}


def inject_theme():
    st.markdown(
        """<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
    :root{color-scheme:dark;--ink:#eef5ff;--muted:#91a8c0;--line:#1a3851;--panel:#0b2033;--accent:#1688ff}
    html,body,[class*="stApp"]{font-family:'DM Sans',sans-serif}
    [data-testid="stAppViewContainer"]{background:radial-gradient(ellipse at 20% -10%,#10314c 0%,transparent 42%),#071421;color:var(--ink)}
    [data-testid="stHeader"]{background:rgba(7,20,33,.82)}
    [data-testid="stSidebar"]{background:linear-gradient(180deg,#081b2d,#071523);border-right:1px solid #142e45}
    [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p{color:#c5d6e7}
    h1,h2,h3{font-family:'Manrope',sans-serif;letter-spacing:-.3px}
    h1{font-size:1.8rem!important;font-weight:800!important} h2{font-size:1.12rem!important;font-weight:700!important} h3{font-size:.96rem!important}
    p,li{color:#c3d2e1}.stCaption,small{color:#8ca5bb!important}
    [data-testid="stMetric"]{background:linear-gradient(145deg,#0d263d,#091b2c);border:1px solid #1a3851;border-radius:10px;padding:15px 16px;box-shadow:0 6px 18px #0002}
    [data-testid="stMetricLabel"]{color:#afc3d6!important;font-size:.75rem!important}
    [data-testid="stMetricValue"]{font:800 1.55rem 'Manrope',sans-serif!important;color:#f1f7ff!important}
    div[data-testid="stForm"]{background:#0b2033;border:1px solid #1a3851;border-radius:10px;padding:20px}
    [data-testid="stExpander"]{border:1px solid #1a3851!important;border-radius:8px!important;background:#0a1f31}
    .stButton>button,.stDownloadButton>button{border-radius:7px;border:1px solid #286391;background:#103554;color:#dbedff;font-weight:600}
    .stButton>button:hover,.stDownloadButton>button:hover{border-color:#48baff;background:#12446d;color:white}
    button[kind="primary"]{background:linear-gradient(180deg,#168dff,#0870ed)!important;border-color:#268cff!important;color:white!important}
    input,textarea,[data-baseweb="select"]>div{background:#091d2e!important;border-color:#21415c!important;color:#eff6ff!important}
    [data-testid="stDataFrame"],[data-testid="stTable"]{border:1px solid #1b3952;border-radius:8px;overflow:hidden}
    .brand{font:800 1.2rem 'Manrope',sans-serif;color:white;margin:.5rem 0 0}.brand small{font:500 .64rem 'DM Sans',sans-serif;display:block;color:#8eabc4;margin-top:2px;letter-spacing:.4px}
    .role-pill{display:inline-flex;align-items:center;padding:5px 9px;border-radius:999px;border:1px solid currentColor;font-size:.7rem;font-weight:700;letter-spacing:.25px}
    .eyebrow{font-size:.68rem;color:#51baff;letter-spacing:1.2px;font-weight:700;text-transform:uppercase}
    .panel{background:linear-gradient(145deg,#0b2033,#091b2c);border:1px solid #1a3851;border-radius:10px;padding:17px 18px;margin:.25rem 0 1rem;box-shadow:0 5px 16px #0002}
    .bug-key{font:700 .8rem 'Manrope',sans-serif;color:#47baff}.muted{color:#8ca5bb}.status-chip{padding:4px 8px;border-radius:5px;background:#14314a;font-size:.68rem;font-weight:700;white-space:nowrap}
    .stAlert{border-radius:8px}.block-container{padding-top:1.5rem;padding-bottom:3rem;max-width:1500px}
    @media(max-width:700px){.block-container{padding:1rem .8rem 2rem} h1{font-size:1.45rem!important}}
    </style>""",
        unsafe_allow_html=True,
    )


def heading(title, subtitle="", role=None):
    role_html = ""
    if role:
        color = ROLE_COLORS.get(role, "#1688ff")
        role_html = (
            f'<span class="role-pill" style="color:{color}">{escape(role.replace("_", " "))}</span>'
        )
    st.markdown(
        f'<div class="eyebrow">BugTracker · Bug Management &amp; QA Retest</div><div style="display:flex;align-items:center;gap:12px;margin:.1rem 0"><h1 style="margin:0">{escape(title)}</h1>{role_html}</div>',
        unsafe_allow_html=True,
    )
    if subtitle:
        st.caption(subtitle)


def status_chip(status):
    color = STATUS_COLORS.get(status, "#8fa9c1")
    label = status.replace("_", " ").title()
    return f'<span class="status-chip" style="color:{color}">{escape(label)}</span>'


def bug_link(bug):
    return f'<span class="bug-key">{escape(bug.get("bug_key", ""))}</span> · {escape(bug.get("title", ""))}'


def friendly_error(exc):
    if getattr(exc, "status_code", None) == 403:
        st.error("You do not have permission to perform this action.")
    elif getattr(exc, "status_code", None) == 401:
        st.error("Session expired. Please log in again.")
    else:
        st.error(str(exc))
