#!/bin/sh
set -eu
cd /app
python manage.py migrate --noinput
if [ "${DEMO_SEED:-1}" = "1" ]; then
  python manage.py seed_demo
fi
python manage.py collectstatic --noinput
exec gunicorn --chdir /app/backend config.wsgi:application --bind 0.0.0.0:8000 --workers 3 --timeout 120
