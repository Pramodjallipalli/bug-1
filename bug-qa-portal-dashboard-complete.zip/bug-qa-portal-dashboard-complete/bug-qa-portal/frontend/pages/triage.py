from bug_list import render_bug_list


def render():
    render_bug_list(
        "Triage Official Bugs",
        "Triage confirmed bugs and manage developer assignment. Reported issues are verified separately by QA.",
        forced_status="NEW",
    )


render()
