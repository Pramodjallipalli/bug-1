from bug_list import render_bug_list


def render():
    render_bug_list()


render()
