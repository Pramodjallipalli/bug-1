import streamlit as st
import api_client
import ui

def render():
    user = api_client.current_user()
    ui.heading("My Reported Issues", "Track issues you submitted before they become official bugs.", user.get("role_code"))
    try:
        issues = api_client.request("GET", "reported-issues/").get("results", [])
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    own = [i for i in issues if i.get("reported_by", {}).get("id") == user.get("id")]
    if not own:
        st.info("You have not reported any issues yet.")
        return
    for issue in own:
        status_label = issue["status"].replace("_", " ").title()
        with st.expander(f"{issue['issue_key']} · {issue['title']} · {status_label}"):
            st.write(f"**Project:** {issue['project_key']} · **Reported:** {issue['created_at'][:16].replace('T',' ')} UTC")
            st.write(issue["description"])
            if issue["status"] == "CONVERTED":
                st.success(f"Converted to official bug {issue.get('converted_bug_key')}.")
            elif issue["status"] == "REJECTED":
                st.warning(f"QA decision: {issue.get('review_note') or 'Not a bug.'}")
            else:
                st.info("Awaiting QA verification.")
render()
