import streamlit as st

import api_client
import ui


def render():
    role = api_client.current_user().get("role_code")
    ui.heading("Notifications", "Assignments, workflow changes, retests, and comments.", role)
    try:
        result = api_client.request("GET", "notifications/", params={"page_size": 100})
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    notifications = result.get("results", [])
    unread = [item for item in notifications if not item["is_read"]]
    if unread and st.button("Mark all as read"):
        try:
            api_client.request("PATCH", "notifications/read-all/", json={})
            st.success("Notifications marked as read.")
            st.rerun()
        except api_client.APIError as exc:
            ui.friendly_error(exc)
    if not notifications:
        st.info("No notifications yet.")
        return
    for item in notifications:
        with st.container(border=True):
            left, right = st.columns([0.8, 0.2])
            left.markdown(
                f"**{item['title']}**  \n{item['body'] or ''}  \n<small>{item['kind']} · {item['created_at'][:16].replace('T', ' ')} UTC · {'Read' if item['is_read'] else 'Unread'}</small>",
                unsafe_allow_html=True,
            )
            if item.get("bug_key") and left.button(
                f"Open {item['bug_key']}", key=f"notification-open-{item['id']}"
            ):
                try:
                    bugs = api_client.request("GET", "bugs/", params={"search": item["bug_key"]})
                    if bugs.get("results"):
                        st.session_state["selected_bug_id"] = bugs["results"][0]["id"]
                        st.switch_page("pages/bug_details.py")
                except api_client.APIError as exc:
                    ui.friendly_error(exc)
            if not item["is_read"] and right.button(
                "Mark read", key=f"notification-read-{item['id']}"
            ):
                try:
                    api_client.request("PATCH", f"notifications/{item['id']}/read/", json={})
                    st.rerun()
                except api_client.APIError as exc:
                    ui.friendly_error(exc)


render()
