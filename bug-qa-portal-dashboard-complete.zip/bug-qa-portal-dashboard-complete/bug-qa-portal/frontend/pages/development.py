from bug_list import render_bug_list


def render():
    render_bug_list(
        "Development Work",
        "Track assigned fixes, pull requests, CI results, and deployments.",
        forced_status="IN_DEVELOPMENT",
    )


render()
