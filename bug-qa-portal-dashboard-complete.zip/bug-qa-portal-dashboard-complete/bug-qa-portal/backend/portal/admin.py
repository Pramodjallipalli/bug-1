from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import (
    Bug,
    BugAssignment,
    BugAttachment,
    BugComment,
    BugDeploymentHistory,
    BugEngineering,
    BugHistory,
    BugRetest,
    BugStatusTransition,
    Notification,
    Permission,
    Project,
    Role,
    RolePermission,
    User,
    UserRole,
)


@admin.register(User)
class PortalUserAdmin(UserAdmin):
    list_display = ("username", "email", "first_name", "last_name", "is_active", "role_code")
    list_filter = ("is_active", "roles__code")
    search_fields = ("username", "email", "first_name", "last_name")
    # Role memberships are administered through the explicit UserRole table.


@admin.register(Bug)
class BugAdmin(admin.ModelAdmin):
    list_display = (
        "bug_key",
        "title",
        "project",
        "severity",
        "priority",
        "status",
        "assigned_to",
        "updated_at",
    )
    list_filter = ("status", "severity", "priority", "project", "is_reopened")
    search_fields = ("bug_key", "title", "description")
    readonly_fields = ("bug_key", "reported_by", "created_at", "updated_at", "closed_at")


admin.site.register(
    (
        Role,
        Permission,
        RolePermission,
        UserRole,
        Project,
        BugAssignment,
        BugEngineering,
        BugDeploymentHistory,
        BugRetest,
        BugStatusTransition,
        BugHistory,
        BugComment,
        BugAttachment,
        Notification,
    )
)
