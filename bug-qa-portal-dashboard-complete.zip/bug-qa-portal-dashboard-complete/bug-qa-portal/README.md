# BugTracker — Bug Management & QA Retest Portal

An independent bug workflow portal for reporting, triage, engineering, deployment, QA verification, audit history, and role-based dashboards. It does not connect to or share data with a parent PMS. Every role can report an Issue; QA verifies it before an official bug is created. The Manager has full operational access.

## Architecture

```text
Streamlit UI  →  Django REST Framework API  →  Django ORM  →  PostgreSQL
```

The Streamlit frontend talks only to the REST API. JWT authentication and database-backed role capabilities are checked by the backend. Django migrations own the schema. The development setup can use SQLite; Docker Compose runs PostgreSQL.

### Stack

- Python 3.13 in Docker; local development supports Python 3.10+
- Streamlit, requests, Plotly
- Django 5.2 LTS, Django REST Framework, SimpleJWT, drf-spectacular
- PostgreSQL with psycopg 3
- pytest, pytest-django, DRF APIClient, Playwright, Ruff, Black

### Project layout

```text
backend/config/                 Django settings and URL configuration
backend/portal/                 Models, permissions, workflow, API, seed command
backend/portal/migrations/      Database migrations
backend/portal/tests/           API/workflow and Playwright smoke tests
frontend/app.py                 Role-aware Streamlit navigation
frontend/pages/                 Dashboards and workflow pages
docker/                         Container startup scripts
.github/workflows/ci.yml        PostgreSQL, tests, lint, browser smoke CI
```

## Run with Docker Compose

1. Copy `.env.example` to `.env` and replace `DB_PASSWORD` and `DJANGO_SECRET_KEY` with private values. `DATABASE_URL` is optional; when blank, the app uses `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT`. JWT access and refresh lifetimes are configurable with `JWT_ACCESS_MINUTES` and `JWT_REFRESH_DAYS`.
2. Start the app:

   ```powershell
   docker compose up --build
   ```

3. Open the UI at [http://localhost:8501](http://localhost:8501), the API at [http://localhost:8000/api/](http://localhost:8000/api/), and interactive API documentation at [http://localhost:8000/api/docs/](http://localhost:8000/api/docs/).

The backend applies migrations and seeds demo data on startup when `DEMO_SEED=1`. Set `DEMO_PASSWORD` in `.env` to select a local demo password. If it is blank, the seed command generates one once; read it with:

```powershell
docker compose logs backend
```

Demo usernames are `manager`, `qa`, `techlead`, `rahul`, `karan`, `sneha`, `vikram`, and `ayush`. The generated or chosen password is shared by the seeded accounts; change it before using any non-demo environment.

Stop the services with `Ctrl+C`; use `docker compose down` to remove the containers while keeping named database/media volumes. `docker compose down -v` also deletes those volumes and their data.

## Run locally without Docker

Use Python 3.10 or newer. From the project root, install dependencies:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements-dev.txt -r requirements-frontend.txt
```

Set local development values and initialize the SQLite database:

```powershell
$env:DATABASE_URL = "sqlite:///./local-dev.sqlite3"
$env:DJANGO_SECRET_KEY = "replace-with-a-long-local-development-secret"
$env:DEMO_PASSWORD = "replace-with-a-local-demo-password"
python manage.py migrate
python manage.py seed_demo
```

In one terminal, run the API:

```powershell
python manage.py runserver 127.0.0.1:8000
```

In a second terminal with the virtual environment active, run the UI:

```powershell
$env:API_BASE_URL = "http://127.0.0.1:8000/api"
streamlit run frontend/app.py
```

The frontend opens at [http://localhost:8501](http://localhost:8501). For local development only, the default API base URL is also `http://127.0.0.1:8000/api`.

## Roles and workflow

| Role | Capabilities |
| --- | --- |
| Manager | Full operational access, including QA verification |
| QA | Report, triage, assign, develop, retest, PASS/FAIL, comments, attachments, reports |
| Tech Lead | Report, triage, assign, develop, PR/CI/deployment tracking; cannot retest or verify |
| Developer | Report and work on permitted/assigned bugs; cannot retest or verify |

QA and Tech Lead can enable Developer Mode for permitted engineering actions. It uses the same user identity and is recorded in the audit trail. All roles with BUG_VIEW can view bug status/details/history. Developer and other workflow actions remain protected by capability and ownership rules; direct status PATCH requests are rejected.

The controlled path is:

```text
NEW → IN_TRIAGE → ASSIGNED → IN_DEVELOPMENT → FIX_SUBMITTED
→ PR_REVIEW → CI_PENDING → CI_PASSED → DEPLOYED → READY_FOR_RETEST → QA_RETEST
```

QA FAIL records a new retest, moves the bug to `REOPENED`, increments the reopen count, and creates audit entries and notifications. Engineering work then repeats. QA PASS records another retest and closes the bug. Deployments, retests, status transitions, and history are append-only records.

## Data and features

- Django models cover users, roles, permissions, projects, bugs, assignments, engineering cycles, deployment history, retests, status transitions, audit history, comments, attachments, and notifications.
- Dashboard KPIs, distributions, trends, workload, and project summaries come from database-backed API aggregations.
- Bug lists support search, filtering, ordering, and pagination.
- Attachments have extension, MIME, size, and selected file-signature checks; downloads require authentication and bug access.
- Notifications are stored in the database and can be marked read individually or in bulk.
- Branch, commit, PR, CI, and deployment data are tracked as workflow records and links. MVP does not call GitHub, CI providers, or deployment systems automatically.
- File uploads use the configured media storage. Compose persists uploaded files in the `portal_media` volume.

## API and OpenAPI

Base path: `/api/`

- Health: `/health/`
- Auth: `/auth/login/`, `/auth/logout/`, `/auth/token/refresh/`
- Bugs: `/bugs/` with controlled actions for triage, assign/reassign, start work, engineering, fix, PR, CI, deployment, retest readiness, retests, comments, attachments, history, and reopen
- Projects and users: `/projects/`, `/users/`
- Notifications: `/notifications/`
- Role dashboards: `/dashboard/manager/`, `/dashboard/qa/`, `/dashboard/tech-lead/`, `/dashboard/developer/`
- OpenAPI schema: `/api/schema/`
- Swagger UI: `/api/docs/`

Use the Swagger UI or schema to see request fields and response formats.

## Database and migrations

```powershell
python manage.py makemigrations --check --dry-run
python manage.py migrate
python manage.py seed_demo
```

The seed command is idempotent for existing users and keeps an existing demo password. To reset the demo data during local development, delete the SQLite file and rerun migrations and seed. Do not use demo-reset steps against real data.

## Testing and code quality

Run the API, RBAC, and complete two-cycle FAIL → reopen → PASS workflow tests:

```powershell
$env:DATABASE_URL = "sqlite:///:memory:"
$env:DJANGO_SECRET_KEY = "test-only-secret-key-that-is-long-enough"
python -m pytest -q
```

The browser tests are skipped unless the frontend and API are already running. Install the browser once with `python -m playwright install chromium`. For both the login smoke test and the full QA → developer → FAIL/reopen → second fix → PASS lifecycle, set the browser environment and run:

```powershell
$env:PLAYWRIGHT_BASE_URL = "http://127.0.0.1:8501"
$env:PLAYWRIGHT_API_BASE_URL = "http://127.0.0.1:8000/api"
$env:PLAYWRIGHT_USERNAME = "qa"
$env:PLAYWRIGHT_PASSWORD = "your-local-demo-password"
python -m pytest -q backend/portal/tests/test_frontend_smoke.py backend/portal/tests/test_playwright_workflow.py
```

Quality and schema checks:

```powershell
ruff check backend frontend
black --check backend frontend manage.py
python manage.py check
python manage.py makemigrations --check --dry-run
docker compose config --quiet
```

GitHub Actions runs PostgreSQL migrations and workflow tests, starts both services for a Playwright login/dashboard check, and runs Ruff, Black, and Compose syntax validation on pushes and pull requests.

## Deployment notes

Compose is configured for local/demo use. Before production, use managed secrets, `DJANGO_DEBUG=0`, a restricted `DJANGO_ALLOWED_HOSTS`, TLS/reverse proxy configuration, hardened cookie/security settings, backed-up PostgreSQL and media storage, and a reviewed account/password policy. The app does not currently automate external PR, CI, or deployment integrations.

## Human acceptance checklist

1. Sign in as `qa`; report a bug and verify it appears in the database-backed list/dashboard.
2. Triage and assign it to a developer. Sign in as that developer and record engineering notes, PR, CI, and deployment.
3. Mark it ready for retest; sign in as QA and record FAIL. Confirm it reopens and a notification/history entry is created.
4. Repeat the engineering/deployment path and record PASS. Confirm the bug closes and both retest records remain visible.
5. Try the retest API as Tech Lead and Developer and confirm the backend rejects the operation.


## Core workflow: Issue first, official bug second

1. **Anyone can report an Issue** — Manager, QA, Tech Lead, or Developer.
2. The submission is stored as `ISSUE-XXXX` with status **Awaiting QA verification**. It is not an official bug.
3. **QA reviews the issue.**
   - **Reject / Not a Bug** keeps it out of the bug lifecycle.
   - **Verify & Create Official Bug** creates `BUG-XXXX`.
4. When the official bug is created, QA records the verifier and selects:
   - **Tech Lead** — technical owner/supervisor.
   - **Developer** — implementation owner.
5. The bug then follows:
   `NEW → IN TRIAGE → ASSIGNED → IN DEVELOPMENT → FIX SUBMITTED → PR REVIEW → CI → DEPLOYED → READY FOR RETEST → QA RETEST`.
6. QA **PASS** closes the bug. QA **FAIL** reopens it for another development cycle.
7. Every important action remains in **Bug History**. Retest records are never overwritten.
8. **My Reported Issues** shows each user's submissions and whether QA has converted them.
9. **Bugs Assigned to Me** is role-aware:
   - Tech Lead: bugs where the user is the technical lead.
   - Developer: bugs where the user is the assigned developer.
10. Manager has full workflow access. Tech Lead and Developer cannot perform QA retest/PASS/FAIL. QA can enter Developer Mode when needed, and the audit records the real QA identity and mode.
