from django.urls import include, path
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from .api import (
    BugViewSet,
    DashboardView,
    HealthView,
    LoginView,
    LogoutView,
    NotificationViewSet,
    ProjectViewSet,
    ReportedIssueViewSet,
    UserViewSet,
)

router = DefaultRouter()
router.register("users", UserViewSet, basename="user")
router.register("projects", ProjectViewSet, basename="project")
router.register("reported-issues", ReportedIssueViewSet, basename="reported-issue")
router.register("bugs", BugViewSet, basename="bug")
router.register("notifications", NotificationViewSet, basename="notification")

urlpatterns = [
    path("health/", HealthView.as_view(), name="health"),
    path("auth/login/", LoginView.as_view(), name="login"),
    path("auth/logout/", LogoutView.as_view(), name="logout"),
    path("auth/token/refresh/", TokenRefreshView.as_view(), name="token-refresh"),
    path("dashboard/<str:kind>/", DashboardView.as_view(), name="dashboard"),
    path("", include(router.urls)),
]
