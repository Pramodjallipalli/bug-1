from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from .models import (
    Bug,
    BugAssignment,
    BugComment,
    BugDeploymentHistory,
    BugEngineering,
    BugHistory,
    BugRetest,
    BugStatusTransition,
    Notification,
    ReportedIssue,
    User,
)
from .permissions import performed_mode, require_capability

TRANSITIONS = {
    Bug.Status.NEW: {Bug.Status.IN_TRIAGE, Bug.Status.INVALID},
    Bug.Status.IN_TRIAGE: {Bug.Status.ASSIGNED, Bug.Status.INVALID},
    Bug.Status.ASSIGNED: {Bug.Status.IN_DEVELOPMENT, Bug.Status.IN_TRIAGE},
    Bug.Status.IN_DEVELOPMENT: {Bug.Status.FIX_SUBMITTED},
    Bug.Status.FIX_SUBMITTED: {Bug.Status.PR_REVIEW, Bug.Status.IN_DEVELOPMENT},
    Bug.Status.PR_REVIEW: {Bug.Status.CI_PENDING, Bug.Status.IN_DEVELOPMENT},
    Bug.Status.CI_PENDING: {Bug.Status.CI_PASSED, Bug.Status.IN_DEVELOPMENT},
    Bug.Status.CI_PASSED: {Bug.Status.DEPLOYED},
    Bug.Status.DEPLOYED: {Bug.Status.READY_FOR_RETEST},
    Bug.Status.READY_FOR_RETEST: {Bug.Status.QA_RETEST},
    Bug.Status.QA_RETEST: {Bug.Status.CLOSED, Bug.Status.REOPENED},
    Bug.Status.REOPENED: {Bug.Status.IN_DEVELOPMENT},
    Bug.Status.CLOSED: {Bug.Status.REOPENED},
    Bug.Status.INVALID: set(),
}


def _mode(request):
    return performed_mode(request)


def audit(bug, request, action, *, field_name="", old_value="", new_value="", notes=""):
    BugHistory.objects.create(
        bug=bug,
        user=request.user,
        action=action,
        field_name=field_name,
        old_value=str(old_value or ""),
        new_value=str(new_value or ""),
        performed_role=request.user.role_code,
        performed_mode=_mode(request),
        notes=notes,
    )


def notify_users(users, bug, title, body, kind):
    unique_ids = {user.pk for user in users if user and user.is_active}
    if unique_ids:
        Notification.objects.bulk_create(
            [
                Notification(user_id=user_id, bug=bug, title=title, body=body, kind=kind)
                for user_id in unique_ids
            ]
        )


def notify_roles(role_codes, bug, title, body, kind):
    users = User.objects.filter(is_active=True, roles__code__in=role_codes).distinct()
    notify_users(users, bug, title, body, kind)


def transition(bug, request, new_status, note=""):
    old_status = bug.status
    if new_status not in TRANSITIONS.get(old_status, set()):
        raise ValidationError({"status": f"Cannot move a bug from {old_status} to {new_status}."})
    bug.status = new_status
    bug.save(update_fields=("status", "updated_at"))
    BugStatusTransition.objects.create(
        bug=bug, from_status=old_status, to_status=new_status, actor=request.user, note=note
    )
    audit(
        bug,
        request,
        f"Status changed: {old_status} → {new_status}",
        field_name="status",
        old_value=old_status,
        new_value=new_status,
        notes=note,
    )


@transaction.atomic
def triage_bug(bug, request, note=""):
    require_capability(request.user, "BUG_TRIAGE")
    if bug.status != Bug.Status.NEW:
        raise ValidationError({"status": "Only new bugs can be triaged."})
    bug.triaged_by = request.user
    bug.save(update_fields=("triaged_by", "updated_at"))
    transition(bug, request, Bug.Status.IN_TRIAGE, note)
    notify_roles(
        ("TECH_LEAD", "MANAGER"),
        bug,
        f"{bug.bug_key} is ready for assignment",
        bug.title,
        "TRIAGED",
    )
    return bug


@transaction.atomic
def assign_bug(bug, request, assignee, note="", reassign=False):
    capability = "BUG_REASSIGN" if reassign else "BUG_ASSIGN"
    require_capability(request.user, capability)
    if assignee is None or not assignee.is_active or not assignee.has_capability("BUG_DEVELOP"):
        raise ValidationError({"assignee": "Choose an active user with Developer permissions."})
    if bug.status not in (Bug.Status.IN_TRIAGE, Bug.Status.ASSIGNED):
        raise ValidationError({"status": "Triage the bug before assigning or reassigning it."})
    if bug.status == Bug.Status.ASSIGNED and not reassign:
        raise ValidationError({"status": "This bug already has an assignee. Use reassignment."})
    old_assignee = bug.assigned_to
    if old_assignee and old_assignee.pk == assignee.pk:
        raise ValidationError({"assignee": "Choose a different developer for reassignment."})
    BugAssignment.objects.create(
        bug=bug,
        assigned_to=assignee,
        assigned_by=request.user,
        note=note,
        is_reassignment=bool(old_assignee),
    )
    bug.assigned_to = assignee
    bug.save(update_fields=("assigned_to", "updated_at"))
    if bug.status != Bug.Status.ASSIGNED:
        transition(bug, request, Bug.Status.ASSIGNED, note)
    else:
        audit(
            bug,
            request,
            f"Bug reassigned to {assignee.get_full_name() or assignee.username}",
            field_name="assigned_to",
            old_value=old_assignee.username if old_assignee else "",
            new_value=assignee.username,
            notes=note,
        )
    notify_users([assignee], bug, f"{bug.bug_key} assigned to you", bug.title, "ASSIGNED")
    if old_assignee:
        notify_users(
            [old_assignee],
            bug,
            f"{bug.bug_key} reassigned",
            f"It is now assigned to {assignee.get_full_name() or assignee.username}.",
            "REASSIGNED",
        )
    return bug


def _check_owner(bug, request):
    user = request.user
    qa_developer_mode = (
        user.role_code == "QA" and request.headers.get("X-Work-Mode", "").upper() == "DEVELOPER"
    )
    if (
        bug.assigned_to_id != user.pk
        and user.role_code not in ("MANAGER", "TECH_LEAD")
        and not qa_developer_mode
        and not user.is_superuser
    ):
        from rest_framework.exceptions import PermissionDenied

        raise PermissionDenied("This bug is assigned to another developer.")


@transaction.atomic
def start_work(bug, request):
    require_capability(request.user, "BUG_DEVELOP")
    _check_owner(bug, request)
    if bug.status not in (Bug.Status.ASSIGNED, Bug.Status.REOPENED):
        raise ValidationError({"status": "Start work is available for assigned or reopened bugs."})
    bug.development_cycle += 1
    bug.is_reopened = bug.reopen_count > 0
    bug.save(update_fields=("development_cycle", "is_reopened", "updated_at"))
    transition(
        bug,
        request,
        Bug.Status.IN_DEVELOPMENT,
        f"Development cycle {bug.development_cycle} started",
    )
    BugEngineering.objects.create(bug=bug, cycle=bug.development_cycle, developer=request.user)
    notify_roles(
        ("TECH_LEAD",), bug, f"{bug.bug_key} moved to development", bug.title, "IN_DEVELOPMENT"
    )
    return bug


@transaction.atomic
def update_engineering(bug, request, data):
    require_capability(request.user, "BUG_DEVELOP")
    _check_owner(bug, request)
    if bug.status not in (
        Bug.Status.IN_DEVELOPMENT,
        Bug.Status.FIX_SUBMITTED,
        Bug.Status.PR_REVIEW,
        Bug.Status.CI_PENDING,
    ):
        raise ValidationError(
            {"status": "Engineering details can be updated during an active development cycle."}
        )
    engineering, _ = BugEngineering.objects.get_or_create(
        bug=bug, cycle=max(1, bug.development_cycle), defaults={"developer": request.user}
    )
    for field in ("branch_name", "commit_reference", "fix_notes", "pull_request_url", "ci_link"):
        if field in data:
            old = getattr(engineering, field)
            value = data[field]
            if old != value:
                setattr(engineering, field, value)
                audit(
                    bug,
                    request,
                    f"Updated {field.replace('_', ' ')}",
                    field_name=field,
                    old_value=old,
                    new_value=value,
                )
    engineering.updated_at = timezone.now()
    engineering.save()
    return engineering


@transaction.atomic
def submit_fix(bug, request, notes=""):
    require_capability(request.user, "BUG_FIX")
    _check_owner(bug, request)
    if bug.status != Bug.Status.IN_DEVELOPMENT:
        raise ValidationError({"status": "Only bugs in development can submit a fix."})
    engineering = bug.engineering_cycles.filter(cycle=bug.development_cycle).first()
    if engineering is None or not (notes.strip() or engineering.fix_notes.strip()):
        raise ValidationError({"fix_notes": "Add fix notes before submitting the fix."})
    if notes.strip():
        engineering.fix_notes = notes.strip()
    engineering.fixed_at = timezone.now()
    engineering.save(update_fields=("fix_notes", "fixed_at", "updated_at"))
    transition(bug, request, Bug.Status.FIX_SUBMITTED, notes)
    notify_roles(
        ("TECH_LEAD",), bug, f"Fix submitted for {bug.bug_key}", bug.title, "FIX_SUBMITTED"
    )
    return bug


@transaction.atomic
def update_pull_request(bug, request, data):
    require_capability(request.user, "BUG_PR")
    _check_owner(bug, request)
    if bug.status not in (Bug.Status.FIX_SUBMITTED, Bug.Status.PR_REVIEW):
        raise ValidationError({"status": "Submit a fix before recording its pull request."})
    engineering = bug.engineering_cycles.filter(cycle=bug.development_cycle).first()
    if engineering is None:
        raise ValidationError({"engineering": "Start a development cycle first."})
    old_pr = engineering.pr_status
    engineering.pull_request_url = data.get("pull_request_url", engineering.pull_request_url)
    engineering.pr_status = data["pr_status"]
    engineering.save(update_fields=("pull_request_url", "pr_status", "updated_at"))
    audit(
        bug,
        request,
        "Updated pull request",
        field_name="pr_status",
        old_value=old_pr,
        new_value=engineering.pr_status,
        notes=engineering.pull_request_url,
    )
    if bug.status == Bug.Status.FIX_SUBMITTED:
        transition(bug, request, Bug.Status.PR_REVIEW, engineering.pull_request_url)
    if (
        engineering.pr_status == BugEngineering.PRStatus.MERGED
        and bug.status == Bug.Status.PR_REVIEW
    ):
        transition(bug, request, Bug.Status.CI_PENDING, "Pull request merged; CI can be recorded")
    elif (
        engineering.pr_status == BugEngineering.PRStatus.CHANGES_REQUESTED
        and bug.status == Bug.Status.PR_REVIEW
    ):
        transition(bug, request, Bug.Status.IN_DEVELOPMENT, "Pull request changes requested")
    notify_roles(
        ("TECH_LEAD",), bug, f"PR updated for {bug.bug_key}", engineering.pr_status, "PR_UPDATED"
    )
    return engineering


@transaction.atomic
def record_ci(bug, request, data):
    require_capability(request.user, "BUG_CI")
    _check_owner(bug, request)
    if bug.status != Bug.Status.CI_PENDING:
        raise ValidationError({"status": "A merged pull request is required before recording CI."})
    engineering = bug.engineering_cycles.filter(cycle=bug.development_cycle).first()
    if engineering is None or engineering.pr_status != BugEngineering.PRStatus.MERGED:
        raise ValidationError({"pr_status": "Merge the pull request before CI can pass."})
    old_ci = engineering.ci_status
    result = data["ci_status"]
    engineering.ci_status = result
    engineering.ci_link = data.get("ci_link", engineering.ci_link)
    engineering.save(update_fields=("ci_status", "ci_link", "updated_at"))
    audit(
        bug,
        request,
        f"CI {result.lower()}",
        field_name="ci_status",
        old_value=old_ci,
        new_value=result,
        notes=engineering.ci_link,
    )
    if result == BugEngineering.CIStatus.PASSED:
        transition(bug, request, Bug.Status.CI_PASSED, engineering.ci_link)
    else:
        transition(bug, request, Bug.Status.IN_DEVELOPMENT, "CI failed; return to development")
    notify_roles(
        ("TECH_LEAD",), bug, f"CI {result.lower()} for {bug.bug_key}", bug.title, "CI_COMPLETED"
    )
    return engineering


@transaction.atomic
def record_deployment(bug, request, data):
    require_capability(request.user, "BUG_DEPLOY")
    _check_owner(bug, request)
    if bug.status != Bug.Status.CI_PASSED:
        raise ValidationError({"status": "A passing CI result is required before deployment."})
    deployment = BugDeploymentHistory.objects.create(
        bug=bug,
        cycle=bug.development_cycle,
        environment=data["environment"],
        version=data.get("version", ""),
        deployed_by=request.user,
        deployment_link=data.get("deployment_link", ""),
        notes=data.get("notes", ""),
    )
    transition(
        bug,
        request,
        Bug.Status.DEPLOYED,
        f"{deployment.environment} · {deployment.version}".strip(" ·"),
    )
    notify_roles(
        ("QA",),
        bug,
        f"{bug.bug_key} deployed",
        f"{deployment.environment} {deployment.version}".strip(),
        "DEPLOYED",
    )
    return deployment


@transaction.atomic
def mark_ready_for_retest(bug, request, note=""):
    require_capability(request.user, "BUG_DEPLOY")
    if bug.status != Bug.Status.DEPLOYED:
        raise ValidationError({"status": "Record a deployment before requesting QA retest."})
    transition(bug, request, Bug.Status.READY_FOR_RETEST, note)
    notify_roles(("QA",), bug, f"{bug.bug_key} is ready for retest", bug.title, "READY_FOR_RETEST")
    return bug


@transaction.atomic
def create_retest(bug, request, data):
    require_capability(request.user, "BUG_RETEST")
    require_capability(
        request.user, "BUG_PASS" if data["test_result"] == BugRetest.Result.PASS else "BUG_FAIL"
    )
    if data["test_result"] == BugRetest.Result.PASS:
        require_capability(request.user, "BUG_CLOSE")
    if bug.status != Bug.Status.READY_FOR_RETEST:
        raise ValidationError({"status": "This bug is not ready for retest."})
    retest = BugRetest.objects.create(
        bug=bug,
        cycle=bug.development_cycle,
        retested_by=request.user,
        test_environment=data["test_environment"],
        test_version=data["test_version"],
        test_steps=data["test_steps"],
        expected_result=data["expected_result"],
        actual_result=data["actual_result"],
        test_result=data["test_result"],
        remarks=data.get("remarks", ""),
    )
    transition(
        bug, request, Bug.Status.QA_RETEST, f"Retest cycle {retest.cycle}: {retest.test_result}"
    )
    if retest.test_result == BugRetest.Result.FAIL:
        bug.reopen_count += 1
        bug.is_reopened = True
        bug.save(update_fields=("reopen_count", "is_reopened", "updated_at"))
        transition(bug, request, Bug.Status.REOPENED, retest.remarks)
        notify_users(
            [bug.assigned_to],
            bug,
            f"{bug.bug_key} failed QA and was reopened",
            retest.remarks or bug.title,
            "QA_FAIL",
        )
        notify_roles(
            ("TECH_LEAD",), bug, f"{bug.bug_key} reopened", retest.remarks or bug.title, "REOPENED"
        )
    else:
        bug.closed_at = timezone.now()
        bug.save(update_fields=("closed_at", "updated_at"))
        transition(bug, request, Bug.Status.CLOSED, retest.remarks or "QA passed")
        notify_users(
            [bug.reported_by, bug.assigned_to],
            bug,
            f"{bug.bug_key} passed QA and is closed",
            retest.remarks,
            "CLOSED",
        )
    return retest


@transaction.atomic
def reopen_bug(bug, request, note=""):
    require_capability(request.user, "BUG_REOPEN")
    if bug.status != Bug.Status.CLOSED:
        raise ValidationError({"status": "Only a closed bug can be manually reopened."})
    bug.reopen_count += 1
    bug.is_reopened = True
    bug.closed_at = None
    bug.save(update_fields=("reopen_count", "is_reopened", "closed_at", "updated_at"))
    transition(bug, request, Bug.Status.REOPENED, note)
    notify_users(
        [bug.assigned_to], bug, f"{bug.bug_key} was reopened", note or bug.title, "REOPENED"
    )
    return bug




@transaction.atomic
def reject_reported_issue(issue, request, note=""):
    if request.user.role_code not in ("QA", "MANAGER") and not request.user.is_superuser:
        from rest_framework.exceptions import PermissionDenied
        raise PermissionDenied("Only QA can verify reported issues. Manager has full access.")
    if issue.status != ReportedIssue.Status.AWAITING_QA:
        raise ValidationError({"status": "This issue has already been reviewed."})
    issue.status = ReportedIssue.Status.REJECTED
    issue.reviewed_by = request.user
    issue.review_note = note
    issue.save(update_fields=("status", "reviewed_by", "review_note", "updated_at"))
    return issue

@transaction.atomic
def convert_issue_to_bug(issue, request, tech_lead, developer, note=""):
    if request.user.role_code not in ("QA", "MANAGER") and not request.user.is_superuser:
        from rest_framework.exceptions import PermissionDenied
        raise PermissionDenied("Only QA can verify and create an official bug. Manager has full access.")
    if issue.status != ReportedIssue.Status.AWAITING_QA:
        raise ValidationError({"status": "Only issues awaiting QA verification can become official bugs."})
    if not tech_lead or tech_lead.role_code != "TECH_LEAD":
        raise ValidationError({"tech_lead_id": "Select an active Tech Lead."})
    if not developer or developer.role_code != "DEVELOPER":
        raise ValidationError({"developer_id": "Select an active Developer."})
    bug = Bug.objects.create(
        project=issue.project,
        title=issue.title,
        description=issue.description,
        steps_to_reproduce=issue.steps_to_reproduce,
        expected_result=issue.expected_result,
        actual_result=issue.actual_result,
        severity=issue.severity,
        priority=issue.priority,
        status=Bug.Status.NEW,
        reported_by=issue.reported_by,
        verified_by=request.user,
        tech_lead=tech_lead,
        assigned_to=developer,
        environment=issue.environment,
        application_version=issue.application_version,
    )
    BugAssignment.objects.create(
        bug=bug, assigned_to=developer, assigned_by=request.user,
        note=f"Official bug created; Developer assigned. {note}".strip()
    )
    audit(bug, request, "Official bug created after QA verification", notes=note)
    audit(
        bug, request, "Tech Lead assigned",
        field_name="tech_lead", new_value=tech_lead.username,
    )
    audit(
        bug, request, "Developer assigned",
        field_name="assigned_to", new_value=developer.username,
    )
    issue.status = ReportedIssue.Status.CONVERTED
    issue.reviewed_by = request.user
    issue.review_note = note
    issue.converted_bug = bug
    issue.save(update_fields=("status", "reviewed_by", "review_note", "converted_bug", "updated_at"))
    notify_users(
        [tech_lead], bug, f"{bug.bug_key} assigned to you as Tech Lead", bug.title, "TECH_LEAD_ASSIGNED"
    )
    notify_users(
        [developer], bug, f"{bug.bug_key} assigned to you", bug.title, "DEVELOPER_ASSIGNED"
    )
    return bug

def add_comment(bug, request, text):
    require_capability(request.user, "BUG_VIEW")
    comment = BugComment.objects.create(bug=bug, user=request.user, comment=text)
    audit(bug, request, "Added a comment", notes=text[:300])
    notify_users(
        [bug.reported_by, bug.assigned_to],
        bug,
        f"New comment on {bug.bug_key}",
        text[:200],
        "COMMENT",
    )
    return comment
