import streamlit as st

import api_client
import ui


def render():
    user = api_client.current_user()
    ui.heading(
        "Report an Issue",
        "Anyone can report a suspected problem. QA verifies it before an official bug is created.",
        user.get("role_code"),
    )
    st.info(
        "This submission is an **Issue**, not an official bug yet. "
        "It enters the QA verification queue. QA will either reject it or convert it into an official bug."
    )
    try:
        projects = api_client.request("GET", "projects/").get("results", [])
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    active = [project for project in projects if project["is_active"]]
    if not active:
        st.warning("There are no active projects. Ask a manager to create a project first.")
        return

    with st.form("report-issue-form"):
        project_map = {f"{item['key']} · {item['name']}": item["id"] for item in active}
        project = st.selectbox("Project", list(project_map))
        title = st.text_input("Issue title", max_chars=180, placeholder="Short, specific summary")
        description = st.text_area("What went wrong?", height=100)
        left, right = st.columns(2)
        steps = left.text_area("Steps to reproduce", height=120)
        expected = right.text_area("Expected result", height=120)
        actual = st.text_area("Actual result", height=100)
        fields = st.columns(4)
        severity = fields[0].selectbox("Suspected severity", ["CRITICAL", "HIGH", "MEDIUM", "LOW"], index=2)
        priority = fields[1].selectbox("Suspected priority", ["P1", "P2", "P3", "P4"], index=2)
        environment = fields[2].text_input("Environment", placeholder="e.g. QA / Staging / Production")
        version = fields[3].text_input("Application version", placeholder="e.g. 2.8.1")
        submitted = st.form_submit_button("Submit Issue for QA Review", type="primary", width="stretch")

    if submitted:
        body = {
            "project": project_map[project],
            "title": title,
            "description": description,
            "steps_to_reproduce": steps,
            "expected_result": expected,
            "actual_result": actual,
            "severity": severity,
            "priority": priority,
            "environment": environment,
            "application_version": version,
        }
        try:
            result = api_client.request("POST", "reported-issues/", json=body)
            st.success(f"{result['issue_key']} submitted to QA for verification.")
        except api_client.APIError as exc:
            ui.friendly_error(exc)


render()
