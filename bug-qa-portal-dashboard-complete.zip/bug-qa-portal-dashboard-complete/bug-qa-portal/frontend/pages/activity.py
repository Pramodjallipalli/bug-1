import streamlit as st

import api_client
import ui


def render():
    user = api_client.current_user()
    role = user.get("role_code", "DEVELOPER")
    kind = {"MANAGER":"manager", "QA":"qa", "TECH_LEAD":"tech-lead", "DEVELOPER":"developer"}.get(role, "developer")
    ui.heading("Activity", "A read-only timeline of bug workflow activity visible to your role.", role)
    try:
        data = api_client.request("GET", f"dashboard/{kind}/")
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    items = data.get("recent_activity", [])
    if not items:
        st.info("No activity yet.")
        return
    for item in items:
        with st.container(border=True):
            st.markdown(
                f'**{item["bug_key"]} · {item["title"]}**  \n'
                f'{item["user"]} — {item["action"]}  \n'
                f'<small>{item["created_at"][:16].replace("T", " ")} UTC</small>',
                unsafe_allow_html=True,
            )


render()
