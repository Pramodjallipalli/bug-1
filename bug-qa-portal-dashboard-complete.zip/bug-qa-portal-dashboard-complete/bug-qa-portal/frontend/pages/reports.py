import csv
import io

import streamlit as st

import api_client
import ui


def render():
    role = api_client.current_user().get("role_code")
    ui.heading("Reports & Analytics", "Export live issue data and review quality metrics.", role)
    try:
        dashboard_name = {
            "MANAGER": "manager",
            "QA": "qa",
            "TECH_LEAD": "tech-lead",
            "DEVELOPER": "developer",
        }.get(role, "developer")
        data = api_client.request("GET", f"dashboard/{dashboard_name}/")
        bugs = api_client.request("GET", "bugs/", params={"page_size": 100})
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    kpis = data["kpis"]
    cols = st.columns(4)
    cols[0].metric("Open Bugs", kpis["open_bugs"])
    cols[1].metric("Verification Rate", f"{kpis['verification_rate']}%")
    cols[2].metric("Failed Retests", kpis["failed_retests"])
    cols[3].metric("Aging > 7d", kpis["aging_bugs"])
    rows = bugs.get("results", [])
    buffer = io.StringIO()
    writer = csv.DictWriter(
        buffer,
        fieldnames=(
            "bug_key",
            "title",
            "project_key",
            "status",
            "severity",
            "priority",
            "reported_by",
            "assigned_to",
            "created_at",
            "updated_at",
        ),
    )
    writer.writeheader()
    for item in rows:
        writer.writerow(
            {
                "bug_key": item["bug_key"],
                "title": item["title"],
                "project_key": item["project_key"],
                "status": item["status"],
                "severity": item["severity"],
                "priority": item["priority"],
                "reported_by": item["reported_by"]["username"],
                "assigned_to": item["assigned_to"]["username"] if item.get("assigned_to") else "",
                "created_at": item["created_at"],
                "updated_at": item["updated_at"],
            }
        )
    st.download_button(
        "Export visible bugs as CSV",
        buffer.getvalue(),
        file_name="bugtracker-bugs.csv",
        mime="text/csv",
    )
    st.dataframe(
        [
            {
                "Bug": item["bug_key"],
                "Title": item["title"],
                "Project": item["project_name"],
                "Status": item["status"],
                "Severity": item["severity"],
                "Updated": item["updated_at"][:10],
            }
            for item in rows
        ],
        hide_index=True,
        width="stretch",
    )


render()
