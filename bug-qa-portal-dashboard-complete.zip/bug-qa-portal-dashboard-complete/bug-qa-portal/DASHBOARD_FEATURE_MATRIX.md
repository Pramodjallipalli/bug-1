# BugTracker Dashboard Feature Matrix

This standalone portal implements the workflow:

`Report Issue → QA Verification → Official Bug → Tech Lead → Developer → Development → PR → CI → Deployment → Ready for Retest → QA PASS/FAIL → Closed/Reopened`

## Access rule

- Everyone with `BUG_VIEW` can view the current status and read bug details/history.
- Everyone can report a suspected issue.
- Only QA (and Manager full-access) can verify a reported issue and create the official bug.
- QA verification requires a Tech Lead and Developer assignment.
- Tech Lead can perform technical/developer work but never QA retest/PASS/FAIL.
- Developer can perform development/PR/CI/deployment work but never QA retest/PASS/FAIL/close.
- QA PASS closes the bug; QA FAIL reopens it and preserves the retest/history cycle.
- QA Developer Mode and Tech Lead Developer Mode are recorded in history.

## Manager dashboard

- Total Projects
- Total Bugs
- Closed Bugs
- Team Members
- Open Bugs
- In Development
- Ready for Retest
- Reopened
- Critical Bugs
- Overdue/Aging Bugs
- Project Progress Overview
- Bugs by Status
- Bugs by Severity
- Bugs by Project
- Team Workload
- Bug Trend
- Action Required
- Recent Activity
- Overdue/Aging Bugs table
- Project Health
- All Visible Bugs + Current Status

## QA dashboard

- Bugs Reported by Me
- Assigned to Me (QA verifier)
- Ready for Retest
- Closed by Me
- Issues Awaiting Verification
- Reopened
- Verification Rate
- Average Retest Turnaround
- Critical Bugs
- High Priority Bugs
- My Bugs by Status
- Severity Distribution
- Retest Result Trend (PASS/FAIL)
- Bugs by Project
- Team Workload
- Bug Trend
- Action Required
- Ready for Retest action table
- Recently Reported Bugs
- Upcoming QA Deadlines
- Recent QA Activity
- Reported Issues Awaiting Verification
- All Visible Bugs + Current Status

## Tech Lead dashboard

- New Bugs
- Bugs Assigned to Me / Technical Ownership
- In Development
- Awaiting Retest
- Closed
- Awaiting PR
- CI Pending
- Reopened
- Critical Bugs
- Overdue/Aging Bugs
- Bugs by Status
- Bugs by Project
- Severity Distribution
- Pending Triage
- Team Workload
- Bug Trend
- Top Reopened Bugs
- Overdue/Aging Bugs
- Recent Technical Activity
- All Visible Bugs + Current Status

## Developer dashboard

- Assigned to Me
- In Progress
- Fix Submitted
- Deployed
- Closed
- PR/CI Work
- Ready for Retest
- Reopened
- Critical/High attention
- My Bugs by Status
- Severity Distribution
- PR Status
- CI Results
- Bugs by Project (Assigned to Me)
- My Assigned Bugs table
- My Upcoming Deadlines
- Recent Activity (Team)
- My Productivity
- Update Status / My Bugs action
- Fix / PR / CI / Deployment action
- All Visible Bugs + Current Status

## Common status visibility

The **All Visible Bugs · Current Status** section is present on every dashboard. The separate **All Bugs** page and **Bug Details** page also expose status/history. Status changes are still controlled by workflow permissions rather than by hiding the status.
