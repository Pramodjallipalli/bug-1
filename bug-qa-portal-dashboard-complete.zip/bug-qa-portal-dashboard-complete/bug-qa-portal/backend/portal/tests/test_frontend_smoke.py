import os

import pytest


@pytest.mark.skipif(
    not os.getenv("PLAYWRIGHT_BASE_URL"),
    reason="Set PLAYWRIGHT_BASE_URL when frontend and API are running.",
)
def test_browser_can_open_login_and_sign_in(page):
    base = os.environ["PLAYWRIGHT_BASE_URL"]
    page.goto(base, wait_until="domcontentloaded")
    page.get_by_text("Welcome to BugTracker").wait_for()
    page.get_by_label("Username").fill(os.environ["PLAYWRIGHT_USERNAME"])
    page.get_by_role("textbox", name="Password").fill(os.environ["PLAYWRIGHT_PASSWORD"])
    page.get_by_role("button", name="Sign in").click()
    page.get_by_role("heading", name="QA Dashboard").wait_for(timeout=15000)
    page.get_by_role("button", name="↪ Sign out").click()
    page.get_by_role("button", name="Sign in").wait_for(timeout=15000)
