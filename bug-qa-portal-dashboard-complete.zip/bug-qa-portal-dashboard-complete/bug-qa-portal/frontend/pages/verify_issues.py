import streamlit as st

import api_client
import ui


def render():
    user = api_client.current_user()
    ui.heading(
        "Verify Reported Issues",
        "QA is the gate between a reported issue and an official bug.",
        user.get("role_code"),
    )
    if user.get("role_code") not in {"QA", "MANAGER"}:
        st.error("Only QA can verify reported issues. Manager has full access.")
        return
    try:
        issues = api_client.request("GET", "reported-issues/?status=AWAITING_QA").get("results", [])
        users = api_client.request("GET", "users/").get("results", [])
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return

    tech_leads = [u for u in users if u.get("role_code") == "TECH_LEAD" and u.get("is_active")]
    developers = [u for u in users if u.get("role_code") == "DEVELOPER" and u.get("is_active")]

    if not issues:
        st.success("No reported issues are waiting for QA verification.")
        return
    st.caption(f"{len(issues)} issue(s) awaiting verification.")
    for issue in issues:
        with st.expander(f"{issue['issue_key']} · {issue['title']}", expanded=False):
            st.markdown(
                f"**Reporter:** {issue['reported_by']['full_name']} · "
                f"**Project:** {issue['project_key']} · **Severity:** {issue['severity']} · "
                f"**Priority:** {issue['priority']}"
            )
            st.write(issue["description"])
            left, right = st.columns(2)
            left.write(f"**Steps:** {issue.get('steps_to_reproduce') or '—'}")
            right.write(f"**Expected:** {issue.get('expected_result') or '—'}")
            st.write(f"**Actual:** {issue.get('actual_result') or '—'}")
            st.caption(
                "Confirming creates the official bug and records you as the QA verifier. "
                "The selected Tech Lead and Developer become the technical owners."
            )
            tech_map = {
                f"{u.get('full_name') or u['username']}": u["id"] for u in tech_leads
            }
            dev_map = {
                f"{u.get('full_name') or u['username']}": u["id"] for u in developers
            }
            if not tech_map or not dev_map:
                st.warning("An active Tech Lead and Developer are required before this issue can become an official bug.")
                continue
            with st.form(f"review-{issue['id']}"):
                tech = st.selectbox("Tech Lead", list(tech_map), key=f"tl-{issue['id']}")
                dev = st.selectbox("Developer", list(dev_map), key=f"dev-{issue['id']}")
                note = st.text_area("QA verification note", key=f"note-{issue['id']}")
                c1, c2 = st.columns(2)
                confirm = c1.form_submit_button("✓ Verify & Create Official Bug", type="primary")
                reject = c2.form_submit_button("✕ Reject / Not a Bug")
            if confirm:
                try:
                    bug = api_client.request(
                        "POST",
                        f"reported-issues/{issue['id']}/review/",
                        json={"tech_lead_id": tech_map[tech], "developer_id": dev_map[dev], "note": note},
                    )
                    st.success(
                        f"{bug['bug_key']} created. Tech Lead: {bug['tech_lead']['full_name']} · "
                        f"Developer: {bug['assigned_to']['full_name']}"
                    )
                    st.session_state["selected_bug_id"] = bug["id"]
                    st.page_link("pages/bug_details.py", label=f"Open {bug['bug_key']}", icon="🔎")
                    st.rerun()
                except api_client.APIError as exc:
                    ui.friendly_error(exc)
            if reject:
                try:
                    api_client.request(
                        "POST",
                        f"reported-issues/{issue['id']}/reject/",
                        json={"note": note},
                    )
                    st.success(f"{issue['issue_key']} marked as rejected / not a bug.")
                    st.rerun()
                except api_client.APIError as exc:
                    ui.friendly_error(exc)


render()
