from bug_list import render_bug_list


def render():
    render_bug_list(
        "Retest & Verify",
        "Verify deployed fixes. PASS closes; FAIL reopens the same bug.",
        forced_status="READY_FOR_RETEST",
    )


render()
