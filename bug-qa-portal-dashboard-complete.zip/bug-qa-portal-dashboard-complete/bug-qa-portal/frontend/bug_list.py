from datetime import date

import streamlit as st

import api_client
import ui


def render_bug_list(
    title="Bugs",
    subtitle="Search, filter, and follow every issue through QA verification.",
    forced_status=None,
):
    role = api_client.current_user().get("role_code", "DEVELOPER")
    ui.heading(title, subtitle, role)
    try:
        projects_data = api_client.request("GET", "projects/", params={"page_size": 100})
        users_data = api_client.request("GET", "users/", params={"page_size": 100})
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    projects = projects_data.get("results", [])
    users = users_data.get("results", [])
    project_options = {"All projects": ""}
    project_options.update({f"{item['key']} · {item['name']}": item["id"] for item in projects})
    user_options = {"Anyone": ""}
    user_options.update({item.get("full_name") or item["username"]: item["id"] for item in users})

    with st.form("bug-search-form"):
        search = st.text_input("Search bugs", placeholder="Bug key, title, or description")
        filter_cols = st.columns(4)
        selected_project = filter_cols[0].selectbox("Project", list(project_options))
        statuses = [
            "All statuses",
            "NEW",
            "IN_TRIAGE",
            "ASSIGNED",
            "IN_DEVELOPMENT",
            "FIX_SUBMITTED",
            "PR_REVIEW",
            "CI_PENDING",
            "CI_PASSED",
            "DEPLOYED",
            "READY_FOR_RETEST",
            "REOPENED",
            "CLOSED",
            "INVALID",
        ]
        status_default = forced_status if forced_status in statuses else "All statuses"
        selected_status = filter_cols[1].selectbox(
            "Status", statuses, index=statuses.index(status_default)
        )
        selected_severity = filter_cols[2].selectbox(
            "Severity", ["All severities", "CRITICAL", "HIGH", "MEDIUM", "LOW"]
        )
        selected_priority = filter_cols[3].selectbox(
            "Priority", ["All priorities", "P1", "P2", "P3", "P4"]
        )
        second = st.columns(4)
        selected_assignee = second[0].selectbox("Assigned to", list(user_options))
        selected_reporter = second[1].selectbox("Reported by", list(user_options))
        environment = second[2].text_input("Environment", placeholder="e.g. Staging")
        sort_by = second[3].selectbox(
            "Sort", ["Recently updated", "Newest", "Oldest", "Severity", "Priority", "Aging"]
        )
        dates = st.columns(3)
        start_date = dates[0].date_input("Created after", value=None)
        end_date = dates[1].date_input("Created before", value=None)
        reopened_only = dates[2].checkbox("Reopened only")
        submitted = st.form_submit_button("Apply filters", type="primary")
    # Filters remain stable across reruns; the form applies them only after the user submits.
    if submitted:
        st.session_state["bug_page"] = 1
    if "bug_list_filters" not in st.session_state or submitted:
        st.session_state.bug_list_filters = {
            "search": search,
            "project": project_options[selected_project],
            "status": selected_status,
            "severity": selected_severity,
            "priority": selected_priority,
            "assigned_to": user_options[selected_assignee],
            "reported_by": user_options[selected_reporter],
            "environment": environment,
            "ordering": {
                "Recently updated": "-updated_at",
                "Newest": "-created_at",
                "Oldest": "created_at",
                "Severity": "severity",
                "Priority": "priority",
                "Aging": "created_at",
            }[sort_by],
            "created_after": start_date.isoformat() if isinstance(start_date, date) else "",
            "created_before": end_date.isoformat() if isinstance(end_date, date) else "",
            "is_reopened": reopened_only,
        }
    filters = st.session_state.bug_list_filters.copy()
    if forced_status and not submitted:
        filters["status"] = forced_status
    params = {key: value for key, value in filters.items() if value not in ("", None, False)}
    page_number = st.session_state.get("bug_page", 1)
    params["page"] = page_number
    if params.get("status") in ("All statuses", None):
        params.pop("status", None)
    if params.get("severity") == "All severities":
        params.pop("severity", None)
    if params.get("priority") == "All priorities":
        params.pop("priority", None)
    try:
        with st.spinner("Loading bugs…"):
            result = api_client.request("GET", "bugs/", params=params)
    except api_client.APIError as exc:
        ui.friendly_error(exc)
        return
    rows = result.get("results", [])
    st.caption(f"{result.get('count', len(rows))} bugs · page {page_number}")
    if not rows:
        st.info("No bugs match these filters. Clear a filter or report a new bug.")
        return
    st.markdown('<div class="panel">', unsafe_allow_html=True)
    header = st.columns([0.11, 0.33, 0.14, 0.13, 0.16, 0.13])
    for col, label in zip(
        header, ("ID", "Title", "Project", "Severity", "Status", "Updated"), strict=False
    ):
        col.markdown(f"**{label}**")
    for bug in rows:
        cols = st.columns([0.11, 0.33, 0.14, 0.13, 0.16, 0.13])
        cols[0].markdown(f"`{bug['bug_key']}`")
        if cols[1].button(bug["title"], key=f"open-bug-{bug['id']}", help="Open bug details"):
            st.session_state["selected_bug_id"] = bug["id"]
            st.switch_page("pages/bug_details.py")
        cols[2].write(bug["project_key"])
        cols[3].write(bug["severity"].title())
        cols[4].markdown(ui.status_chip(bug["status"]), unsafe_allow_html=True)
        cols[5].write(bug["updated_at"][:10])
    st.markdown("</div>", unsafe_allow_html=True)
    previous, page_label, following = st.columns([1, 2, 1])
    page_label.caption(f"Page {page_number} · {result.get('count', len(rows))} total")
    if page_number > 1 and previous.button("← Previous"):
        st.session_state["bug_page"] = page_number - 1
        st.rerun()
    if result.get("next") and following.button("Next →"):
        st.session_state["bug_page"] = page_number + 1
        st.rerun()
