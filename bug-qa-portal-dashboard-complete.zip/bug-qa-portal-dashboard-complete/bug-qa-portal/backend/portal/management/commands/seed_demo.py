import os
import secrets
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.db import transaction
from django.utils import timezone

from portal.models import (
    Bug,
    BugAssignment,
    BugDeploymentHistory,
    BugEngineering,
    BugHistory,
    BugRetest,
    BugStatusTransition,
    Notification,
    ReportedIssue,
    Permission,
    Project,
    Role,
    RolePermission,
    User,
)

PERMISSIONS = {
    "ISSUE_REPORT": "Report an issue for QA verification",
    "ISSUE_VIEW": "View reported issues",
    "ISSUE_REVIEW": "Verify or reject reported issues",
    "BUG_VIEW": "View permitted bugs",
    "BUG_CREATE": "Report bugs",
    "BUG_EDIT": "Edit permitted bug details",
    "BUG_TRIAGE": "Triage new bugs",
    "BUG_ASSIGN": "Assign bugs",
    "BUG_REASSIGN": "Reassign bugs",
    "BUG_DEVELOP": "Perform development work",
    "BUG_FIX": "Submit a fix",
    "BUG_PR": "Record pull request progress",
    "BUG_CI": "Record continuous integration results",
    "BUG_DEPLOY": "Record deployment and request retest",
    "BUG_RETEST": "Perform QA retests",
    "BUG_PASS": "Pass QA verification",
    "BUG_FAIL": "Fail QA verification",
    "BUG_CLOSE": "Close bugs after successful QA verification",
    "BUG_REOPEN": "Reopen closed bugs",
    "PROJECT_VIEW": "View projects",
    "PROJECT_MANAGE": "Manage projects",
    "USER_VIEW": "View team members",
    "USER_MANAGE": "Manage users and roles",
    "TEAM_MANAGE": "Manage development workload",
    "REPORT_VIEW": "View dashboards and analytics",
    "MANAGER_SUPERVISION": "Perform manager oversight actions",
}

ROLE_CAPABILITIES = {
    "MANAGER": set(PERMISSIONS),
    "QA": {
        "ISSUE_REPORT",
        "ISSUE_VIEW",
        "ISSUE_REVIEW",
        "BUG_VIEW",
        "BUG_EDIT",
        "BUG_TRIAGE",
        "BUG_ASSIGN",
        "BUG_REASSIGN",
        "BUG_DEVELOP",
        "BUG_FIX",
        "BUG_PR",
        "BUG_CI",
        "BUG_DEPLOY",
        "BUG_RETEST",
        "BUG_PASS",
        "BUG_FAIL",
        "BUG_CLOSE",
        "BUG_REOPEN",
        "PROJECT_VIEW",
        "REPORT_VIEW",
        "USER_VIEW",
    },
    "TECH_LEAD": {
        "ISSUE_REPORT",
        "ISSUE_VIEW",
        "BUG_VIEW",
        "BUG_EDIT",
        "BUG_TRIAGE",
        "BUG_ASSIGN",
        "BUG_REASSIGN",
        "BUG_DEVELOP",
        "BUG_FIX",
        "BUG_PR",
        "BUG_CI",
        "BUG_DEPLOY",
        "BUG_REOPEN",
        "PROJECT_VIEW",
        "TEAM_MANAGE",
        "REPORT_VIEW",
        "USER_VIEW",
    },
    "DEVELOPER": {
        "ISSUE_REPORT",
        "ISSUE_VIEW",
        "BUG_VIEW",
        "BUG_DEVELOP",
        "BUG_FIX",
        "BUG_PR",
        "BUG_CI",
        "BUG_DEPLOY",
        "PROJECT_VIEW",
        "REPORT_VIEW",
        "USER_VIEW",
    },
}

USERS = [
    ("manager", "Suresh", "Kumar", "MANAGER"),
    ("qa", "Ananya", "Shah", "QA"),
    ("techlead", "Rahul", "Verma", "TECH_LEAD"),
    ("rahul", "Rahul", "Mehta", "DEVELOPER"),
    ("karan", "Karan", "Patel", "DEVELOPER"),
    ("sneha", "Sneha", "Rao", "DEVELOPER"),
    ("vikram", "Vikram", "Das", "DEVELOPER"),
    ("ayush", "Ayush", "Nair", "DEVELOPER"),
]

PROJECTS = [
    ("E-Commerce", "ECOM", "Customer shopping and checkout"),
    ("Mobile App", "MOB", "iOS and Android client"),
    ("Data Analytics", "DATA", "Reporting and analytics platform"),
    ("Internal Tools", "TOOLS", "Internal productivity systems"),
    ("Web Portal", "WEB", "Customer web portal"),
]

BUGS = [
    ("Payment page fails on retry", "ECOM", "CRITICAL", "P1", "NEW", "qa", None),
    ("Search results omit new items", "ECOM", "HIGH", "P2", "IN_TRIAGE", "qa", None),
    ("Push notification arrives late", "MOB", "MEDIUM", "P3", "ASSIGNED", "qa", "rahul"),
    ("Chart legend overlaps on tablet", "DATA", "MEDIUM", "P2", "IN_DEVELOPMENT", "qa", "rahul"),
    ("CSV export uses wrong timezone", "TOOLS", "HIGH", "P2", "FIX_SUBMITTED", "techlead", "karan"),
    ("Password reset link expires early", "WEB", "HIGH", "P1", "PR_REVIEW", "qa", "sneha"),
    (
        "Dashboard count is stale after refresh",
        "DATA",
        "MEDIUM",
        "P3",
        "CI_PENDING",
        "qa",
        "vikram",
    ),
    ("Mobile profile image does not refresh", "MOB", "LOW", "P4", "CI_PASSED", "qa", "ayush"),
    ("Order confirmation banner missing", "ECOM", "CRITICAL", "P1", "DEPLOYED", "qa", "rahul"),
    (
        "Account settings save intermittently fails",
        "WEB",
        "HIGH",
        "P2",
        "READY_FOR_RETEST",
        "qa",
        "karan",
    ),
    ("Login issue returned after cache clear", "WEB", "CRITICAL", "P1", "REOPENED", "qa", "sneha"),
    ("Invoice download truncates long addresses", "TOOLS", "MEDIUM", "P3", "CLOSED", "qa", "rahul"),
    ("Team summary shows duplicate members", "DATA", "LOW", "P4", "CLOSED", "techlead", "vikram"),
]


class Command(BaseCommand):
    help = "Create local demo roles, users, projects, bugs, and workflow history."

    @transaction.atomic
    def handle(self, *args, **options):
        existing_users = User.objects.exists()
        password = os.getenv("DEMO_PASSWORD") or (
            None if existing_users else secrets.token_urlsafe(18)
        )
        roles = {}
        for code, label, level in (
            ("MANAGER", "Project Manager", 4),
            ("QA", "QA Engineer", 3),
            ("TECH_LEAD", "Tech Lead", 2),
            ("DEVELOPER", "Developer", 1),
        ):
            roles[code], _ = Role.objects.update_or_create(
                code=code, defaults={"label": label, "hierarchy_level": level}
            )
        permissions = {
            code: Permission.objects.update_or_create(code=code, defaults={"description": label})[0]
            for code, label in PERMISSIONS.items()
        }
        for role_code, codes in ROLE_CAPABILITIES.items():
            role = roles[role_code]
            for code, permission in permissions.items():
                if code in codes:
                    RolePermission.objects.get_or_create(role=role, permission=permission)
                else:
                    RolePermission.objects.filter(role=role, permission=permission).delete()

        users = {}
        for username, first, last, role_code in USERS:
            user, created = User.objects.get_or_create(
                username=username,
                defaults={
                    "first_name": first,
                    "last_name": last,
                    "email": f"{username}@bugtracker.local",
                    "is_active": True,
                },
            )
            if created:
                user.set_password(password or secrets.token_urlsafe(18))
                user.save()
            else:
                user.first_name, user.last_name, user.is_active = first, last, True
                user.save(update_fields=("first_name", "last_name", "is_active", "updated_at"))
            user.roles.set([roles[role_code]])
            users[username] = user

        projects = {}
        for name, key, description in PROJECTS:
            projects[key], _ = Project.objects.get_or_create(
                key=key,
                defaults={"name": name, "description": description, "created_by": users["manager"]},
            )

        if Bug.objects.exists():
            self.stdout.write(
                self.style.SUCCESS(
                    "Roles, permissions, demo users, and projects are up to date. Existing bugs were preserved."
                )
            )
            if password and not existing_users:
                self.stdout.write(f"Initial demo password: {password}")
            return

        for index, (
            title,
            project_key,
            severity,
            priority,
            status_code,
            reporter_key,
            assignee_key,
        ) in enumerate(BUGS, start=1001):
            reporter = users[reporter_key]
            assignee = users.get(assignee_key) if assignee_key else None
            cycle = (
                0
                if status_code in ("NEW", "IN_TRIAGE", "ASSIGNED")
                else (2 if index == 1012 else 1)
            )
            reopen_count = 1 if status_code == "REOPENED" else (1 if index == 1012 else 0)
            bug = Bug.objects.create(
                bug_key=f"BUG-{index}",
                project=projects[project_key],
                title=title,
                description=f"{title}. This seeded issue is provided to make the {status_code.replace('_', ' ').lower()} workflow visible.",
                steps_to_reproduce="1. Open the relevant screen.\n2. Repeat the affected action.\n3. Observe the issue.",
                expected_result="The action completes and the UI shows the correct result.",
                actual_result="The reported behavior is reproduced.",
                severity=severity,
                priority=priority,
                status=status_code,
                reported_by=reporter,
                triaged_by=users["techlead"] if status_code != "NEW" else None,
                assigned_to=assignee,
                environment="Staging",
                application_version="2.8.0",
                development_cycle=cycle,
                reopen_count=reopen_count,
                is_reopened=reopen_count > 0,
                due_at=timezone.now() + timedelta(days=(index % 7) - 2),
            )
            BugHistory.objects.create(
                bug=bug,
                user=reporter,
                action="Bug reported",
                field_name="status",
                new_value="NEW",
                performed_role=reporter.role_code,
                performed_mode=reporter.role_code,
            )
            if status_code != "NEW":
                BugStatusTransition.objects.create(
                    bug=bug,
                    from_status="NEW",
                    to_status="IN_TRIAGE",
                    actor=users["techlead"],
                    note="Seeded triage history",
                )
                BugHistory.objects.create(
                    bug=bug,
                    user=users["techlead"],
                    action="Status changed: NEW → IN_TRIAGE",
                    field_name="status",
                    old_value="NEW",
                    new_value="IN_TRIAGE",
                    performed_role="TECH_LEAD",
                    performed_mode="TECH_LEAD",
                )
            if assignee:
                BugAssignment.objects.create(
                    bug=bug,
                    assigned_to=assignee,
                    assigned_by=users["techlead"],
                    note="Seeded assignment",
                )
            if cycle:
                pr_status = (
                    BugEngineering.PRStatus.MERGED
                    if status_code
                    in (
                        "CI_PENDING",
                        "CI_PASSED",
                        "DEPLOYED",
                        "READY_FOR_RETEST",
                        "REOPENED",
                        "CLOSED",
                    )
                    else (
                        BugEngineering.PRStatus.OPEN
                        if status_code == "PR_REVIEW"
                        else BugEngineering.PRStatus.NONE
                    )
                )
                ci_status = (
                    BugEngineering.CIStatus.PENDING
                    if status_code == "CI_PENDING"
                    else (
                        BugEngineering.CIStatus.PASSED
                        if status_code
                        in ("CI_PASSED", "DEPLOYED", "READY_FOR_RETEST", "REOPENED", "CLOSED")
                        else BugEngineering.CIStatus.NOT_RUN
                    )
                )
                BugEngineering.objects.create(
                    bug=bug,
                    cycle=cycle,
                    developer=assignee or users["rahul"],
                    branch_name=f"fix/{bug.bug_key.lower()}",
                    commit_reference=f"{index:07x}",
                    pull_request_url=(
                        f"https://github.com/demo/bugtracker/pull/{index}"
                        if pr_status != "NONE"
                        else ""
                    ),
                    pr_status=pr_status,
                    ci_status=ci_status,
                    fix_notes="Seeded engineering notes for workflow preview.",
                )
            if status_code in ("DEPLOYED", "READY_FOR_RETEST", "REOPENED", "CLOSED"):
                BugDeploymentHistory.objects.create(
                    bug=bug,
                    cycle=cycle,
                    environment="Staging",
                    version="2.8.1",
                    deployed_by=assignee or users["rahul"],
                    notes="Seeded deployment history",
                )
            if status_code == "REOPENED":
                BugRetest.objects.create(
                    bug=bug,
                    cycle=cycle,
                    retested_by=users["qa"],
                    test_environment="Staging",
                    test_version="2.8.1",
                    test_steps="Repeat the reported steps.",
                    expected_result="The issue is fixed.",
                    actual_result="The issue still occurs.",
                    test_result="FAIL",
                    remarks="Seeded failed retest.",
                )
            if index == 1012:
                BugDeploymentHistory.objects.create(
                    bug=bug,
                    cycle=1,
                    environment="Staging",
                    version="2.8.0",
                    deployed_by=users["rahul"],
                    notes="First fix deployment",
                )
                BugRetest.objects.create(
                    bug=bug,
                    cycle=1,
                    retested_by=users["qa"],
                    test_environment="Staging",
                    test_version="2.8.0",
                    test_steps="Download a long-address invoice.",
                    expected_result="Full address is present.",
                    actual_result="Address was truncated.",
                    test_result="FAIL",
                    remarks="First QA cycle failed.",
                )
                BugRetest.objects.create(
                    bug=bug,
                    cycle=2,
                    retested_by=users["qa"],
                    test_environment="Staging",
                    test_version="2.8.1",
                    test_steps="Download a long-address invoice again.",
                    expected_result="Full address is present.",
                    actual_result="Full address is present.",
                    test_result="PASS",
                    remarks="Second QA cycle passed.",
                )
                bug.closed_at = timezone.now()
                bug.save(update_fields=("closed_at", "updated_at"))
                for old_status, new_status in (
                    ("READY_FOR_RETEST", "QA_RETEST"),
                    ("QA_RETEST", "REOPENED"),
                    ("REOPENED", "IN_DEVELOPMENT"),
                    ("IN_DEVELOPMENT", "FIX_SUBMITTED"),
                    ("FIX_SUBMITTED", "PR_REVIEW"),
                    ("PR_REVIEW", "CI_PENDING"),
                    ("CI_PENDING", "CI_PASSED"),
                    ("CI_PASSED", "DEPLOYED"),
                    ("DEPLOYED", "READY_FOR_RETEST"),
                    ("READY_FOR_RETEST", "QA_RETEST"),
                    ("QA_RETEST", "CLOSED"),
                ):
                    BugStatusTransition.objects.create(
                        bug=bug,
                        from_status=old_status,
                        to_status=new_status,
                        actor=users["qa"],
                        note="Seeded two-cycle lifecycle",
                    )
            if status_code in ("READY_FOR_RETEST", "REOPENED", "CLOSED"):
                notify = [users["qa"]] if status_code != "CLOSED" else [reporter, assignee]
                Notification.objects.bulk_create(
                    [
                        Notification(
                            user=user,
                            bug=bug,
                            title=f"{bug.bug_key}: {bug.get_status_display()}",
                            body=bug.title,
                            kind=status_code,
                        )
                        for user in notify
                        if user
                    ]
                )

        # Keep a small reported-issue queue so the QA verification gate is visible in a fresh demo.
        if not ReportedIssue.objects.exists():
            for offset, (title, project_key, reporter_key) in enumerate(
                (
                    ("Checkout spinner never completes", "ECOM", "rahul"),
                    ("Profile image appears stale after upload", "MOB", "karan"),
                    ("Analytics export header is incorrect", "DATA", "sneha"),
                ),
                start=1,
            ):
                ReportedIssue.objects.create(
                    project=projects[project_key],
                    title=title,
                    description=f"{title}. This is a demo reported issue awaiting QA verification.",
                    steps_to_reproduce="1. Open the feature.\n2. Perform the affected action.\n3. Observe the behavior.",
                    expected_result="The feature behaves as documented.",
                    actual_result="The reported behavior is observed.",
                    severity=("HIGH", "MEDIUM", "LOW")[offset - 1],
                    priority=("P2", "P3", "P4")[offset - 1],
                    environment="Staging",
                    application_version="2.8.1",
                    reported_by=users[reporter_key],
                )

        self.stdout.write(
            self.style.SUCCESS(
                f"Seeded {Role.objects.count()} roles, {User.objects.count()} users, {Project.objects.count()} projects, {Bug.objects.count()} bugs, and {ReportedIssue.objects.count()} reported issues."
            )
        )
        if password and not existing_users:
            self.stdout.write(
                "Demo accounts: manager, qa, techlead, rahul, karan, sneha, vikram, ayush"
            )
            self.stdout.write(f"Initial demo password: {password}")
