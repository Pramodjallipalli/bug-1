import os

import requests
import streamlit as st

API_BASE_URL = os.getenv("API_BASE_URL", "http://127.0.0.1:8000/api").rstrip("/")
TIMEOUT_SECONDS = 15


class APIError(RuntimeError):
    def __init__(self, message, status_code=None, payload=None):
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload


def _mode_header():
    mode = st.session_state.get("work_mode", "DEFAULT")
    return {"X-Work-Mode": mode} if mode != "DEFAULT" else {}


def _refresh_access_token():
    refresh = st.session_state.get("refresh_token")
    if not refresh:
        return False
    try:
        response = requests.post(
            f"{API_BASE_URL}/auth/token/refresh/",
            json={"refresh": refresh},
            timeout=TIMEOUT_SECONDS,
        )
        if response.status_code >= 400:
            return False
        result = response.json()
        st.session_state["access_token"] = result["access"]
        st.session_state["refresh_token"] = result.get("refresh", refresh)
        return True
    except requests.RequestException:
        return False


def request(method, path, *, params=None, json=None, data=None, files=None, stream=False):
    url = f"{API_BASE_URL}/{path.lstrip('/')}"
    headers = _mode_header()
    token = st.session_state.get("access_token")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        response = requests.request(
            method,
            url,
            params=params,
            json=json,
            data=data,
            files=files,
            headers=headers,
            timeout=TIMEOUT_SECONDS,
            stream=stream,
        )
        if (
            response.status_code == 401
            and token
            and not path.startswith("auth/")
            and _refresh_access_token()
        ):
            headers["Authorization"] = f"Bearer {st.session_state['access_token']}"
            response = requests.request(
                method,
                url,
                params=params,
                json=json,
                data=data,
                files=files,
                headers=headers,
                timeout=TIMEOUT_SECONDS,
                stream=stream,
            )
    except requests.Timeout as exc:
        raise APIError("The server took too long to respond. Please try again.") from exc
    except requests.ConnectionError as exc:
        raise APIError(
            "Unable to reach the BugTracker API. Check that the backend is running."
        ) from exc
    except requests.RequestException as exc:
        raise APIError("The request could not be completed.") from exc
    if response.status_code >= 400:
        try:
            payload = response.json()
        except ValueError:
            payload = response.text[:500]
        if response.status_code == 401 and token:
            st.session_state.pop("access_token", None)
            st.session_state.pop("refresh_token", None)
            st.session_state.pop("user", None)
            raise APIError("Session expired. Please log in again.", response.status_code, payload)
        if isinstance(payload, dict):
            detail = payload.get("detail") or "; ".join(
                f"{key}: {value}" for key, value in payload.items()
            )
        else:
            detail = str(payload)
        raise APIError(detail or "The request was rejected.", response.status_code, payload)
    if response.status_code == 204 or not response.content:
        return None
    if stream:
        return response
    try:
        return response.json()
    except ValueError:
        return response.content


def login(username, password):
    result = request("POST", "auth/login/", json={"username": username, "password": password})
    st.session_state["access_token"] = result["access"]
    st.session_state["refresh_token"] = result["refresh"]
    st.session_state["user"] = result["user"]
    st.session_state["work_mode"] = "DEFAULT"


def logout():
    refresh = st.session_state.get("refresh_token")
    if refresh and st.session_state.get("access_token"):
        try:
            request("POST", "auth/logout/", json={"refresh": refresh})
        except APIError:
            pass
    for key in ("access_token", "refresh_token", "user", "work_mode", "selected_bug_id"):
        st.session_state.pop(key, None)


def authenticated():
    return bool(st.session_state.get("access_token") and st.session_state.get("user"))


def current_user():
    return st.session_state.get("user", {})
