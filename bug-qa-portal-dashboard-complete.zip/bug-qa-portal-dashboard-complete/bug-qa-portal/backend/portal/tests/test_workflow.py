from django.test import TestCase
from rest_framework.test import APIClient

from portal.models import (
    Bug,
    BugHistory,
    BugStatusTransition,
    Notification,
    Permission,
    Project,
    ReportedIssue,
    Role,
    RolePermission,
    User,
)


class BugWorkflowTests(TestCase):
    def setUp(self):
        self.roles = {
            code: Role.objects.create(code=code, label=label, hierarchy_level=level)
            for code, label, level in (
                ("MANAGER", "Project Manager", 4),
                ("QA", "QA Engineer", 3),
                ("TECH_LEAD", "Tech Lead", 2),
                ("DEVELOPER", "Developer", 1),
            )
        }
        capabilities = {
            "MANAGER": set(),
            "QA": {
                "ISSUE_REPORT",
                "ISSUE_VIEW",
                "ISSUE_REVIEW",
                "BUG_VIEW",
                "BUG_EDIT",
                "BUG_TRIAGE",
                "BUG_ASSIGN",
                "BUG_REASSIGN",
                "BUG_DEVELOP",
                "BUG_FIX",
                "BUG_PR",
                "BUG_CI",
                "BUG_DEPLOY",
                "BUG_RETEST",
                "BUG_PASS",
                "BUG_FAIL",
                "BUG_CLOSE",
                "BUG_REOPEN",
                "PROJECT_VIEW",
                "REPORT_VIEW",
                "USER_VIEW",
            },
            "TECH_LEAD": {
                "ISSUE_REPORT",
                "ISSUE_VIEW",
                "ISSUE_REVIEW",
                "BUG_VIEW",
                "BUG_EDIT",
                "BUG_TRIAGE",
                "BUG_ASSIGN",
                "BUG_REASSIGN",
                "BUG_DEVELOP",
                "BUG_FIX",
                "BUG_PR",
                "BUG_CI",
                "BUG_DEPLOY",
                "BUG_REOPEN",
                "PROJECT_VIEW",
                "REPORT_VIEW",
                "USER_VIEW",
            },
            "DEVELOPER": {
                "ISSUE_REPORT",
                "ISSUE_VIEW",
                "ISSUE_REVIEW",
                "BUG_VIEW",
                "BUG_DEVELOP",
                "BUG_FIX",
                "BUG_PR",
                "BUG_CI",
                "BUG_DEPLOY",
                "PROJECT_VIEW",
                "REPORT_VIEW",
                "USER_VIEW",
            },
        }
        for role_code, codes in capabilities.items():
            for code in codes:
                permission, _ = Permission.objects.get_or_create(
                    code=code, defaults={"description": code}
                )
                RolePermission.objects.create(role=self.roles[role_code], permission=permission)
        self.users = {}
        for username, role in (
            ("manager", "MANAGER"),
            ("qa", "QA"),
            ("lead", "TECH_LEAD"),
            ("dev", "DEVELOPER"),
        ):
            user = User.objects.create_user(
                username=username,
                password="Long-demo-password-42",
                first_name=username.title(),
                email=f"{username}@example.test",
            )
            user.roles.add(self.roles[role])
            self.users[role] = user
        self.project = Project.objects.create(
            name="Checkout", key="CHECK", created_by=self.users["MANAGER"]
        )
        self.client = APIClient()

    def _login_as(self, role):
        self.client.force_authenticate(self.users[role])

    def _create_bug(self, role="QA"):
        # Everyone reports an issue; QA verifies it and creates the official bug.
        self._login_as(role)
        response = self.client.post(
            "/api/reported-issues/",
            {
                "project": self.project.pk,
                "title": "Login flow returns an error",
                "description": "A valid account cannot complete login.",
                "steps_to_reproduce": "Enter valid credentials and submit.",
                "expected_result": "The user is signed in.",
                "actual_result": "An error is shown.",
                "severity": "HIGH",
                "priority": "P2",
                "environment": "Staging",
                "application_version": "1.0.0",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201, response.data)
        issue_id = response.data["id"]
        self._login_as("QA")
        response = self.client.post(
            f"/api/reported-issues/{issue_id}/review/",
            {
                "tech_lead_id": self.users["TECH_LEAD"].pk,
                "developer_id": self.users["DEVELOPER"].pk,
                "note": "Verified and reproducible.",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201, response.data)
        self.assertEqual(response.data["status"], Bug.Status.NEW)
        return response.data["id"]

    def _finish_development_cycle(self, bug_id, cycle):
        self._login_as("DEVELOPER")
        self.assertEqual(self.client.post(f"/api/bugs/{bug_id}/start-work/").status_code, 200)
        self.assertEqual(
            self.client.patch(
                f"/api/bugs/{bug_id}/engineering/",
                {
                    "branch_name": f"fix/login-cycle-{cycle}",
                    "commit_reference": f"commit-{cycle}",
                    "fix_notes": f"Fix for cycle {cycle}.",
                },
                format="json",
            ).status_code,
            200,
        )
        self.assertEqual(
            self.client.post(
                f"/api/bugs/{bug_id}/submit-fix/",
                {"fix_notes": f"Fix for cycle {cycle}."},
                format="json",
            ).status_code,
            200,
        )
        pr = self.client.post(
            f"/api/bugs/{bug_id}/pr/",
            {
                "pull_request_url": f"https://github.com/example/portal/pull/{cycle}",
                "pr_status": "MERGED",
            },
            format="json",
        )
        self.assertEqual(pr.status_code, 200, pr.data)
        bug = Bug.objects.get(pk=bug_id)
        self.assertEqual(bug.status, Bug.Status.CI_PENDING)
        ci = self.client.post(
            f"/api/bugs/{bug_id}/ci/",
            {"ci_status": "PASSED", "ci_link": "https://ci.example/run/1"},
            format="json",
        )
        self.assertEqual(ci.status_code, 200, ci.data)
        deployment = self.client.post(
            f"/api/bugs/{bug_id}/deploy/",
            {
                "environment": "Staging",
                "version": f"1.0.{cycle}",
                "notes": f"Cycle {cycle} deployment",
            },
            format="json",
        )
        self.assertEqual(deployment.status_code, 200, deployment.data)
        ready = self.client.post(f"/api/bugs/{bug_id}/ready-for-retest/", {}, format="json")
        self.assertEqual(ready.status_code, 200, ready.data)

    def _retest(self, bug_id, result, cycle):
        self._login_as("QA")
        response = self.client.post(
            f"/api/bugs/{bug_id}/retests/",
            {
                "test_environment": "Staging",
                "test_version": f"1.0.{cycle}",
                "test_steps": "Sign in using a valid account.",
                "expected_result": "The user is signed in.",
                "actual_result": (
                    "The user is signed in." if result == "PASS" else "An error is displayed."
                ),
                "test_result": result,
                "remarks": f"Cycle {cycle} {result.lower()}.",
            },
            format="json",
        )
        self.assertEqual(response.status_code, 201, response.data)

    def test_fail_reopens_and_second_pass_closes_with_full_audit(self):
        bug_id = self._create_bug()
        self._login_as("QA")
        self.assertEqual(
            self.client.post(
                f"/api/bugs/{bug_id}/triage/", {"note": "Repro confirmed."}, format="json"
            ).status_code,
            200,
        )
        self.assertEqual(
            self.client.post(
                f"/api/bugs/{bug_id}/assign/",
                {"user_id": self.users["DEVELOPER"].pk},
                format="json",
            ).status_code,
            200,
        )

        self._finish_development_cycle(bug_id, 1)
        self._retest(bug_id, "FAIL", 1)
        bug = Bug.objects.get(pk=bug_id)
        self.assertEqual(bug.status, Bug.Status.REOPENED)
        self.assertEqual(bug.reopen_count, 1)
        self.assertTrue(bug.is_reopened)

        self._finish_development_cycle(bug_id, 2)
        self._retest(bug_id, "PASS", 2)
        bug.refresh_from_db()
        self.assertEqual(bug.status, Bug.Status.CLOSED)
        self.assertEqual(bug.retests.count(), 2)
        self.assertEqual(set(bug.retests.values_list("test_result", flat=True)), {"PASS", "FAIL"})
        self.assertEqual(bug.deployments.count(), 2)
        self.assertGreaterEqual(BugHistory.objects.filter(bug=bug).count(), 12)
        self.assertEqual(
            BugStatusTransition.objects.filter(bug=bug, to_status=Bug.Status.REOPENED).count(), 1
        )
        self.assertTrue(
            Notification.objects.filter(
                bug=bug, kind="QA_FAIL", user=self.users["DEVELOPER"]
            ).exists()
        )
        self.assertTrue(Notification.objects.filter(bug=bug, kind="CLOSED").exists())

        self._login_as("MANAGER")
        dashboard = self.client.get("/api/dashboard/manager/")
        self.assertEqual(dashboard.status_code, 200)
        self.assertGreaterEqual(dashboard.data["kpis"]["closed_bugs"], 1)
        self.assertEqual(dashboard.data["kpis"]["failed_retests"], 1)

    def test_every_role_can_report_but_developer_cannot_set_status_or_retest(self):
        for role in ("MANAGER", "QA", "TECH_LEAD", "DEVELOPER"):
            bug_id = self._create_bug(role)
            bug = Bug.objects.get(pk=bug_id)
            self.assertEqual(bug.reported_by, self.users[role])
            self._login_as(role)
            direct_status = self.client.patch(
                f"/api/bugs/{bug_id}/", {"status": "CLOSED"}, format="json"
            )
            expected_code = 403 if role == "DEVELOPER" else 400
            self.assertEqual(direct_status.status_code, expected_code)
            self.assertEqual(Bug.objects.get(pk=bug_id).status, Bug.Status.NEW)
        bug_id = self._create_bug("QA")
        for role in ("TECH_LEAD", "DEVELOPER"):
            self._login_as(role)
            response = self.client.post(
                f"/api/bugs/{bug_id}/retests/",
                {
                    "test_environment": "Staging",
                    "test_version": "1",
                    "test_steps": "Step",
                    "expected_result": "Expected",
                    "actual_result": "Actual",
                    "test_result": "PASS",
                },
                format="json",
            )
            self.assertEqual(response.status_code, 403)

    def test_every_role_can_report_issue_but_only_qa_verifies(self):
        issue_ids = {}
        for role in ("MANAGER", "QA", "TECH_LEAD", "DEVELOPER"):
            self._login_as(role)
            response = self.client.post(
                "/api/reported-issues/",
                {
                    "project": self.project.pk,
                    "title": f"Issue reported by {role}",
                    "description": "Suspected defect.",
                    "severity": "MEDIUM",
                    "priority": "P3",
                },
                format="json",
            )
            self.assertEqual(response.status_code, 201, response.data)
            issue_ids[role] = response.data["id"]
        self._login_as("TECH_LEAD")
        blocked = self.client.post(
            f"/api/reported-issues/{issue_ids['DEVELOPER']}/review/",
            {"tech_lead_id": self.users["TECH_LEAD"].pk, "developer_id": self.users["DEVELOPER"].pk},
            format="json",
        )
        self.assertEqual(blocked.status_code, 403)
        self._login_as("QA")
        converted = self.client.post(
            f"/api/reported-issues/{issue_ids['DEVELOPER']}/review/",
            {"tech_lead_id": self.users["TECH_LEAD"].pk, "developer_id": self.users["DEVELOPER"].pk},
            format="json",
        )
        self.assertEqual(converted.status_code, 201, converted.data)
        bug = Bug.objects.get(pk=converted.data["id"])
        self.assertEqual(bug.verified_by, self.users["QA"])
        self.assertEqual(bug.tech_lead, self.users["TECH_LEAD"])
        self.assertEqual(bug.assigned_to, self.users["DEVELOPER"])

    def test_every_role_can_view_bug_status(self):
        bug_id = self._create_bug("QA")
        for role in ("MANAGER", "QA", "TECH_LEAD", "DEVELOPER"):
            self._login_as(role)
            response = self.client.get(f"/api/bugs/{bug_id}/")
            self.assertEqual(response.status_code, 200, response.data)
            self.assertEqual(response.data["status"], Bug.Status.NEW)

    def test_manager_can_view_every_role_dashboard(self):
        self._login_as("MANAGER")
        for kind in ("manager", "qa", "tech-lead", "developer"):
            response = self.client.get(f"/api/dashboard/{kind}/")
            self.assertEqual(response.status_code, 200, response.data)

    def test_public_health_endpoint_is_available(self):
        response = self.client.get("/api/health/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["status"], "ok")

    def test_manager_can_login_and_refresh_endpoint_is_present(self):
        response = self.client.post(
            "/api/auth/login/",
            {"username": "manager", "password": "Long-demo-password-42"},
            format="json",
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn("access", response.data)
        self.assertEqual(response.data["user"]["role_code"], "MANAGER")

        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {response.data['access']}")
        logout = self.client.post(
            "/api/auth/logout/", {"refresh": response.data["refresh"]}, format="json"
        )
        self.assertEqual(logout.status_code, 204)
        refresh = self.client.post(
            "/api/auth/token/refresh/", {"refresh": response.data["refresh"]}, format="json"
        )
        self.assertEqual(refresh.status_code, 401)

    def test_qa_developer_mode_keeps_qa_identity_in_audit(self):
        bug_id = self._create_bug("QA")
        self._login_as("QA")
        triage = self.client.post(
            f"/api/bugs/{bug_id}/triage/", {"note": "Confirmed for developer mode."}, format="json"
        )
        self.assertEqual(triage.status_code, 200)
        assignment = self.client.post(
            f"/api/bugs/{bug_id}/assign/",
            {"user_id": self.users["DEVELOPER"].pk},
            format="json",
        )
        self.assertEqual(assignment.status_code, 200)

        self.client.credentials(HTTP_X_WORK_MODE="DEVELOPER")
        start = self.client.post(f"/api/bugs/{bug_id}/start-work/")
        self.assertEqual(start.status_code, 200, start.data)
        self.assertTrue(
            BugHistory.objects.filter(
                bug_id=bug_id,
                performed_role="QA",
                performed_mode="QA_DEVELOPER_MODE",
                new_value=Bug.Status.IN_DEVELOPMENT,
            ).exists()
        )
