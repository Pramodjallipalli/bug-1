from datetime import timedelta

from django.db.models import Count, Q
from django.db.models.functions import TruncDate
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django_filters.rest_framework import DjangoFilterBackend
from drf_spectacular.types import OpenApiTypes
from drf_spectacular.utils import OpenApiParameter, OpenApiResponse, extend_schema
from rest_framework import filters, status, viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.tokens import RefreshToken

from .models import (
    Bug,
    BugAssignment,
    BugHistory,
    BugEngineering,
    BugRetest,
    Notification,
    Project,
    ReportedIssue,
    User,
)
from .permissions import CapabilityPermission, require_capability
from .serializers import (
    AssignmentInputSerializer,
    BugAttachmentSerializer,
    BugCommentSerializer,
    BugEngineeringSerializer,
    BugHistorySerializer,
    BugListSerializer,
    BugRetestSerializer,
    BugSerializer,
    CIInputSerializer,
    DashboardResponseSerializer,
    DeploymentInputSerializer,
    FixInputSerializer,
    LoginInputSerializer,
    LoginResponseSerializer,
    LogoutInputSerializer,
    NoteSerializer,
    NotificationSerializer,
    ProjectSerializer,
    PullRequestInputSerializer,
    ReportedIssueSerializer,
    IssueReviewSerializer,
    ReadAllResponseSerializer,
    UserCreateSerializer,
    UserSummarySerializer,
)
from .workflow import (
    add_comment,
    assign_bug,
    audit,
    create_retest,
    mark_ready_for_retest,
    notify_roles,
    record_ci,
    record_deployment,
    reopen_bug,
    start_work,
    submit_fix,
    triage_bug,
    update_engineering,
    update_pull_request,
    convert_issue_to_bug,
    reject_reported_issue,
)


class HealthView(APIView):
    """Unauthenticated liveness endpoint used by Docker and local health checks."""

    permission_classes = (AllowAny,)
    authentication_classes = ()

    def get(self, request):
        return Response({"status": "ok", "service": "bugtracker-api"})


class LoginSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["role"] = user.role_code
        return token

    def validate(self, attrs):
        result = super().validate(attrs)
        result["user"] = UserSummarySerializer(self.user).data
        return result


class LoginView(APIView):
    permission_classes = (AllowAny,)
    authentication_classes = ()

    @extend_schema(
        request=LoginInputSerializer,
        responses={
            200: LoginResponseSerializer,
            400: OpenApiResponse(description="Invalid credentials or request."),
        },
    )
    def post(self, request):
        serializer = LoginSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        return Response(serializer.validated_data)


class LogoutView(APIView):
    permission_classes = (IsAuthenticated,)

    @extend_schema(
        request=LogoutInputSerializer,
        responses={
            204: OpenApiResponse(description="Refresh token revoked."),
            400: OpenApiResponse(description="Refresh token is invalid or missing."),
        },
    )
    def post(self, request):
        serializer = LogoutInputSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        refresh_token = serializer.validated_data["refresh"]
        try:
            RefreshToken(refresh_token).blacklist()
        except Exception:
            return Response(
                {"detail": "Invalid or expired refresh token."}, status=status.HTTP_400_BAD_REQUEST
            )
        return Response(status=status.HTTP_204_NO_CONTENT)


class CapabilityViewSet(viewsets.ModelViewSet):
    required_capability = "BUG_VIEW"
    action_capabilities = {}

    def get_permissions(self):
        capability = self.action_capabilities.get(self.action, self.required_capability)
        self.required_capability = capability
        return [IsAuthenticated(), CapabilityPermission()]


class UserViewSet(CapabilityViewSet):
    queryset = User.objects.prefetch_related("roles").all().order_by("username")
    serializer_class = UserSummarySerializer
    action_capabilities = {
        "list": "USER_VIEW",
        "retrieve": "USER_VIEW",
        "create": "USER_MANAGE",
        "update": "USER_MANAGE",
        "partial_update": "USER_MANAGE",
        "destroy": "USER_MANAGE",
    }
    http_method_names = ("get", "post", "patch", "head", "options")

    def get_serializer_class(self):
        return (
            UserCreateSerializer
            if self.action in ("create", "update", "partial_update")
            else UserSummarySerializer
        )

    def perform_create(self, serializer):
        serializer.save()

    def partial_update(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = UserSummarySerializer(instance, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ProjectViewSet(CapabilityViewSet):
    queryset = Project.objects.select_related("created_by").all()
    serializer_class = ProjectSerializer
    action_capabilities = {
        "list": "PROJECT_VIEW",
        "retrieve": "PROJECT_VIEW",
        "create": "PROJECT_MANAGE",
        "update": "PROJECT_MANAGE",
        "partial_update": "PROJECT_MANAGE",
        "destroy": "PROJECT_MANAGE",
    }
    http_method_names = ("get", "post", "patch", "put", "head", "options")

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class ReportedIssueViewSet(CapabilityViewSet):
    queryset = ReportedIssue.objects.select_related("project", "reported_by", "reviewed_by", "converted_bug")
    serializer_class = ReportedIssueSerializer
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ("project", "status", "reported_by")
    search_fields = ("issue_key", "title", "description")
    ordering = ("-created_at",)
    action_capabilities = {
        "list": "ISSUE_VIEW",
        "retrieve": "ISSUE_VIEW",
        "create": "ISSUE_REPORT",
        "review": "ISSUE_REVIEW",
        "reject": "ISSUE_REVIEW",
    }
    http_method_names = ("get", "post", "head", "options")

    def perform_create(self, serializer):
        serializer.save(reported_by=self.request.user)

    @action(detail=True, methods=("post",))
    def review(self, request, pk=None):
        issue = self.get_object()
        data = IssueReviewSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        tech_lead = get_object_or_404(User, pk=data.validated_data["tech_lead_id"], is_active=True)
        developer = get_object_or_404(User, pk=data.validated_data["developer_id"], is_active=True)
        bug = convert_issue_to_bug(
            issue, request, tech_lead, developer, data.validated_data.get("note", "")
        )
        return Response(BugSerializer(bug, context={"request": request}).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=("post",))
    def reject(self, request, pk=None):
        issue = self.get_object()
        data = NoteSerializer(data=request.data)
        data.is_valid(raise_exception=True)
        issue = reject_reported_issue(issue, request, data.validated_data.get("note", ""))
        return Response(ReportedIssueSerializer(issue).data)


class BugViewSet(CapabilityViewSet):
    queryset = Bug.objects.select_related(
        "project", "reported_by", "triaged_by", "assigned_to"
    ).prefetch_related(
        "engineering_cycles__developer",
        "deployments__deployed_by",
        "retests__retested_by",
        "history",
    )
    serializer_class = BugSerializer
    parser_classes = (JSONParser, MultiPartParser, FormParser)
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = (
        "project",
        "status",
        "severity",
        "priority",
        "assigned_to",
        "reported_by",
        "environment",
        "is_reopened",
    )
    search_fields = ("bug_key", "title", "description")
    ordering_fields = ("created_at", "updated_at", "severity", "priority", "due_at")
    ordering = ("-updated_at",)
    action_capabilities = {
        "list": "BUG_VIEW",
        "retrieve": "BUG_VIEW",
        "create": "BUG_CREATE",
        "update": "BUG_EDIT",
        "partial_update": "BUG_EDIT",
        "destroy": "BUG_EDIT",
        "triage": "BUG_TRIAGE",
        "assign": "BUG_ASSIGN",
        "reassign": "BUG_REASSIGN",
        "start_work_action": "BUG_DEVELOP",
        "engineering": "BUG_DEVELOP",
        "submit_fix_action": "BUG_FIX",
        "pr": "BUG_PR",
        "ci": "BUG_CI",
        "deploy": "BUG_DEPLOY",
        "ready_for_retest": "BUG_DEPLOY",
        "retests": "BUG_VIEW",
        "comments": "BUG_VIEW",
        "history": "BUG_VIEW",
        "attachments": "BUG_VIEW",
        "attachment_download": "BUG_VIEW",
        "reopen": "BUG_REOPEN",
    }
    http_method_names = ("get", "post", "patch", "put", "head", "options")

    def get_serializer_class(self):
        return BugListSerializer if self.action == "list" else BugSerializer

    def get_queryset(self):
        queryset = Bug.objects.select_related("project", "reported_by", "triaged_by", "assigned_to")
        if self.action != "list":
            queryset = queryset.prefetch_related(
                "engineering_cycles__developer",
                "deployments__deployed_by",
                "retests__retested_by",
                "history__user",
                "assignments__assigned_to",
                "assignments__assigned_by",
                "status_transitions__actor",
            )
        # Every authenticated role with BUG_VIEW can view bug status/details.
        # Action endpoints still enforce role/ownership in workflow.py.
        created_after = self.request.query_params.get("created_after")
        created_before = self.request.query_params.get("created_before")
        if created_after:
            queryset = queryset.filter(created_at__date__gte=created_after)
        if created_before:
            queryset = queryset.filter(created_at__date__lte=created_before)
        return queryset

    def perform_create(self, serializer):
        if self.request.user.role_code != "MANAGER" and not self.request.user.is_superuser:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied("Official bugs are created only after QA verification of a reported issue.")
        bug = serializer.save(reported_by=self.request.user, verified_by=self.request.user)
        audit(bug, self.request, "Bug reported", field_name="status", new_value=bug.status)
        notify_roles(
            ("TECH_LEAD", "MANAGER"), bug, f"New bug reported: {bug.bug_key}", bug.title, "NEW_BUG"
        )

    def perform_update(self, serializer):
        old = self.get_object()
        before = {
            field: getattr(old, field)
            for field in (
                "title",
                "description",
                "severity",
                "priority",
                "environment",
                "application_version",
            )
        }
        bug = serializer.save()
        for field, previous in before.items():
            current = getattr(bug, field)
            if previous != current:
                audit(
                    bug,
                    self.request,
                    f"Updated {field.replace('_', ' ')}",
                    field_name=field,
                    old_value=previous,
                    new_value=current,
                )

    def partial_update(self, request, *args, **kwargs):
        if "status" in request.data:
            return Response(
                {"status": "Use a workflow action to change bug status."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return super().partial_update(request, *args, **kwargs)

    def _input(self, serializer_class):
        serializer = serializer_class(data=self.request.data)
        serializer.is_valid(raise_exception=True)
        return serializer.validated_data

    @action(detail=True, methods=("post",))
    def triage(self, request, pk=None):
        bug = self.get_object()
        triage_bug(bug, request, self._input(NoteSerializer).get("note", ""))
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("post",))
    def assign(self, request, pk=None):
        bug = self.get_object()
        data = self._input(AssignmentInputSerializer)
        assignee = get_object_or_404(User, pk=data["user_id"], is_active=True)
        assign_bug(bug, request, assignee, data.get("note", ""))
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("post",))
    def reassign(self, request, pk=None):
        bug = self.get_object()
        data = self._input(AssignmentInputSerializer)
        assignee = get_object_or_404(User, pk=data["user_id"], is_active=True)
        assign_bug(bug, request, assignee, data.get("note", ""), reassign=True)
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("post",), url_path="start-work")
    def start_work_action(self, request, pk=None):
        bug = self.get_object()
        start_work(bug, request)
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("patch",))
    def engineering(self, request, pk=None):
        bug = self.get_object()
        serializer = BugEngineeringSerializer(data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        engineering = update_engineering(bug, request, serializer.validated_data)
        return Response(BugEngineeringSerializer(engineering, context={"request": request}).data)

    @action(detail=True, methods=("post",), url_path="submit-fix")
    def submit_fix_action(self, request, pk=None):
        bug = self.get_object()
        data = self._input(FixInputSerializer)
        submit_fix(bug, request, data["fix_notes"])
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("post",))
    def pr(self, request, pk=None):
        bug = self.get_object()
        engineering = update_pull_request(bug, request, self._input(PullRequestInputSerializer))
        return Response(BugEngineeringSerializer(engineering, context={"request": request}).data)

    @action(detail=True, methods=("post",))
    def ci(self, request, pk=None):
        bug = self.get_object()
        engineering = record_ci(bug, request, self._input(CIInputSerializer))
        return Response(BugEngineeringSerializer(engineering, context={"request": request}).data)

    @action(detail=True, methods=("post",))
    def deploy(self, request, pk=None):
        bug = self.get_object()
        deployment = record_deployment(bug, request, self._input(DeploymentInputSerializer))
        return Response(
            {
                "deployment": {
                    "id": deployment.pk,
                    "environment": deployment.environment,
                    "version": deployment.version,
                },
                "status": bug.status,
            }
        )

    @action(detail=True, methods=("post",), url_path="ready-for-retest")
    def ready_for_retest(self, request, pk=None):
        bug = self.get_object()
        mark_ready_for_retest(bug, request, self._input(NoteSerializer).get("note", ""))
        return Response(BugSerializer(bug, context={"request": request}).data)

    @action(detail=True, methods=("get", "post"))
    def retests(self, request, pk=None):
        bug = self.get_object()
        if request.method == "GET":
            return Response(
                BugRetestSerializer(bug.retests.select_related("retested_by"), many=True).data
            )
        require_capability(request.user, "BUG_RETEST")
        serializer = BugRetestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        retest = create_retest(bug, request, serializer.validated_data)
        return Response(BugRetestSerializer(retest).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=("get", "post"))
    def comments(self, request, pk=None):
        bug = self.get_object()
        if request.method == "GET":
            return Response(
                BugCommentSerializer(bug.comments.select_related("user"), many=True).data
            )
        serializer = BugCommentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        comment = add_comment(bug, request, serializer.validated_data["comment"])
        return Response(BugCommentSerializer(comment).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=("get",))
    def history(self, request, pk=None):
        bug = self.get_object()
        return Response(BugHistorySerializer(bug.history.select_related("user"), many=True).data)

    @action(detail=True, methods=("get", "post"), parser_classes=(MultiPartParser, FormParser))
    def attachments(self, request, pk=None):
        bug = self.get_object()
        if request.method == "GET":
            return Response(
                BugAttachmentSerializer(
                    bug.attachments.select_related("uploaded_by"),
                    many=True,
                    context={"request": request},
                ).data
            )
        require_capability(request.user, "BUG_VIEW")
        serializer = BugAttachmentSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        file = serializer.validated_data["file"]
        attachment = serializer.save(
            bug=bug,
            uploaded_by=request.user,
            original_name=file.name[:255],
            content_type=getattr(file, "content_type", "") or "application/octet-stream",
            size=file.size,
        )
        audit(bug, request, "Attachment uploaded", notes=attachment.original_name)
        return Response(
            BugAttachmentSerializer(attachment, context={"request": request}).data,
            status=status.HTTP_201_CREATED,
        )

    @extend_schema(
        parameters=[OpenApiParameter("attachment_id", OpenApiTypes.INT, OpenApiParameter.PATH)],
        responses={200: OpenApiTypes.BINARY},
    )
    @action(
        detail=True, methods=("get",), url_path=r"attachments/(?P<attachment_id>[0-9]+)/download"
    )
    def attachment_download(self, request, pk=None, attachment_id=None):
        bug = self.get_object()
        attachment = get_object_or_404(bug.attachments, pk=attachment_id)
        if not attachment.file:
            raise Http404
        response = FileResponse(
            attachment.file.open("rb"), as_attachment=True, filename=attachment.original_name
        )
        response["X-Content-Type-Options"] = "nosniff"
        return response

    @action(detail=True, methods=("post",))
    def reopen(self, request, pk=None):
        bug = self.get_object()
        reopen_bug(bug, request, self._input(NoteSerializer).get("note", ""))
        return Response(BugSerializer(bug, context={"request": request}).data)


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = NotificationSerializer
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return Notification.objects.none()
        return Notification.objects.filter(user=self.request.user).select_related("bug")

    @action(detail=True, methods=("patch",), url_path="read")
    def mark_read(self, request, pk=None):
        item = self.get_object()
        if not item.is_read:
            item.is_read = True
            item.read_at = timezone.now()
            item.save(update_fields=("is_read", "read_at"))
        return Response(NotificationSerializer(item).data)

    @action(detail=False, methods=("patch",), url_path="read-all")
    @extend_schema(request=None, responses=ReadAllResponseSerializer)
    def mark_all_read(self, request):
        Notification.objects.filter(user=request.user, is_read=False).update(
            is_read=True, read_at=timezone.now()
        )
        return Response({"updated": True})


class DashboardView(APIView):
    permission_classes = (IsAuthenticated, CapabilityPermission)
    required_capability = "REPORT_VIEW"

    @extend_schema(
        parameters=[
            OpenApiParameter(
                "kind",
                str,
                OpenApiParameter.PATH,
                enum=("manager", "qa", "tech-lead", "developer"),
            )
        ],
        responses={
            200: DashboardResponseSerializer,
            403: OpenApiResponse(description="Role cannot access this dashboard."),
            404: OpenApiResponse(description="Dashboard not found."),
        },
    )
    def get(self, request, kind):
        allowed = {
            "manager": {"MANAGER"},
            "qa": {"MANAGER", "QA"},
            "tech-lead": {"MANAGER", "QA", "TECH_LEAD"},
            "developer": {"MANAGER", "QA", "TECH_LEAD", "DEVELOPER"},
        }
        if kind not in allowed:
            return Response({"detail": "Dashboard not found."}, status=status.HTTP_404_NOT_FOUND)
        if (
            request.user.role_code not in allowed[kind]
            and request.user.role_code != "MANAGER"
            and not request.user.is_superuser
        ):
            raise PermissionDenied("You cannot view this role dashboard.")
        return Response(dashboard_data(request.user, kind))


def dashboard_data(user, kind):
    """Return the complete role dashboard model without hiding bug status from users.

    Personal work queues are role-scoped, while the common read-only status view contains
    every bug visible to a BUG_VIEW user. Workflow mutations remain protected separately.
    """
    all_bugs = Bug.objects.select_related(
        "project", "assigned_to", "reported_by", "tech_lead", "verified_by"
    )
    personal = all_bugs
    if kind == "developer":
        personal = all_bugs.filter(assigned_to=user)
    elif kind == "tech-lead":
        personal = all_bugs.filter(Q(tech_lead=user) | Q(triaged_by=user) | Q(reported_by=user))
    elif kind == "qa":
        personal = all_bugs.filter(Q(verified_by=user) | Q(reported_by=user))

    now = timezone.now()
    since = now - timedelta(days=30)
    open_all = all_bugs.exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID))
    closed_all = all_bugs.filter(status=Bug.Status.CLOSED)
    waiting_all = all_bugs.filter(status=Bug.Status.READY_FOR_RETEST)
    total = all_bugs.count()

    def distributions(qs):
        return (
            list(qs.values("status").annotate(count=Count("id")).order_by("status")),
            list(qs.values("severity").annotate(count=Count("id")).order_by("severity")),
            list(
                qs.values("project__name", "project__key")
                .annotate(count=Count("id"))
                .order_by("project__name")
            ),
        )

    status_source = personal if kind in {"qa", "developer"} else all_bugs
    by_status, by_severity, by_project = distributions(status_source)

    created_trend = {
        row["day"]: row["created"]
        for row in all_bugs.filter(created_at__gte=since)
        .annotate(day=TruncDate("created_at"))
        .values("day")
        .annotate(created=Count("id"))
    }
    closed_trend = {
        row["day"]: row["closed"]
        for row in all_bugs.filter(closed_at__isnull=False, closed_at__gte=since)
        .annotate(day=TruncDate("closed_at"))
        .values("day")
        .annotate(closed=Count("id"))
    }
    trend_days = sorted(set(created_trend) | set(closed_trend))
    trend = [
        {"day": day, "created": created_trend.get(day, 0), "closed": closed_trend.get(day, 0)}
        for day in trend_days
    ]

    workload = list(
        User.objects.filter(roles__code="DEVELOPER", is_active=True)
        .distinct()
        .annotate(
            assigned=Count(
                "assigned_bugs",
                filter=Q(assigned_bugs__in=all_bugs) & ~Q(assigned_bugs__status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)),
            ),
            in_development=Count(
                "assigned_bugs", filter=Q(assigned_bugs__status=Bug.Status.IN_DEVELOPMENT)
            ),
            retest=Count(
                "assigned_bugs", filter=Q(assigned_bugs__status=Bug.Status.READY_FOR_RETEST)
            ),
        )
        .values("id", "username", "first_name", "last_name", "assigned", "in_development", "retest")
        .order_by("username")
    )
    workload_rows = [
        {
            "Developer": f'{item["first_name"]} {item["last_name"]}'.strip() or item["username"],
            "Assigned": item["assigned"],
            "In Development": item["in_development"],
            "Retest": item["retest"],
            "Total": item["assigned"] + item["retest"],
        }
        for item in workload
    ]

    events = (
        BugHistory.objects.filter(bug__in=all_bugs)
        .select_related("user", "bug")
        .order_by("-created_at")[:12]
    )

    engineering = BugEngineering.objects.filter(bug__in=all_bugs)
    pr_status_distribution = list(
        engineering.values("pr_status").annotate(count=Count("id")).order_by("pr_status")
    )
    for row in pr_status_distribution:
        row["status"] = row.pop("pr_status")
    ci_distribution = list(
        engineering.values("ci_status").annotate(count=Count("id")).order_by("ci_status")
    )
    for row in ci_distribution:
        row["status"] = row.pop("ci_status")

    retests = list(
        BugRetest.objects.filter(bug__in=all_bugs)
        .select_related("bug")
        .prefetch_related("bug__deployments")
        .order_by("-retested_at")
    )
    durations = []
    for retest in retests:
        deployment_times = [
            deployment.deployed_at
            for deployment in retest.bug.deployments.all()
            if deployment.cycle == retest.cycle
        ]
        if deployment_times:
            elapsed = (retest.retested_at - max(deployment_times)).total_seconds() / 3600
            if elapsed >= 0:
                durations.append(elapsed)
    avg_hours = round(sum(durations) / len(durations), 1) if durations else None

    own = all_bugs.filter(reported_by=user)
    own_assigned = all_bugs.filter(assigned_to=user)
    closed_by_me = BugRetest.objects.filter(retested_by=user, test_result=BugRetest.Result.PASS).count()
    pass_count = BugRetest.objects.filter(bug__in=all_bugs, test_result=BugRetest.Result.PASS).count()
    retest_count = BugRetest.objects.filter(bug__in=all_bugs).count()

    reported_issues_qs = ReportedIssue.objects.filter(status=ReportedIssue.Status.AWAITING_QA).select_related("project", "reported_by")
    reported_issues = [
        {
            "id": item.id,
            "issue_key": item.issue_key,
            "title": item.title,
            "project_key": item.project.key,
            "reported_by": item.reported_by.get_full_name() or item.reported_by.username,
            "created_at": item.created_at.isoformat(),
        }
        for item in reported_issues_qs.order_by("created_at")[:20]
    ]

    ready_for_retest_bugs = list(
        waiting_all.select_related("project", "assigned_to", "verified_by")
        .order_by("created_at")[:20]
    )
    recently_reported = list(own.order_by("-created_at")[:10])
    my_assigned_bugs = list(own_assigned.exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)).order_by("-updated_at")[:20])
    developer_action_qs = own_assigned.exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)).order_by("-updated_at")
    pending_triage = list(all_bugs.filter(status__in=(Bug.Status.NEW, Bug.Status.IN_TRIAGE)).order_by("created_at")[:20])
    top_reopened = list(all_bugs.filter(is_reopened=True).order_by("-reopen_count", "-updated_at")[:10])
    overdue = list(
        open_all.filter(due_at__isnull=False, due_at__lt=now).order_by("due_at", "-severity")[:12]
    )
    aging = list(open_all.filter(created_at__lte=now - timedelta(days=7)).order_by("created_at")[:12])
    overdue_rows = overdue or aging

    def bug_rows(qs):
        return BugListSerializer(qs, many=True).data

    upcoming_qs = all_bugs.filter(
        due_at__isnull=False,
        due_at__gte=now,
    ).exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)).order_by("due_at")[:10]
    upcoming_deadlines = [
        {
            "Due Date": bug.due_at.strftime("%b %d, %Y") if bug.due_at else "—",
            "ID": bug.bug_key,
            "Title": bug.title,
            "Severity": bug.get_severity_display(),
            "Status": bug.get_status_display(),
        }
        for bug in upcoming_qs
    ]

    project_progress = []
    project_health = []
    for project in Project.objects.filter(is_active=True).order_by("name"):
        qs = all_bugs.filter(project=project)
        count = qs.count()
        closed = qs.filter(status=Bug.Status.CLOSED).count()
        open_count = qs.exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)).count()
        overdue_count = qs.filter(due_at__isnull=False, due_at__lt=now).exclude(status__in=(Bug.Status.CLOSED, Bug.Status.INVALID)).count()
        progress = round((closed / count) * 100) if count else 0
        health = "Delayed" if overdue_count >= 2 else ("Watch" if overdue_count or open_count >= 8 else "On Track")
        project_progress.append({
            "Project": project.name,
            "Bugs": count,
            "Closed": closed,
            "Open": open_count,
            "Progress": f"{progress}%",
            "Overdue": overdue_count,
        })
        project_health.append({
            "Project": project.name,
            "Status": health,
            "Bugs": count,
            "Progress": f"{progress}%",
            "Health": "Critical" if health == "Delayed" else ("Watch" if health == "Watch" else "Good"),
        })

    my_project_distribution = list(
        own_assigned.values("project__name", "project__key").annotate(count=Count("id")).order_by("-count")
    )
    my_project_distribution = [
        {"Project": row["project__name"], "Key": row["project__key"], "Assigned Bugs": row["count"]}
        for row in my_project_distribution
    ]

    qa_retest_trend = [
        {"date": row.retested_at.date().isoformat(), "result": row.test_result}
        for row in retests[:50]
    ]

    # Developer productivity by week for the reference dashboard.
    productivity = []
    if kind == "developer":
        for offset in range(4, -1, -1):
            start = (now - timedelta(days=7 * offset)).date()
            end = start + timedelta(days=7)
            assigned_count = BugAssignment.objects.filter(assigned_to=user, assigned_at__date__gte=start, assigned_at__date__lt=end).count()
            closed_count = BugRetest.objects.filter(retested_by=user, test_result=BugRetest.Result.PASS, retested_at__date__gte=start, retested_at__date__lt=end).count()
            productivity.append({"week": start.isoformat(), "assigned": assigned_count, "closed": closed_count})

    return {
        "role": kind,
        "kpis": {
            "total_projects": Project.objects.filter(is_active=True).count(),
            "team_members": User.objects.filter(is_active=True).count(),
            "total_bugs": total,
            "open_bugs": open_all.count(),
            "in_development": all_bugs.filter(status=Bug.Status.IN_DEVELOPMENT).count(),
            "new_bugs": all_bugs.filter(status=Bug.Status.NEW).count(),
            "fix_submitted": all_bugs.filter(status=Bug.Status.FIX_SUBMITTED).count(),
            "awaiting_pr": all_bugs.filter(status=Bug.Status.PR_REVIEW).count(),
            "ci_pending": all_bugs.filter(status=Bug.Status.CI_PENDING).count(),
            "deployed": all_bugs.filter(status=Bug.Status.DEPLOYED).count(),
            "ready_for_retest": waiting_all.count(),
            "closed_bugs": closed_all.count(),
            "reopened_bugs": all_bugs.filter(status=Bug.Status.REOPENED).count(),
            "critical_bugs": all_bugs.filter(severity=Bug.Severity.CRITICAL).count(),
            "high_priority_bugs": all_bugs.filter(priority__in=(Bug.Priority.P1, Bug.Priority.P2)).count(),
            "verification_rate": round(pass_count * 100 / retest_count, 1) if retest_count else 0,
            "average_retest_turnaround_hours": avg_hours,
            "aging_bugs": open_all.filter(created_at__lte=now - timedelta(days=7)).count(),
            "reported_by_me": own.count(),
            "assigned_to_me": (
                all_bugs.filter(tech_lead=user) if kind == "tech-lead"
                else all_bugs.filter(verified_by=user) if kind == "qa"
                else own_assigned
            ).exclude(status=Bug.Status.CLOSED).count(),
            "closed_by_me": closed_by_me,
            "failed_retests": BugRetest.objects.filter(bug__in=all_bugs, test_result=BugRetest.Result.FAIL).count(),
            "reported_issues_waiting": reported_issues_qs.count(),
        },
        "status_distribution": by_status,
        "severity_distribution": by_severity,
        "project_distribution": by_project,
        "team_workload": workload_rows,
        "trend": [{"date": row["day"].isoformat(), "created": row["created"], "closed": row["closed"]} for row in trend],
        "action_required": bug_rows(
            (waiting_all if kind == "qa" else developer_action_qs if kind == "developer" else pending_triage if kind == "tech-lead" else open_all.order_by("-updated_at"))[:10]
        ),
        "reported_issues": reported_issues,
        "recent_activity": [
            {
                "bug_key": event.bug.bug_key,
                "title": event.bug.title,
                "action": event.action,
                "user": event.user.get_full_name() or event.user.username,
                "created_at": event.created_at.isoformat(),
            }
            for event in events
        ],
        "qa_retest_trend": qa_retest_trend,
        "pr_status_distribution": pr_status_distribution,
        "ci_distribution": ci_distribution,
        "ready_for_retest_bugs": bug_rows(ready_for_retest_bugs),
        "recently_reported": bug_rows(recently_reported),
        "my_assigned_bugs": bug_rows(my_assigned_bugs),
        "pending_triage": bug_rows(pending_triage),
        "top_reopened": bug_rows(top_reopened),
        "overdue_bugs": bug_rows(overdue_rows),
        "upcoming_deadlines": upcoming_deadlines,
        "project_progress": project_progress,
        "project_health": project_health,
        "my_project_distribution": my_project_distribution,
        "productivity": productivity,
        "all_visible_bugs": bug_rows(all_bugs.order_by("-updated_at")[:20]),
    }




