from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    dependencies = [("portal", "0001_initial")]

    operations = [
        migrations.AddField(
            model_name="bug",
            name="tech_lead",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="technical_lead_bugs", to="portal.user"),
        ),
        migrations.AddField(
            model_name="bug",
            name="verified_by",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="verified_bugs", to="portal.user"),
        ),
        migrations.CreateModel(
            name="ReportedIssue",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("issue_key", models.CharField(blank=True, db_index=True, max_length=20, unique=True)),
                ("title", models.CharField(max_length=180)),
                ("description", models.TextField()),
                ("steps_to_reproduce", models.TextField(blank=True)),
                ("expected_result", models.TextField(blank=True)),
                ("actual_result", models.TextField(blank=True)),
                ("severity", models.CharField(choices=[("CRITICAL","Critical"),("HIGH","High"),("MEDIUM","Medium"),("LOW","Low")], default="MEDIUM", max_length=12)),
                ("priority", models.CharField(choices=[("P1","P1 · Urgent"),("P2","P2 · High"),("P3","P3 · Normal"),("P4","P4 · Low")], default="P3", max_length=2)),
                ("environment", models.CharField(blank=True, max_length=80)),
                ("application_version", models.CharField(blank=True, max_length=80)),
                ("status", models.CharField(choices=[("AWAITING_QA","Awaiting QA verification"),("REJECTED","Rejected / Not a bug"),("CONVERTED","Converted to official bug")], db_index=True, default="AWAITING_QA", max_length=24)),
                ("review_note", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("converted_bug", models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="source_issue", to="portal.bug")),
                ("project", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="reported_issues", to="portal.project")),
                ("reported_by", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="reported_issues", to="portal.user")),
                ("reviewed_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="reviewed_issues", to="portal.user")),
            ],
            options={"ordering": ("-created_at", "-id")},
        ),
    ]
