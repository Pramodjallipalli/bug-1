import uuid
from pathlib import Path

from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator, MaxValueValidator
from django.db import models
from django.utils import timezone


class Role(models.Model):
    code = models.CharField(max_length=24, unique=True)
    label = models.CharField(max_length=40)
    hierarchy_level = models.PositiveSmallIntegerField()
    permissions = models.ManyToManyField(
        "Permission", through="RolePermission", related_name="roles"
    )

    class Meta:
        ordering = ("-hierarchy_level", "label")

    def __str__(self):
        return self.label


class Permission(models.Model):
    code = models.CharField(max_length=48, unique=True)
    description = models.CharField(max_length=160)

    def __str__(self):
        return self.code


class RolePermission(models.Model):
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE)

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=("role", "permission"), name="uniq_role_permission")
        ]


class User(AbstractUser):
    roles = models.ManyToManyField(Role, through="UserRole", related_name="users")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def primary_role(self):
        return self.roles.order_by("-hierarchy_level", "code").first()

    @property
    def role_code(self):
        role = self.primary_role
        return role.code if role else ""

    @property
    def role_label(self):
        role = self.primary_role
        return role.label if role else "No role assigned"

    def has_capability(self, code):
        if self.is_superuser or self.roles.filter(code="MANAGER").exists():
            return True
        return self.roles.filter(permissions__code=code).exists()

    def __str__(self):
        return self.get_full_name() or self.username


class UserRole(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    role = models.ForeignKey(Role, on_delete=models.CASCADE)
    granted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=("user", "role"), name="uniq_user_role")]


class Project(models.Model):
    name = models.CharField(max_length=100, unique=True)
    key = models.CharField(max_length=16, unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="created_projects")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("name",)

    def __str__(self):
        return self.name



class ReportedIssue(models.Model):
    class Status(models.TextChoices):
        AWAITING_QA = "AWAITING_QA", "Awaiting QA verification"
        REJECTED = "REJECTED", "Rejected / Not a bug"
        CONVERTED = "CONVERTED", "Converted to official bug"

    issue_key = models.CharField(max_length=20, unique=True, blank=True, db_index=True)
    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="reported_issues")
    title = models.CharField(max_length=180)
    description = models.TextField()
    steps_to_reproduce = models.TextField(blank=True)
    expected_result = models.TextField(blank=True)
    actual_result = models.TextField(blank=True)
    severity = models.CharField(max_length=12, choices=[("CRITICAL","Critical"),("HIGH","High"),("MEDIUM","Medium"),("LOW","Low")], default="MEDIUM")
    priority = models.CharField(max_length=2, choices=[("P1","P1 · Urgent"),("P2","P2 · High"),("P3","P3 · Normal"),("P4","P4 · Low")], default="P3")
    environment = models.CharField(max_length=80, blank=True)
    application_version = models.CharField(max_length=80, blank=True)
    reported_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="reported_issues")
    status = models.CharField(max_length=24, choices=Status.choices, default=Status.AWAITING_QA, db_index=True)
    reviewed_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="reviewed_issues", null=True, blank=True)
    review_note = models.TextField(blank=True)
    converted_bug = models.OneToOneField("Bug", on_delete=models.PROTECT, related_name="source_issue", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-created_at", "-id")

    def save(self, *args, **kwargs):
        creating = self.pk is None
        super().save(*args, **kwargs)
        if creating and not self.issue_key:
            self.issue_key = f"ISSUE-{1000 + self.pk:04d}"
            super().save(update_fields=("issue_key",))

    def __str__(self):
        return f"{self.issue_key} · {self.title}"


class Bug(models.Model):
    class Status(models.TextChoices):
        NEW = "NEW", "New"
        IN_TRIAGE = "IN_TRIAGE", "In Triage"
        ASSIGNED = "ASSIGNED", "Assigned"
        IN_DEVELOPMENT = "IN_DEVELOPMENT", "In Development"
        FIX_SUBMITTED = "FIX_SUBMITTED", "Fix Submitted"
        PR_REVIEW = "PR_REVIEW", "PR Review"
        CI_PENDING = "CI_PENDING", "CI Pending"
        CI_PASSED = "CI_PASSED", "CI Passed"
        DEPLOYED = "DEPLOYED", "Deployed"
        READY_FOR_RETEST = "READY_FOR_RETEST", "Ready for Retest"
        QA_RETEST = "QA_RETEST", "QA Retest"
        REOPENED = "REOPENED", "Reopened"
        CLOSED = "CLOSED", "Closed"
        INVALID = "INVALID", "Invalid"

    class Severity(models.TextChoices):
        CRITICAL = "CRITICAL", "Critical"
        HIGH = "HIGH", "High"
        MEDIUM = "MEDIUM", "Medium"
        LOW = "LOW", "Low"

    class Priority(models.TextChoices):
        P1 = "P1", "P1 · Urgent"
        P2 = "P2", "P2 · High"
        P3 = "P3", "P3 · Normal"
        P4 = "P4", "P4 · Low"

    bug_key = models.CharField(max_length=20, unique=True, blank=True, db_index=True)
    project = models.ForeignKey(Project, on_delete=models.PROTECT, related_name="bugs")
    title = models.CharField(max_length=180)
    description = models.TextField()
    steps_to_reproduce = models.TextField(blank=True)
    expected_result = models.TextField(blank=True)
    actual_result = models.TextField(blank=True)
    severity = models.CharField(
        max_length=12, choices=Severity.choices, default=Severity.MEDIUM, db_index=True
    )
    priority = models.CharField(
        max_length=2, choices=Priority.choices, default=Priority.P3, db_index=True
    )
    status = models.CharField(
        max_length=24, choices=Status.choices, default=Status.NEW, db_index=True
    )
    reported_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="reported_bugs")
    triaged_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="triaged_bugs", null=True, blank=True
    )
    assigned_to = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="assigned_bugs",
        null=True,
        blank=True,
        db_index=True,
    )
    tech_lead = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="technical_lead_bugs",
        null=True,
        blank=True,
    )
    verified_by = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        related_name="verified_bugs",
        null=True,
        blank=True,
    )
    environment = models.CharField(max_length=80, blank=True)
    application_version = models.CharField(max_length=80, blank=True)
    is_reopened = models.BooleanField(default=False)
    reopen_count = models.PositiveSmallIntegerField(default=0)
    development_cycle = models.PositiveSmallIntegerField(default=0)
    due_at = models.DateTimeField(null=True, blank=True)
    closed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)

    class Meta:
        ordering = ("-updated_at", "-id")
        indexes = [
            models.Index(fields=("status", "severity"), name="bug_status_severity_idx"),
            models.Index(fields=("project", "created_at"), name="bug_project_created_idx"),
            models.Index(fields=("reported_by", "created_at"), name="bug_reporter_created_idx"),
        ]

    def save(self, *args, **kwargs):
        creating = self.pk is None
        super().save(*args, **kwargs)
        if creating and not self.bug_key:
            self.bug_key = f"BUG-{1000 + self.pk:04d}"
            super().save(update_fields=("bug_key",))

    def __str__(self):
        return f"{self.bug_key} · {self.title}"


class BugAssignment(models.Model):
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="assignments")
    assigned_to = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="bug_assignment_history"
    )
    assigned_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="bug_assignments_made"
    )
    note = models.CharField(max_length=240, blank=True)
    is_reassignment = models.BooleanField(default=False)
    assigned_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ("-assigned_at",)
        indexes = [models.Index(fields=("bug", "assigned_at"), name="assignment_bug_time_idx")]


class BugEngineering(models.Model):
    class PRStatus(models.TextChoices):
        NONE = "NONE", "Not submitted"
        OPEN = "OPEN", "Open"
        CHANGES_REQUESTED = "CHANGES_REQUESTED", "Changes requested"
        APPROVED = "APPROVED", "Approved"
        MERGED = "MERGED", "Merged"

    class CIStatus(models.TextChoices):
        NOT_RUN = "NOT_RUN", "Not run"
        PENDING = "PENDING", "Pending"
        PASSED = "PASSED", "Passed"
        FAILED = "FAILED", "Failed"

    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="engineering_cycles")
    cycle = models.PositiveSmallIntegerField()
    developer = models.ForeignKey(User, on_delete=models.PROTECT, related_name="engineering_work")
    branch_name = models.CharField(max_length=180, blank=True)
    commit_reference = models.CharField(max_length=120, blank=True)
    pull_request_url = models.URLField(max_length=500, blank=True)
    pr_status = models.CharField(max_length=24, choices=PRStatus.choices, default=PRStatus.NONE)
    ci_status = models.CharField(max_length=16, choices=CIStatus.choices, default=CIStatus.NOT_RUN)
    ci_link = models.URLField(max_length=500, blank=True)
    fix_notes = models.TextField(blank=True)
    fixed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ("-cycle",)
        constraints = [
            models.UniqueConstraint(fields=("bug", "cycle"), name="uniq_bug_engineering_cycle")
        ]
        indexes = [models.Index(fields=("bug", "cycle"), name="engineering_bug_cycle_idx")]


class BugDeploymentHistory(models.Model):
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="deployments")
    cycle = models.PositiveSmallIntegerField()
    environment = models.CharField(max_length=80)
    version = models.CharField(max_length=80, blank=True)
    deployed_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="deployments_recorded"
    )
    deployment_link = models.URLField(max_length=500, blank=True)
    deployed_at = models.DateTimeField(default=timezone.now, db_index=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ("-deployed_at",)
        indexes = [models.Index(fields=("bug", "deployed_at"), name="deployment_bug_time_idx")]


class BugRetest(models.Model):
    class Result(models.TextChoices):
        PASS = "PASS", "Pass"
        FAIL = "FAIL", "Fail"

    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="retests")
    cycle = models.PositiveSmallIntegerField()
    retested_by = models.ForeignKey(
        User, on_delete=models.PROTECT, related_name="retests_performed"
    )
    test_environment = models.CharField(max_length=80)
    test_version = models.CharField(max_length=80)
    test_steps = models.TextField()
    expected_result = models.TextField()
    actual_result = models.TextField()
    test_result = models.CharField(max_length=4, choices=Result.choices)
    remarks = models.TextField(blank=True)
    retested_at = models.DateTimeField(default=timezone.now, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-retested_at", "-id")
        indexes = [models.Index(fields=("bug", "retested_at"), name="retest_bug_time_idx")]


class BugStatusTransition(models.Model):
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="status_transitions")
    from_status = models.CharField(max_length=24, blank=True)
    to_status = models.CharField(max_length=24, choices=Bug.Status.choices)
    actor = models.ForeignKey(User, on_delete=models.PROTECT, related_name="status_transitions")
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ("created_at", "id")
        indexes = [models.Index(fields=("bug", "created_at"), name="transition_bug_time_idx")]


class BugHistory(models.Model):
    class Mode(models.TextChoices):
        MANAGER = "MANAGER", "Manager"
        QA = "QA", "QA"
        TECH_LEAD = "TECH_LEAD", "Tech Lead"
        DEVELOPER = "DEVELOPER", "Developer"
        QA_DEVELOPER = "QA_DEVELOPER_MODE", "QA + Developer Mode"
        LEAD_DEVELOPER = "LEAD_DEVELOPER_MODE", "Tech Lead + Developer Mode"

    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="history")
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bug_history")
    action = models.CharField(max_length=120)
    field_name = models.CharField(max_length=80, blank=True)
    old_value = models.TextField(blank=True)
    new_value = models.TextField(blank=True)
    performed_role = models.CharField(max_length=24, blank=True)
    performed_mode = models.CharField(max_length=32, choices=Mode.choices)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ("-created_at", "-id")
        indexes = [models.Index(fields=("bug", "created_at"), name="history_bug_time_idx")]


class BugComment(models.Model):
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="comments")
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bug_comments")
    comment = models.TextField(max_length=4000)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ("created_at", "id")


def bug_attachment_path(instance, filename):
    safe_name = Path(filename).name.replace(" ", "_")
    return f"bugs/{instance.bug.bug_key}/{uuid.uuid4().hex}_{safe_name}"


class BugAttachment(models.Model):
    ALLOWED_EXTENSIONS = ("png", "jpg", "jpeg", "gif", "pdf", "txt", "log", "csv")
    bug = models.ForeignKey(Bug, on_delete=models.CASCADE, related_name="attachments")
    file = models.FileField(
        upload_to=bug_attachment_path, validators=[FileExtensionValidator(ALLOWED_EXTENSIONS)]
    )
    original_name = models.CharField(max_length=255)
    content_type = models.CharField(max_length=120)
    size = models.PositiveIntegerField(validators=[MaxValueValidator(10 * 1024 * 1024)])
    uploaded_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bug_attachments")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ("-created_at",)


class Notification(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="notifications", db_index=True
    )
    bug = models.ForeignKey(
        Bug, on_delete=models.CASCADE, related_name="notifications", null=True, blank=True
    )
    title = models.CharField(max_length=160)
    body = models.CharField(max_length=500, blank=True)
    kind = models.CharField(max_length=48)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    read_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ("-created_at", "-id")
