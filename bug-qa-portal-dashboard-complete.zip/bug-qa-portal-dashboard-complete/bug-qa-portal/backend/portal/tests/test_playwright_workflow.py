import os
import re
from uuid import uuid4

import pytest
import requests

pytestmark = pytest.mark.skipif(
    not os.getenv("PLAYWRIGHT_BASE_URL"),
    reason="Set PLAYWRIGHT_BASE_URL when frontend and API are running.",
)


def _choose(page, label, value):
    page.get_by_role("combobox", name=label).click()
    page.get_by_text(value, exact=True).last.click()


def _open_nav(page, label):
    page.get_by_role("link", name=re.compile(f"{re.escape(label)}$")).click()


def _login(page, username, password, expected_heading):
    page.get_by_label("Username").fill(username)
    page.get_by_role("textbox", name="Password").fill(password)
    page.get_by_role("button", name="Sign in").click()
    page.get_by_role("heading", name=expected_heading).wait_for(timeout=20000)


def _logout(page):
    page.get_by_role("button", name=re.compile("Sign out")).click()
    page.get_by_role("button", name="Sign in").wait_for(timeout=20000)


def _open_bug_from_list(page, title, bug_key):
    _open_nav(page, "Bugs")
    page.get_by_role("heading", name="Bugs").wait_for()
    page.get_by_label("Search bugs").fill(title)
    page.get_by_role("button", name="Apply filters").click()
    page.get_by_role("button", name=title).click()
    page.get_by_role("heading", name=re.compile(re.escape(bug_key))).wait_for()


def _complete_development_cycle(page, bug_key, cycle):
    page.get_by_role("button", name="Start Development").click()
    page.get_by_label("Branch").wait_for()
    page.get_by_label("Branch").fill(f"fix/{bug_key.lower()}-cycle-{cycle}")
    page.get_by_label("Commit").fill(f"playwright-commit-{cycle}")
    page.get_by_label("Fix notes").fill(f"Browser verified implementation cycle {cycle}.")
    page.get_by_role("button", name="Save engineering details").click()
    page.get_by_role("button", name="Submit Fix").wait_for()
    page.get_by_label("Fix summary for review").fill(
        f"Browser verified implementation cycle {cycle}."
    )
    page.get_by_role("button", name="Submit Fix").click()

    page.get_by_label("Pull request URL").wait_for()
    page.get_by_label("Pull request URL").fill(
        f"https://github.com/example/bugtracker/pull/{cycle}"
    )
    _choose(page, "PR status", "MERGED")
    page.get_by_role("button", name="Save PR status").click()

    page.get_by_label("CI result").wait_for()
    # PASSED is the first configured CI option and is the form's safe default.
    page.get_by_label("CI run URL").fill(f"https://ci.example.test/runs/{cycle}")
    page.get_by_role("button", name="Record CI result").click()

    page.get_by_label("Version").wait_for()
    page.get_by_label("Version").fill(f"3.0.{cycle}")
    page.get_by_label("Deployment link").fill(f"https://deploy.example.test/releases/{cycle}")
    page.get_by_label("Deployment notes").fill(f"Playwright cycle {cycle} deployment.")
    page.get_by_role("button", name="Record Deployment").click()
    page.get_by_role("button", name="Ready for Retest").click()
    page.locator(".status-chip").filter(
        has_text=re.compile("Ready For Retest", re.IGNORECASE)
    ).wait_for(timeout=20000)


def _retest(page, title, bug_key, result):
    _open_nav(page, "Retest & Verify")
    page.get_by_role("heading", name="Retest & Verify").wait_for()
    page.get_by_role("button", name=title).click()
    page.get_by_role("heading", name=re.compile(re.escape(bug_key))).wait_for()
    page.get_by_role("button", name="Save QA Retest").wait_for()
    page.get_by_role("radiogroup", name="Retest result").get_by_text(result, exact=True).click()
    page.get_by_label("QA remarks").fill(f"Playwright retest result: {result}.")
    page.get_by_role("button", name="Save QA Retest").click()
    page.get_by_text("Reopened" if result == "FAIL" else "Closed", exact=True).wait_for(
        timeout=20000
    )


def test_qa_developer_fail_reopen_pass_lifecycle_in_browser(page):
    page.set_default_timeout(20000)
    base_url = os.environ["PLAYWRIGHT_BASE_URL"].rstrip("/")
    api_base = os.getenv("PLAYWRIGHT_API_BASE_URL", "http://127.0.0.1:8000/api").rstrip("/")
    password = os.environ["PLAYWRIGHT_PASSWORD"]
    title = f"Browser lifecycle {uuid4().hex[:8]}"

    page.goto(base_url, wait_until="domcontentloaded")
    page.get_by_text("Welcome to BugTracker").wait_for()
    _login(page, "qa", password, "QA Dashboard")

    _open_nav(page, "Report Issue")
    page.get_by_role("heading", name="Report an Issue").wait_for()
    page.get_by_label("Issue title").fill(title)
    page.get_by_label("Description").fill("A complete lifecycle driven through the browser.")
    page.get_by_label("Steps to reproduce").fill("Open the route and submit a request.")
    page.get_by_label("Expected result").fill("The request succeeds.")
    page.get_by_label("Actual result").fill("The request currently fails.")
    page.get_by_label("Environment").fill("Staging")
    page.get_by_label("Application version").fill("3.0.0")
    page.get_by_role("button", name="Submit Issue for QA Review").click()

    _open_nav(page, "Verify Reported Issues")
    page.get_by_role("heading", name="Verify Reported Issues").wait_for()
    issue_link = page.get_by_text(re.compile(r"ISSUE-\d+"))
    issue_link.first.wait_for()
    page.get_by_label("Tech Lead").first.wait_for()
    _choose(page, "Tech Lead", "Rahul Verma")
    _choose(page, "Developer", "Rahul Mehta")
    page.get_by_label("QA verification note").fill("Reproduced and verified.")
    page.get_by_role("button", name="✓ Verify & Create Official Bug").click()
    open_link = page.get_by_role("link", name=re.compile(r"Open BUG-\d+"))
    open_link.wait_for()
    bug_key = re.search(r"BUG-\d+", open_link.inner_text()).group(0)
    open_link.click()
    page.get_by_role("heading", name=re.compile(re.escape(bug_key))).wait_for()
    page.get_by_role("button", name="Triage bug").wait_for()
    page.get_by_label("Triage note").fill("Confirmed bug; routed to technical owners.")
    page.get_by_role("button", name="Triage bug").click()

    _logout(page)
    _login(page, "rahul", password, "Developer Dashboard")
    _open_bug_from_list(page, title, bug_key)
    _complete_development_cycle(page, bug_key, 1)

    _logout(page)
    _login(page, "qa", password, "QA Dashboard")
    _retest(page, title, bug_key, "FAIL")

    page.get_by_role("tab", name="Comments").click()
    comment = f"QA evidence for {bug_key}: the issue remains reproducible."
    page.get_by_label("Add a comment").fill(comment)
    page.get_by_role("button", name="Post comment").click()
    page.get_by_text(comment, exact=True).wait_for(timeout=20000)

    page.get_by_role("tab", name="Attachments").click()
    page.locator('input[type="file"]').set_input_files(
        {"name": "qa-evidence.txt", "mimeType": "text/plain", "buffer": b"Reproduced in Staging."}
    )
    page.get_by_role("button", name="Upload file").click()
    page.get_by_text("qa-evidence.txt").wait_for(timeout=20000)

    _logout(page)
    _login(page, "rahul", password, "Developer Dashboard")
    _open_bug_from_list(page, title, bug_key)
    _complete_development_cycle(page, bug_key, 2)

    _logout(page)
    _login(page, "qa", password, "QA Dashboard")
    _retest(page, title, bug_key, "PASS")

    api = requests.Session()
    login = api.post(
        f"{api_base}/auth/login/", json={"username": "qa", "password": password}, timeout=15
    )
    assert login.status_code == 200, login.text
    api.headers.update({"Authorization": f"Bearer {login.json()['access']}"})
    bugs = api.get(f"{api_base}/bugs/", params={"search": title}, timeout=15)
    assert bugs.status_code == 200, bugs.text
    matches = [item for item in bugs.json()["results"] if item["bug_key"] == bug_key]
    assert len(matches) == 1
    bug = api.get(f"{api_base}/bugs/{matches[0]['id']}/", timeout=15)
    assert bug.status_code == 200, bug.text
    assert bug.json()["status"] == "CLOSED"
    assert {item["test_result"] for item in bug.json()["retests"]} == {"FAIL", "PASS"}
    assert len(bug.json()["retests"]) == 2
    assert len(bug.json()["deployments"]) == 2
    attachments = api.get(f"{api_base}/bugs/{matches[0]['id']}/attachments/", timeout=15)
    assert attachments.status_code == 200, attachments.text
    assert any(item["original_name"] == "qa-evidence.txt" for item in attachments.json())
    comments = api.get(f"{api_base}/bugs/{matches[0]['id']}/comments/", timeout=15)
    assert comments.status_code == 200, comments.text
    assert any(item["comment"].startswith("QA evidence") for item in comments.json())
    history = api.get(f"{api_base}/bugs/{matches[0]['id']}/history/", timeout=15)
    assert history.status_code == 200, history.text
    assert any("REOPENED" in item["action"] for item in history.json())
