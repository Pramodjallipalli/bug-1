import plotly.express as px
import streamlit as st

import api_client
import ui


def _chart_theme(fig):
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font={"color": "#d3e2ef", "family": "DM Sans"},
        margin={"l": 8, "r": 8, "t": 18, "b": 8},
        legend={"orientation": "h", "y": -0.22, "font": {"size": 10}},
    )
    fig.update_xaxes(gridcolor="#16344d", zerolinecolor="#16344d")
    fig.update_yaxes(gridcolor="#16344d", zerolinecolor="#16344d")
    return fig


def _open_bug(bug_id):
    st.session_state["selected_bug_id"] = bug_id
    st.switch_page("pages/bug_details.py")


def _status_chart(rows, title="Bug Status Distribution"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if rows:
        fig = px.pie(
            rows,
            names="status",
            values="count",
            hole=0.62,
            color="status",
            color_discrete_map=ui.STATUS_COLORS,
        )
        fig.update_traces(textposition="outside", textinfo="label+value")
        fig.update_layout(showlegend=False)
        st.plotly_chart(_chart_theme(fig), width="stretch", key=f"status_chart_{title}")
    else:
        st.info("No bug data yet.")
    st.markdown("</div>", unsafe_allow_html=True)


def _severity_chart(rows, title="Severity Distribution"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if rows:
        fig = px.bar(
            rows,
            x="severity",
            y="count",
            color="severity",
            text="count",
            color_discrete_map={
                "CRITICAL": "#ff526a",
                "HIGH": "#ff8129",
                "MEDIUM": "#f3c431",
                "LOW": "#04c99a",
            },
        )
        fig.update_traces(textposition="outside")
        fig.update_layout(showlegend=False)
        st.plotly_chart(_chart_theme(fig), width="stretch", key=f"severity_chart_{title}")
    else:
        st.info("No severity data yet.")
    st.markdown("</div>", unsafe_allow_html=True)


def _project_chart(rows, title="Bugs by Project"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if rows:
        fig = px.bar(rows, x="count", y="project__name", orientation="h", text="count", color_discrete_sequence=["#148cff"])
        fig.update_traces(textposition="outside")
        fig.update_layout(yaxis_title=None, xaxis_title=None)
        st.plotly_chart(_chart_theme(fig), width="stretch", key=f"project_chart_{id(fig)}")
    else:
        st.info("No project activity yet.")
    st.markdown("</div>", unsafe_allow_html=True)


def _trend_chart(rows, title="Bug Trend · Last 30 Days"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if rows:
        fig = px.line(rows, x="date", y=["created", "closed"], markers=True)
        fig.update_layout(xaxis_title=None, yaxis_title="Bugs", legend={"orientation": "h", "y": -0.22})
        st.plotly_chart(_chart_theme(fig), width="stretch", key=f"trend_chart_{title}")
    else:
        st.info("No recent bug reports.")
    st.markdown("</div>", unsafe_allow_html=True)


def _open_bug_table(rows, title, action_label="Open"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if not rows:
        st.info("Nothing to show.")
    else:
        header = st.columns([0.12, 0.31, 0.13, 0.13, 0.17, 0.14])
        for col, label in zip(header, ("ID", "Title", "Project", "Severity", "Status", "Action"), strict=False):
            col.markdown(f"**{label}**")
        for bug in rows[:12]:
            cols = st.columns([0.12, 0.31, 0.13, 0.13, 0.17, 0.14])
            cols[0].markdown(f'`{bug["bug_key"]}`')
            cols[1].write(bug["title"])
            cols[2].write(bug.get("project_key", "—"))
            cols[3].write(str(bug.get("severity", "—")).title())
            cols[4].markdown(ui.status_chip(bug.get("status", "")), unsafe_allow_html=True)
            if cols[5].button(action_label, key=f"dash-row-{title}-{bug['id']}"):
                _open_bug(bug["id"])
    st.markdown("</div>", unsafe_allow_html=True)


def _action_required(rows):
    st.markdown('<div class="panel"><h3>Action Required</h3>', unsafe_allow_html=True)
    if rows:
        for bug in rows[:8]:
            a, b, c = st.columns([0.18, 0.60, 0.22])
            a.markdown(f'<span class="bug-key">{bug["bug_key"]}</span>', unsafe_allow_html=True)
            b.markdown(f'{bug["title"]}<br><small>{bug["status"].replace("_", " ").title()}</small>', unsafe_allow_html=True)
            if c.button("Open", key=f"dash-open-{bug['id']}"):
                _open_bug(bug["id"])
    else:
        st.success("No items need immediate action.")
    st.markdown("</div>", unsafe_allow_html=True)


def _recent_activity(items, title="Recent Activity"):
    st.markdown(f'<div class="panel"><h3>{title}</h3>', unsafe_allow_html=True)
    if not items:
        st.info("No recent activity.")
    for item in items[:10]:
        st.markdown(
            f'`{item["bug_key"]}` · **{item["user"]}** {item["action"]}<br>'
            f'<small>{item["title"]} · {item["created_at"][:16].replace("T", " ")} UTC</small>',
            unsafe_allow_html=True,
        )
    st.markdown("</div>", unsafe_allow_html=True)


def _metric_row(cards):
    cols = st.columns(len(cards))
    for col, (label, value, help_text) in zip(cols, cards, strict=False):
        with col:
            st.metric(label, value, help=help_text)


def _role_kpis(kind, k):
    if kind == "manager":
        return [
            ("Total Projects", k["total_projects"], "Active and visible projects"),
            ("Total Bugs", k["total_bugs"], "All official bugs"),
            ("Closed Bugs", k["closed_bugs"], "QA-passed and closed"),
            ("Team Members", k["team_members"], "Active users"),
        ]
    if kind == "qa":
        return [
            ("Bugs Reported by Me", k["reported_by_me"], "Official bugs reported/owned by you"),
            ("Assigned to Me", k["assigned_to_me"], "Bugs assigned for QA visibility"),
            ("Ready for Retest", k["ready_for_retest"], "Developer fixes waiting for QA"),
            ("Closed by Me", k["closed_by_me"], "Successful QA retests"),
        ]
    if kind == "tech-lead":
        return [
            ("New Bugs", k["new_bugs"], "Bugs waiting for triage"),
            ("Assigned", k["assigned_to_me"], "Bugs under your technical ownership"),
            ("In Development", k["in_development"], "Team bugs being worked on"),
            ("Awaiting Retest", k["ready_for_retest"], "Fixed and waiting for QA"),
            ("Closed", k["closed_bugs"], "Completed bugs"),
        ]
    return [
        ("Assigned to Me", k["assigned_to_me"], "Your assigned bugs"),
        ("In Progress", k["in_development"], "Bugs currently in development"),
        ("Fix Submitted", k["fix_submitted"], "Fixes submitted for review"),
        ("Deployed", k["deployed"], "Fixes deployed"),
        ("Closed", k["closed_bugs"], "QA-passed and closed"),
    ]


def render():
    user = api_client.current_user()
    role = user.get("role_code", "DEVELOPER")
    kind = {"MANAGER": "manager", "QA": "qa", "TECH_LEAD": "tech-lead", "DEVELOPER": "developer"}.get(role, "developer")
    try:
        data = api_client.request("GET", f"dashboard/{kind}/")
    except api_client.APIError as exc:
        ui.heading("Dashboard", "Live data from your BugTracker workspace", role)
        ui.friendly_error(exc)
        return

    titles = {"manager": "Operations Overview", "qa": "QA Dashboard", "tech-lead": "Tech Lead Dashboard", "developer": "Developer Dashboard"}
    subtitles = {
        "manager": "Supervise projects, bugs, team workload, quality, and delivery.",
        "qa": "Report issues, verify official bugs, retest fixes, and monitor quality.",
        "tech-lead": "Triage, assign, lead development, and track team delivery.",
        "developer": "Work on assigned bugs, track fixes, PRs, CI, deployment, and QA readiness.",
    }
    ui.heading(titles[kind], subtitles[kind], role)
    action_cols = st.columns(3 if kind in {"manager", "tech-lead", "developer"} else 2)
    if action_cols[0].button("＋ Report an Issue", type="primary", key=f"report-issue-{kind}"):
        st.switch_page("pages/report_bug.py")
    if kind == "manager":
        if action_cols[1].button("＋ New Project", key="manager-new-project"):
            st.switch_page("pages/projects.py")
        if action_cols[2].button("📊 Reports & Analytics", key="manager-reports"):
            st.switch_page("pages/reports.py")
    elif kind == "tech-lead":
        if action_cols[1].button("🧭 Triage Bug", key="lead-triage"):
            st.switch_page("pages/triage.py")
        if action_cols[2].button("📊 Reports & Analytics", key="lead-reports"):
            st.switch_page("pages/reports.py")
    elif kind == "developer":
        if action_cols[1].button("↕ Update Status / My Bugs", key="dev-update-status"):
            st.switch_page("pages/bugs.py")
        if action_cols[2].button("🔧 Fix / PR / CI / Deployment", key="dev-engineering"):
            st.switch_page("pages/development.py")
    else:
        if action_cols[1].button("🧪 Retest & Verify", key="qa-retest"):
            st.switch_page("pages/retest.py")
    k = data["kpis"]
    _metric_row(_role_kpis(kind, k))

    # Secondary KPIs preserve the information density of the four reference dashboards.
    if kind == "manager":
        _metric_row([
            ("Open Bugs", k["open_bugs"], "Not closed or invalid"),
            ("In Development", k["in_development"], "Currently being fixed"),
            ("Ready for Retest", k["ready_for_retest"], "Waiting for QA"),
            ("Reopened", k["reopened_bugs"], "Failed or reopened work"),
            ("Critical", k["critical_bugs"], "Critical severity"),
            ("Overdue / Aging", k["aging_bugs"], "Open longer than the aging threshold"),
        ])
    elif kind == "qa":
        _metric_row([
            ("Issues Awaiting Verification", k["reported_issues_waiting"], "Reported issues not yet verified"),
            ("Reopened", k["reopened_bugs"], "Bugs returned after QA failure"),
            ("Verification Rate", f'{k["verification_rate"]}%', "PASS results / completed retests"),
            ("Avg Retest Turnaround", f'{k["average_retest_turnaround_hours"]}h' if k["average_retest_turnaround_hours"] is not None else "—", "Deployment to retest"),
            ("Critical", k["critical_bugs"], "Critical severity"),
            ("High Priority", k["high_priority_bugs"], "P1/P2 priority"),
        ])
    elif kind == "tech-lead":
        _metric_row([
            ("Awaiting PR", k["awaiting_pr"], "PR review stage"),
            ("CI Pending", k["ci_pending"], "Waiting for CI"),
            ("Reopened", k["reopened_bugs"], "Needs another development cycle"),
            ("Critical", k["critical_bugs"], "Critical severity"),
            ("Overdue / Aging", k["aging_bugs"], "Open longer than the aging threshold"),
        ])
    else:
        _metric_row([
            ("PR / CI Work", k["awaiting_pr"] + k["ci_pending"], "PR review + CI pending"),
            ("Ready for Retest", k["ready_for_retest"], "Waiting for QA"),
            ("Reopened", k["reopened_bugs"], "Returned from QA"),
            ("Critical / High", k["critical_bugs"] + k["high_priority_bugs"], "Priority attention"),
        ])

    # Reference-dashboard chart row.
    left, mid, right = st.columns(3)
    with left:
        _status_chart(data["status_distribution"], "My Bugs by Status" if kind in {"qa", "developer"} else "Bugs by Status (All Projects)")
    with mid:
        _severity_chart(data["severity_distribution"], "Bugs by Severity" if kind != "qa" else "Bugs by Severity (My Bugs)")
    with right:
        if kind in {"qa", "manager"}:
            rows = data.get("qa_retest_trend", [])
            st.markdown('<div class="panel"><h3>Retest Result Trend</h3>', unsafe_allow_html=True)
            if rows:
                fig = px.histogram(rows, x="date", color="result", barmode="group", color_discrete_map={"PASS": "#11c79b", "FAIL": "#ff526a"})
                fig.update_layout(xaxis_title=None, yaxis_title="Retests")
                st.plotly_chart(_chart_theme(fig), width="stretch", key="qa_retest_trend_chart")
            else:
                st.info("No retest history yet.")
            st.markdown('</div>', unsafe_allow_html=True)
        elif kind == "developer":
            rows = data.get("pr_status_distribution", [])
            st.markdown('<div class="panel"><h3>PR Status</h3>', unsafe_allow_html=True)
            if rows:
                fig = px.bar(rows, x="status", y="count", text="count", color="status")
                fig.update_traces(textposition="outside")
                fig.update_layout(showlegend=False, xaxis_title=None, yaxis_title=None)
                st.plotly_chart(_chart_theme(fig), width="stretch", key="developer_pr_chart")
            else:
                st.info("No PR activity yet.")
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            rows = data.get("pr_status_distribution", [])
            st.markdown('<div class="panel"><h3>Engineering Pipeline</h3>', unsafe_allow_html=True)
            if rows:
                fig = px.bar(rows, x="status", y="count", text="count", color="status")
                fig.update_traces(textposition="outside")
                fig.update_layout(showlegend=False, xaxis_title=None, yaxis_title=None)
                st.plotly_chart(_chart_theme(fig), width="stretch", key="developer_ci_chart")
            else:
                st.info("No engineering activity yet.")
            st.markdown('</div>', unsafe_allow_html=True)

    # Project and workload/progress modules.
    if kind == "manager":
        st.markdown('<div class="panel"><h3>Project Progress Overview</h3>', unsafe_allow_html=True)
        progress = data.get("project_progress", [])
        if progress:
            st.dataframe(progress, hide_index=True, width="stretch")
        else:
            st.info("No project progress yet.")
        st.markdown('</div>', unsafe_allow_html=True)
        left, right = st.columns([1.1, 0.9])
        with left:
            _project_chart(data["project_distribution"], "Bugs by Project")
        with right:
            st.markdown('<div class="panel"><h3>Team Workload (Open Bugs)</h3>', unsafe_allow_html=True)
            st.dataframe(data.get("team_workload", []), hide_index=True, width="stretch")
            st.markdown('</div>', unsafe_allow_html=True)
    else:
        left, right = st.columns([1.25, 0.75])
        with left:
            _project_chart(data["project_distribution"], "Bugs by Project")
        with right:
            st.markdown('<div class="panel"><h3>Team Workload</h3>', unsafe_allow_html=True)
            if data["team_workload"]:
                st.dataframe(data["team_workload"], hide_index=True, width="stretch")
            else:
                st.info("No developer assignments yet.")
            st.markdown('</div>', unsafe_allow_html=True)

    # Trend + action queue.
    left, right = st.columns(2)
    with left:
        _trend_chart(data["trend"])
    with right:
        _action_required(data["action_required"])

    # Role-specific operational tables.
    if kind == "manager":
        left, right = st.columns(2)
        with left:
            _recent_activity(data["recent_activity"], "Recent Activity")
        with right:
            _open_bug_table(data.get("overdue_bugs", []), "Overdue / Aging Bugs")
        left, right = st.columns(2)
        with left:
            _project_chart(data["project_distribution"], "Bugs by Project")
        with right:
            st.markdown('<div class="panel"><h3>Project Health</h3>', unsafe_allow_html=True)
            st.dataframe(data.get("project_health", []), hide_index=True, width="stretch")
            st.markdown('</div>', unsafe_allow_html=True)

    elif kind == "qa":
        _open_bug_table(data.get("ready_for_retest_bugs", []), "Ready for Retest (Action Required)", "Retest")
        left, right = st.columns(2)
        with left:
            _open_bug_table(data.get("recently_reported", []), "My Recently Reported Bugs")
        with right:
            st.markdown('<div class="panel"><h3>Upcoming Deadlines (QA)</h3>', unsafe_allow_html=True)
            st.dataframe(data.get("upcoming_deadlines", []), hide_index=True, width="stretch")
            st.markdown('</div>', unsafe_allow_html=True)
        _recent_activity(data["recent_activity"], "Recent QA Activity")
        if data.get("reported_issues"):
            st.markdown('<div class="panel"><h3>Reported Issues Awaiting QA Verification</h3>', unsafe_allow_html=True)
            st.dataframe(data["reported_issues"], hide_index=True, width="stretch")
            if st.button("Open QA verification queue", key="open-issue-queue"):
                st.switch_page("pages/verify_issues.py")
            st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.success("No reported issues are waiting for verification.")

    elif kind == "tech-lead":
        _open_bug_table(data.get("pending_triage", []), "Pending Triage", "Triage")
        left, right = st.columns(2)
        with left:
            _open_bug_table(data.get("top_reopened", []), "Top Reopened Bugs")
        with right:
            _open_bug_table(data.get("overdue_bugs", []), "Overdue / Aging Bugs")
        _recent_activity(data["recent_activity"], "Recent Technical Activity")

    else:
        _open_bug_table(data.get("my_assigned_bugs", []), "My Assigned Bugs", "Update")
        left, right = st.columns(2)
        with left:
            st.markdown('<div class="panel"><h3>My Upcoming Deadlines</h3>', unsafe_allow_html=True)
            st.dataframe(data.get("upcoming_deadlines", []), hide_index=True, width="stretch")
            st.markdown('</div>', unsafe_allow_html=True)
        with right:
            st.markdown('<div class="panel"><h3>Bugs by Project (Assigned to Me)</h3>', unsafe_allow_html=True)
            st.dataframe(data.get("my_project_distribution", []), hide_index=True, width="stretch")
            st.markdown('</div>', unsafe_allow_html=True)
        st.markdown('<div class="panel"><h3>CI Results</h3>', unsafe_allow_html=True)
        ci = data.get("ci_distribution", [])
        if ci:
            fig = px.pie(ci, names="status", values="count", hole=0.6, color="status")
            fig.update_layout(showlegend=True)
            st.plotly_chart(_chart_theme(fig), width="stretch", key="dashboard_secondary_chart_1")
        else:
            st.info("No CI builds yet.")
        st.markdown('</div>', unsafe_allow_html=True)
        _recent_activity(data["recent_activity"], "Recent Activity (Team)")
        st.markdown('<div class="panel"><h3>My Productivity</h3>', unsafe_allow_html=True)
        productivity = data.get("productivity", [])
        if productivity:
            fig = px.line(productivity, x="week", y=["assigned", "closed"], markers=True)
            fig.update_layout(xaxis_title=None, yaxis_title="Bugs")
            st.plotly_chart(_chart_theme(fig), width="stretch", key="dashboard_secondary_chart_2")
        else:
            st.info("No productivity history yet.")
        st.markdown('</div>', unsafe_allow_html=True)

    # Everyone gets a common read-only status view. Actions remain role-controlled in Bug Details.
    _open_bug_table(data.get("all_visible_bugs", []), "All Visible Bugs · Current Status", "View")


render()



