from pathlib import Path

from django.contrib.auth.password_validation import validate_password
from rest_framework import serializers

from .models import (
    Bug,
    BugAssignment,
    BugAttachment,
    BugComment,
    BugDeploymentHistory,
    BugEngineering,
    BugHistory,
    BugRetest,
    BugStatusTransition,
    Notification,
    Project,
    ReportedIssue,
    Role,
    User,
)


class UserSummarySerializer(serializers.ModelSerializer):
    full_name = serializers.SerializerMethodField()
    role = serializers.CharField(source="role_label", read_only=True)
    role_code = serializers.CharField(read_only=True)

    class Meta:
        model = User
        fields = ("id", "username", "email", "full_name", "role", "role_code", "is_active")

    def get_full_name(self, obj) -> str:
        return obj.get_full_name() or obj.username


class UserCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, validators=[validate_password])
    role_code = serializers.SlugRelatedField(
        source="roles", slug_field="code", queryset=Role.objects.all(), write_only=True
    )

    class Meta:
        model = User
        fields = (
            "id",
            "username",
            "email",
            "first_name",
            "last_name",
            "password",
            "role_code",
            "is_active",
        )
        read_only_fields = ("id",)

    def create(self, validated_data):
        role = validated_data.pop("roles")
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        user.roles.add(role)
        return user


class ProjectSerializer(serializers.ModelSerializer):
    created_by = UserSummarySerializer(read_only=True)

    class Meta:
        model = Project
        fields = (
            "id",
            "name",
            "key",
            "description",
            "is_active",
            "created_by",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "created_by", "created_at", "updated_at")


class BugEngineeringSerializer(serializers.ModelSerializer):
    developer = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugEngineering
        fields = (
            "id",
            "cycle",
            "developer",
            "branch_name",
            "commit_reference",
            "pull_request_url",
            "pr_status",
            "ci_status",
            "ci_link",
            "fix_notes",
            "fixed_at",
            "created_at",
            "updated_at",
        )
        read_only_fields = (
            "id",
            "cycle",
            "developer",
            "pr_status",
            "ci_status",
            "fixed_at",
            "created_at",
            "updated_at",
        )


class BugAssignmentSerializer(serializers.ModelSerializer):
    assigned_to = UserSummarySerializer(read_only=True)
    assigned_by = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugAssignment
        fields = ("id", "assigned_to", "assigned_by", "note", "is_reassignment", "assigned_at")


class BugDeploymentSerializer(serializers.ModelSerializer):
    deployed_by = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugDeploymentHistory
        fields = (
            "id",
            "cycle",
            "environment",
            "version",
            "deployed_by",
            "deployment_link",
            "deployed_at",
            "notes",
        )


class BugRetestSerializer(serializers.ModelSerializer):
    retested_by = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugRetest
        fields = (
            "id",
            "cycle",
            "retested_by",
            "test_environment",
            "test_version",
            "test_steps",
            "expected_result",
            "actual_result",
            "test_result",
            "remarks",
            "retested_at",
            "created_at",
        )
        read_only_fields = ("id", "cycle", "retested_by", "retested_at", "created_at")


class BugHistorySerializer(serializers.ModelSerializer):
    user = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugHistory
        fields = (
            "id",
            "user",
            "action",
            "field_name",
            "old_value",
            "new_value",
            "performed_role",
            "performed_mode",
            "notes",
            "created_at",
        )


class BugStatusTransitionSerializer(serializers.ModelSerializer):
    actor = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugStatusTransition
        fields = ("id", "from_status", "to_status", "actor", "note", "created_at")


class BugCommentSerializer(serializers.ModelSerializer):
    user = UserSummarySerializer(read_only=True)

    class Meta:
        model = BugComment
        fields = ("id", "user", "comment", "created_at")
        read_only_fields = ("id", "user", "created_at")


class BugAttachmentSerializer(serializers.ModelSerializer):
    uploaded_by = UserSummarySerializer(read_only=True)
    download_url = serializers.SerializerMethodField()
    file = serializers.FileField(write_only=True, required=True)

    class Meta:
        model = BugAttachment
        fields = (
            "id",
            "file",
            "original_name",
            "content_type",
            "size",
            "uploaded_by",
            "created_at",
            "download_url",
        )
        read_only_fields = (
            "id",
            "original_name",
            "content_type",
            "size",
            "uploaded_by",
            "created_at",
            "download_url",
        )

    def validate_file(self, file):
        allowed = {"png", "jpg", "jpeg", "gif", "pdf", "txt", "log", "csv"}
        extension = Path(file.name).suffix.lower().lstrip(".")
        if extension not in allowed:
            raise serializers.ValidationError("Allowed files: PNG, JPG, GIF, PDF, TXT, LOG, CSV.")
        if file.size > 10 * 1024 * 1024:
            raise serializers.ValidationError("Files must be 10 MB or smaller.")
        content_type = getattr(file, "content_type", "") or "application/octet-stream"
        if content_type not in {
            "image/png",
            "image/jpeg",
            "image/gif",
            "application/pdf",
            "text/plain",
            "text/csv",
            "application/octet-stream",
        }:
            raise serializers.ValidationError("This file type is not supported.")
        signatures = {
            "png": lambda data: data.startswith(b"\x89PNG\r\n\x1a\n"),
            "jpg": lambda data: data.startswith(b"\xff\xd8\xff"),
            "jpeg": lambda data: data.startswith(b"\xff\xd8\xff"),
            "gif": lambda data: data.startswith((b"GIF87a", b"GIF89a")),
            "pdf": lambda data: data.startswith(b"%PDF-"),
        }
        if extension in signatures:
            position = file.tell()
            header = file.read(12)
            file.seek(position)
            if not signatures[extension](header):
                raise serializers.ValidationError("The file content does not match its extension.")
        return file

    def get_download_url(self, obj):
        request = self.context.get("request")
        path = f"/api/bugs/{obj.bug_id}/attachments/{obj.id}/download/"
        return request.build_absolute_uri(path) if request else path


class BugSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)
    project_key = serializers.CharField(source="project.key", read_only=True)
    reported_by = UserSummarySerializer(read_only=True)
    triaged_by = UserSummarySerializer(read_only=True)
    assigned_to = UserSummarySerializer(read_only=True)
    tech_lead = UserSummarySerializer(read_only=True)
    verified_by = UserSummarySerializer(read_only=True)
    assignments = BugAssignmentSerializer(many=True, read_only=True)
    engineering = BugEngineeringSerializer(source="engineering_cycles", many=True, read_only=True)
    deployments = BugDeploymentSerializer(many=True, read_only=True)
    retests = BugRetestSerializer(many=True, read_only=True)
    history_count = serializers.IntegerField(source="history.count", read_only=True)
    retest_count = serializers.IntegerField(source="retests.count", read_only=True)
    status_transitions = BugStatusTransitionSerializer(many=True, read_only=True)

    class Meta:
        model = Bug
        fields = (
            "id",
            "bug_key",
            "project",
            "project_name",
            "project_key",
            "title",
            "description",
            "steps_to_reproduce",
            "expected_result",
            "actual_result",
            "severity",
            "priority",
            "status",
            "reported_by",
            "triaged_by",
            "assigned_to",
            "tech_lead",
            "verified_by",
            "environment",
            "application_version",
            "is_reopened",
            "reopen_count",
            "development_cycle",
            "due_at",
            "closed_at",
            "created_at",
            "updated_at",
            "engineering",
            "deployments",
            "retests",
            "assignments",
            "history_count",
            "retest_count",
            "status_transitions",
        )
        read_only_fields = (
            "id",
            "bug_key",
            "status",
            "reported_by",
            "triaged_by",
            "assigned_to",
            "tech_lead",
            "verified_by",
            "is_reopened",
            "reopen_count",
            "development_cycle",
            "closed_at",
            "created_at",
            "updated_at",
            "engineering",
            "deployments",
            "retests",
            "assignments",
            "history_count",
            "retest_count",
            "status_transitions",
        )


class BugListSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)
    project_key = serializers.CharField(source="project.key", read_only=True)
    reported_by = UserSummarySerializer(read_only=True)
    triaged_by = UserSummarySerializer(read_only=True)
    assigned_to = UserSummarySerializer(read_only=True)
    tech_lead = UserSummarySerializer(read_only=True)
    verified_by = UserSummarySerializer(read_only=True)

    class Meta:
        model = Bug
        fields = (
            "id",
            "bug_key",
            "project",
            "project_name",
            "project_key",
            "title",
            "description",
            "severity",
            "priority",
            "status",
            "reported_by",
            "triaged_by",
            "assigned_to",
            "tech_lead",
            "verified_by",
            "environment",
            "application_version",
            "is_reopened",
            "reopen_count",
            "development_cycle",
            "due_at",
            "closed_at",
            "created_at",
            "updated_at",
        )
        read_only_fields = fields


class ReportedIssueSerializer(serializers.ModelSerializer):
    project_name = serializers.CharField(source="project.name", read_only=True)
    project_key = serializers.CharField(source="project.key", read_only=True)
    reported_by = UserSummarySerializer(read_only=True)
    reviewed_by = UserSummarySerializer(read_only=True)
    converted_bug_key = serializers.CharField(source="converted_bug.bug_key", read_only=True, allow_null=True)

    class Meta:
        model = ReportedIssue
        fields = (
            "id", "issue_key", "project", "project_name", "project_key", "title",
            "description", "steps_to_reproduce", "expected_result", "actual_result",
            "severity", "priority", "environment", "application_version", "status",
            "reported_by", "reviewed_by", "review_note", "converted_bug", "converted_bug_key",
            "created_at", "updated_at",
        )
        read_only_fields = (
            "id", "issue_key", "reported_by", "reviewed_by", "status", "review_note",
            "converted_bug", "converted_bug_key", "created_at", "updated_at",
        )


class IssueReviewSerializer(serializers.Serializer):
    tech_lead_id = serializers.IntegerField()
    developer_id = serializers.IntegerField()
    note = serializers.CharField(required=False, allow_blank=True, max_length=2000)


class NotificationSerializer(serializers.ModelSerializer):
    bug_key = serializers.CharField(source="bug.bug_key", read_only=True, default="")

    class Meta:
        model = Notification
        fields = (
            "id",
            "bug",
            "bug_key",
            "title",
            "body",
            "kind",
            "is_read",
            "created_at",
            "read_at",
        )
        read_only_fields = fields


class NoteSerializer(serializers.Serializer):
    note = serializers.CharField(required=False, allow_blank=True, max_length=2000)


class LoginInputSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)


class LoginResponseSerializer(serializers.Serializer):
    access = serializers.CharField()
    refresh = serializers.CharField()
    user = UserSummarySerializer()


class LogoutInputSerializer(serializers.Serializer):
    refresh = serializers.CharField()


class DashboardResponseSerializer(serializers.Serializer):
    role = serializers.CharField()
    kpis = serializers.JSONField()
    status_distribution = serializers.ListField(child=serializers.JSONField())
    severity_distribution = serializers.ListField(child=serializers.JSONField())
    project_distribution = serializers.ListField(child=serializers.JSONField())
    team_workload = serializers.ListField(child=serializers.JSONField())
    trend = serializers.ListField(child=serializers.JSONField())
    action_required = serializers.ListField(child=serializers.JSONField())
    reported_issues = serializers.ListField(child=serializers.JSONField())
    recent_activity = serializers.ListField(child=serializers.JSONField())
    qa_retest_trend = serializers.ListField(child=serializers.JSONField())
    pr_status_distribution = serializers.ListField(child=serializers.JSONField())
    ci_distribution = serializers.ListField(child=serializers.JSONField())
    ready_for_retest_bugs = serializers.ListField(child=serializers.JSONField())
    recently_reported = serializers.ListField(child=serializers.JSONField())
    my_assigned_bugs = serializers.ListField(child=serializers.JSONField())
    pending_triage = serializers.ListField(child=serializers.JSONField())
    top_reopened = serializers.ListField(child=serializers.JSONField())
    overdue_bugs = serializers.ListField(child=serializers.JSONField())
    upcoming_deadlines = serializers.ListField(child=serializers.JSONField())
    project_progress = serializers.ListField(child=serializers.JSONField())
    project_health = serializers.ListField(child=serializers.JSONField())
    my_project_distribution = serializers.ListField(child=serializers.JSONField())
    productivity = serializers.ListField(child=serializers.JSONField())
    all_visible_bugs = serializers.ListField(child=serializers.JSONField())


class DeploymentActionResponseSerializer(serializers.Serializer):
    deployment = serializers.JSONField()
    status = serializers.CharField()


class ReadAllResponseSerializer(serializers.Serializer):
    updated = serializers.BooleanField()


class AssignmentInputSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    note = serializers.CharField(required=False, allow_blank=True, max_length=240)


class FixInputSerializer(serializers.Serializer):
    fix_notes = serializers.CharField(max_length=5000)


class PullRequestInputSerializer(serializers.Serializer):
    pull_request_url = serializers.URLField(max_length=500, required=False, allow_blank=True)
    pr_status = serializers.ChoiceField(choices=BugEngineering.PRStatus.choices)


class CIInputSerializer(serializers.Serializer):
    ci_status = serializers.ChoiceField(choices=BugEngineering.CIStatus.choices)
    ci_link = serializers.URLField(max_length=500, required=False, allow_blank=True)


class DeploymentInputSerializer(serializers.Serializer):
    environment = serializers.CharField(max_length=80)
    version = serializers.CharField(max_length=80, required=False, allow_blank=True)
    deployment_link = serializers.URLField(max_length=500, required=False, allow_blank=True)
    notes = serializers.CharField(required=False, allow_blank=True, max_length=2000)
