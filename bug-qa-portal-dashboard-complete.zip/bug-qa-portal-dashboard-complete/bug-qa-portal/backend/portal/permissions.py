from rest_framework.permissions import BasePermission


class CapabilityPermission(BasePermission):
    """Use a database-backed role permission for every protected endpoint."""

    def has_permission(self, request, view):
        code = getattr(view, "required_capability", None)
        return bool(
            request.user
            and request.user.is_authenticated
            and code
            and request.user.has_capability(code)
        )


def require_capability(user, code):
    if not user.has_capability(code):
        from rest_framework.exceptions import PermissionDenied

        raise PermissionDenied("You do not have permission to perform this action.")


def performed_mode(request):
    role = request.user.role_code
    requested = request.headers.get("X-Work-Mode", "").upper()
    if role == "MANAGER":
        return "MANAGER"
    if role == "QA" and requested == "DEVELOPER" and request.user.has_capability("BUG_DEVELOP"):
        return "QA_DEVELOPER_MODE"
    if (
        role == "TECH_LEAD"
        and requested == "DEVELOPER"
        and request.user.has_capability("BUG_DEVELOP")
    ):
        return "LEAD_DEVELOPER_MODE"
    return role or "DEVELOPER"
