from pathlib import Path

p = Path("frontend/pages/dashboard.py")
lines = p.read_text().splitlines()

keys = {
    39:  'key=f"status_chart_{title}")',
    63:  'key=f"severity_chart_{title}")',
    75:  'key=f"project_chart_{title}")',
    86:  'key=f"trend_chart_{title}")',
    269: 'key="qa_retest_trend_chart")',
    280: 'key="developer_pr_chart")',
    291: 'key="developer_ci_chart")',
    390: 'key="dashboard_secondary_chart_1")',
    400: 'key="dashboard_secondary_chart_2")',
}

for line_no, key_text in keys.items():
    old = lines[line_no - 1]
    start = old.rfind("key=")
    if start == -1:
        raise RuntimeError(f"No key found on line {line_no}")
    lines[line_no - 1] = old[:start] + key_text

p.write_text("\n".join(lines) + "\n")
print("Chart keys fixed successfully.")
